-- ============================================================================
-- OnlineKidz.Store — PostgreSQL schema (for Supabase or any PostgreSQL 13+)
-- Generated from src/db/schema.ts with drizzle-kit export.
--
-- Run once in the Supabase SQL Editor (or psql) before the first deploy.
-- Products, categories, reviews and journal articles are added automatically
-- the first time the website runs.
-- ============================================================================

CREATE TABLE IF NOT EXISTS "analytics_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"event_name" varchar(48) NOT NULL,
	"session_id" varchar(64) NOT NULL,
	"product_slug" varchar(140),
	"page_path" varchar(500) DEFAULT '' NOT NULL,
	"referrer" varchar(500) DEFAULT '' NOT NULL,
	"source" varchar(100) DEFAULT 'direct' NOT NULL,
	"device_type" varchar(24) DEFAULT 'unknown' NOT NULL,
	"experiment" varchar(80) DEFAULT '' NOT NULL,
	"variant" varchar(40) DEFAULT '' NOT NULL,
	"metadata" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS "blog_posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" varchar(160) NOT NULL,
	"title" varchar(240) NOT NULL,
	"excerpt" text NOT NULL,
	"category" varchar(100) NOT NULL,
	"author" varchar(120) NOT NULL,
	"reading_minutes" integer DEFAULT 5 NOT NULL,
	"hero_image" text NOT NULL,
	"published_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone,
	"sponsored" boolean DEFAULT false NOT NULL,
	"sources" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"content" jsonb NOT NULL,
	"featured" boolean DEFAULT false NOT NULL,
	CONSTRAINT "blog_posts_slug_unique" UNIQUE("slug")
);

CREATE TABLE IF NOT EXISTS "categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" varchar(96) NOT NULL,
	"name" varchar(120) NOT NULL,
	"tagline" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"image" text DEFAULT '' NOT NULL,
	"accent" varchar(32) DEFAULT 'terracotta' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "categories_slug_unique" UNIQUE("slug")
);

CREATE TABLE IF NOT EXISTS "orders" (
	"id" serial PRIMARY KEY NOT NULL,
	"order_number" varchar(32) NOT NULL,
	"customer_name" varchar(160) NOT NULL,
	"email" varchar(200) NOT NULL,
	"phone" varchar(32) DEFAULT '' NOT NULL,
	"address1" varchar(240) DEFAULT '' NOT NULL,
	"address2" varchar(240) DEFAULT '' NOT NULL,
	"city" varchar(120) DEFAULT '' NOT NULL,
	"state" varchar(120) DEFAULT '' NOT NULL,
	"pincode" varchar(16) DEFAULT '' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"payment_method" varchar(40) DEFAULT 'upi' NOT NULL,
	"coupon_code" varchar(40) DEFAULT '' NOT NULL,
	"subtotal" integer DEFAULT 0 NOT NULL,
	"shipping" integer DEFAULT 0 NOT NULL,
	"discount" integer DEFAULT 0 NOT NULL,
	"total" integer DEFAULT 0 NOT NULL,
	"status" varchar(32) DEFAULT 'confirmed' NOT NULL,
	"items" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "orders_order_number_unique" UNIQUE("order_number")
);

CREATE TABLE IF NOT EXISTS "products" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" varchar(140) NOT NULL,
	"name" varchar(200) NOT NULL,
	"category_slug" varchar(96) NOT NULL,
	"brand" varchar(120) DEFAULT 'OnlineKids' NOT NULL,
	"tagline" text DEFAULT '' NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"price" integer NOT NULL,
	"compare_at_price" integer,
	"rating" integer DEFAULT 48 NOT NULL,
	"review_count" integer DEFAULT 0 NOT NULL,
	"stock" integer DEFAULT 50 NOT NULL,
	"age_months_min" integer DEFAULT 0 NOT NULL,
	"age_months_max" integer DEFAULT 144 NOT NULL,
	"badge" varchar(48),
	"unit_label" varchar(80) DEFAULT '' NOT NULL,
	"images" jsonb NOT NULL,
	"highlights" jsonb NOT NULL,
	"details" jsonb NOT NULL,
	"is_featured" boolean DEFAULT false NOT NULL,
	"is_bestseller" boolean DEFAULT false NOT NULL,
	"is_new" boolean DEFAULT false NOT NULL,
	"sold_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "products_slug_unique" UNIQUE("slug")
);

CREATE TABLE IF NOT EXISTS "reviews" (
	"id" serial PRIMARY KEY NOT NULL,
	"product_slug" varchar(140) NOT NULL,
	"author" varchar(120) NOT NULL,
	"city" varchar(120) DEFAULT '' NOT NULL,
	"rating" integer NOT NULL,
	"title" varchar(200) DEFAULT '' NOT NULL,
	"body" text NOT NULL,
	"verified" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS "subscribers" (
	"id" serial PRIMARY KEY NOT NULL,
	"email" varchar(200) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "subscribers_email_unique" UNIQUE("email")
);

CREATE INDEX IF NOT EXISTS "analytics_event_time_idx" ON "analytics_events" USING btree ("event_name","created_at");
CREATE INDEX IF NOT EXISTS "analytics_product_time_idx" ON "analytics_events" USING btree ("product_slug","created_at");
CREATE INDEX IF NOT EXISTS "analytics_session_time_idx" ON "analytics_events" USING btree ("session_id","created_at");
CREATE INDEX IF NOT EXISTS "blog_posts_published_idx" ON "blog_posts" USING btree ("published_at");
CREATE INDEX IF NOT EXISTS "products_category_idx" ON "products" USING btree ("category_slug");
CREATE INDEX IF NOT EXISTS "reviews_product_idx" ON "reviews" USING btree ("product_slug");
