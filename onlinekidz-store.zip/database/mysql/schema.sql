-- ============================================================================
-- OnlineKidz.Store — MySQL schema
-- Converted from the live PostgreSQL / Drizzle schema (src/db/schema.ts).
--
-- Requirements: MySQL 8.0.13+ (JSON columns and expression defaults)
--               or MariaDB 10.5+.
-- Timestamps are stored as DATETIME(3) in UTC (PostgreSQL used timestamptz).
-- Booleans are TINYINT(1) (0 = false, 1 = true).
-- Money values are whole rupees (INT), matching the application.
-- products.rating is stored as rating x 10 (e.g. 48 = 4.8 stars).
-- ============================================================================

CREATE DATABASE IF NOT EXISTS onlinekidz_store
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE onlinekidz_store;

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- ----------------------------------------------------------------------------
-- categories
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  slug         VARCHAR(96)   NOT NULL,
  name         VARCHAR(120)  NOT NULL,
  tagline      TEXT          NOT NULL DEFAULT (''),
  description  TEXT          NOT NULL DEFAULT (''),
  image        TEXT          NOT NULL DEFAULT (''),
  accent       VARCHAR(32)   NOT NULL DEFAULT 'terracotta',
  sort_order   INT           NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY categories_slug_unique (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- products
-- images:     JSON array of image URLs, e.g. ["/images/a.jpg", "..."]
-- highlights: JSON array of strings
-- details:    JSON array of {"label": "...", "value": "..."}
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
  id                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  slug              VARCHAR(140)  NOT NULL,
  name              VARCHAR(200)  NOT NULL,
  category_slug     VARCHAR(96)   NOT NULL,
  brand             VARCHAR(120)  NOT NULL DEFAULT 'OnlineKidz',
  tagline           TEXT          NOT NULL DEFAULT (''),
  description       TEXT          NOT NULL DEFAULT (''),
  price             INT           NOT NULL,
  compare_at_price  INT           NULL,
  rating            INT           NOT NULL DEFAULT 48,
  review_count      INT           NOT NULL DEFAULT 0,
  stock             INT           NOT NULL DEFAULT 50,
  age_months_min    INT           NOT NULL DEFAULT 0,
  age_months_max    INT           NOT NULL DEFAULT 144,
  badge             VARCHAR(48)   NULL,
  unit_label        VARCHAR(80)   NOT NULL DEFAULT '',
  images            JSON          NOT NULL,
  highlights        JSON          NOT NULL,
  details           JSON          NOT NULL,
  is_featured       TINYINT(1)    NOT NULL DEFAULT 0,
  is_bestseller     TINYINT(1)    NOT NULL DEFAULT 0,
  is_new            TINYINT(1)    NOT NULL DEFAULT 0,
  sold_count        INT           NOT NULL DEFAULT 0,
  created_at        DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY products_slug_unique (slug),
  KEY products_category_idx (category_slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- reviews (linked to products by slug, as in the application)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reviews (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  product_slug  VARCHAR(140)  NOT NULL,
  author        VARCHAR(120)  NOT NULL,
  city          VARCHAR(120)  NOT NULL DEFAULT '',
  rating        INT           NOT NULL,
  title         VARCHAR(200)  NOT NULL DEFAULT '',
  body          TEXT          NOT NULL,
  verified      TINYINT(1)    NOT NULL DEFAULT 1,
  created_at    DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY reviews_product_idx (product_slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- orders
-- items: JSON array of {"slug","name","image","price","quantity","variant"?}
-- status: confirmed | packed | shipped | delivered | cancelled
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
  id              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  order_number    VARCHAR(32)   NOT NULL,
  customer_name   VARCHAR(160)  NOT NULL,
  email           VARCHAR(200)  NOT NULL,
  phone           VARCHAR(32)   NOT NULL DEFAULT '',
  address1        VARCHAR(240)  NOT NULL DEFAULT '',
  address2        VARCHAR(240)  NOT NULL DEFAULT '',
  city            VARCHAR(120)  NOT NULL DEFAULT '',
  state           VARCHAR(120)  NOT NULL DEFAULT '',
  pincode         VARCHAR(16)   NOT NULL DEFAULT '',
  notes           TEXT          NOT NULL DEFAULT (''),
  payment_method  VARCHAR(40)   NOT NULL DEFAULT 'upi',
  coupon_code     VARCHAR(40)   NOT NULL DEFAULT '',
  subtotal        INT           NOT NULL DEFAULT 0,
  shipping        INT           NOT NULL DEFAULT 0,
  discount        INT           NOT NULL DEFAULT 0,
  total           INT           NOT NULL DEFAULT 0,
  status          VARCHAR(32)   NOT NULL DEFAULT 'confirmed',
  items           JSON          NOT NULL,
  created_at      DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY orders_order_number_unique (order_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- subscribers (newsletter)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS subscribers (
  id          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  email       VARCHAR(200)  NOT NULL,
  created_at  DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY subscribers_email_unique (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- analytics_events (anonymous; no names, emails or addresses are stored)
-- metadata: JSON object of whitelisted keys (placement, cta_variant, ...)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS analytics_events (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  event_name    VARCHAR(48)   NOT NULL,
  session_id    VARCHAR(64)   NOT NULL,
  product_slug  VARCHAR(140)  NULL,
  page_path     VARCHAR(500)  NOT NULL DEFAULT '',
  referrer      VARCHAR(500)  NOT NULL DEFAULT '',
  source        VARCHAR(100)  NOT NULL DEFAULT 'direct',
  device_type   VARCHAR(24)   NOT NULL DEFAULT 'unknown',
  experiment    VARCHAR(80)   NOT NULL DEFAULT '',
  variant       VARCHAR(40)   NOT NULL DEFAULT '',
  metadata      JSON          NOT NULL DEFAULT (JSON_OBJECT()),
  created_at    DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY analytics_event_time_idx (event_name, created_at),
  KEY analytics_product_time_idx (product_slug, created_at),
  KEY analytics_session_time_idx (session_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- blog_posts (journal)
-- content: JSON array of blocks
--          {"type": "paragraph"|"heading"|"list"|"tip", "text"?: "...", "items"?: [...]}
-- sources: JSON array of {"label": "...", "url": "https://..."}
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS blog_posts (
  id               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  slug             VARCHAR(160)  NOT NULL,
  title            VARCHAR(240)  NOT NULL,
  excerpt          TEXT          NOT NULL,
  category         VARCHAR(100)  NOT NULL,
  author           VARCHAR(120)  NOT NULL,
  reading_minutes  INT           NOT NULL DEFAULT 5,
  hero_image       TEXT          NOT NULL,
  published_at     DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at       DATETIME(3)   NULL,
  sponsored        TINYINT(1)    NOT NULL DEFAULT 0,
  sources          JSON          NOT NULL DEFAULT (JSON_ARRAY()),
  content          JSON          NOT NULL,
  featured         TINYINT(1)    NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY blog_posts_slug_unique (slug),
  KEY blog_posts_published_idx (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
