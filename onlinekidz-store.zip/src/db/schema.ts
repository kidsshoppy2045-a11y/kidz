import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 96 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  image: text("image").notNull().default(""),
  accent: varchar("accent", { length: 32 }).notNull().default("terracotta"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 140 }).notNull().unique(),
    name: varchar("name", { length: 200 }).notNull(),
    categorySlug: varchar("category_slug", { length: 96 }).notNull(),
    brand: varchar("brand", { length: 120 }).notNull().default("OnlineKids"),
    tagline: text("tagline").notNull().default(""),
    description: text("description").notNull().default(""),
    price: integer("price").notNull(),
    compareAtPrice: integer("compare_at_price"),
    rating: integer("rating").notNull().default(48), // rating * 10
    reviewCount: integer("review_count").notNull().default(0),
    stock: integer("stock").notNull().default(50),
    ageMonthsMin: integer("age_months_min").notNull().default(0),
    ageMonthsMax: integer("age_months_max").notNull().default(144),
    badge: varchar("badge", { length: 48 }),
    unitLabel: varchar("unit_label", { length: 80 }).notNull().default(""),
    images: jsonb("images").$type<string[]>().notNull(),
    highlights: jsonb("highlights").$type<string[]>().notNull(),
    details: jsonb("details").$type<{ label: string; value: string }[]>().notNull(),
    isFeatured: boolean("is_featured").notNull().default(false),
    isBestseller: boolean("is_bestseller").notNull().default(false),
    isNew: boolean("is_new").notNull().default(false),
    soldCount: integer("sold_count").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("products_category_idx").on(table.categorySlug)],
);

export const reviews = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    productSlug: varchar("product_slug", { length: 140 }).notNull(),
    author: varchar("author", { length: 120 }).notNull(),
    city: varchar("city", { length: 120 }).notNull().default(""),
    rating: integer("rating").notNull(),
    title: varchar("title", { length: 200 }).notNull().default(""),
    body: text("body").notNull(),
    verified: boolean("verified").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("reviews_product_idx").on(table.productSlug)],
);

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 32 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull().default(""),
  address1: varchar("address1", { length: 240 }).notNull().default(""),
  address2: varchar("address2", { length: 240 }).notNull().default(""),
  city: varchar("city", { length: 120 }).notNull().default(""),
  state: varchar("state", { length: 120 }).notNull().default(""),
  pincode: varchar("pincode", { length: 16 }).notNull().default(""),
  notes: text("notes").notNull().default(""),
  paymentMethod: varchar("payment_method", { length: 40 }).notNull().default("upi"),
  couponCode: varchar("coupon_code", { length: 40 }).notNull().default(""),
  subtotal: integer("subtotal").notNull().default(0),
  shipping: integer("shipping").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  total: integer("total").notNull().default(0),
  status: varchar("status", { length: 32 }).notNull().default("confirmed"),
  items: jsonb("items")
    .$type<
      {
        slug: string;
        name: string;
        image: string;
        price: number;
        quantity: number;
        variant?: string;
      }[]
    >()
    .notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const analyticsEvents = pgTable(
  "analytics_events",
  {
    id: serial("id").primaryKey(),
    eventName: varchar("event_name", { length: 48 }).notNull(),
    sessionId: varchar("session_id", { length: 64 }).notNull(),
    productSlug: varchar("product_slug", { length: 140 }),
    pagePath: varchar("page_path", { length: 500 }).notNull().default(""),
    referrer: varchar("referrer", { length: 500 }).notNull().default(""),
    source: varchar("source", { length: 100 }).notNull().default("direct"),
    deviceType: varchar("device_type", { length: 24 }).notNull().default("unknown"),
    experiment: varchar("experiment", { length: 80 }).notNull().default(""),
    variant: varchar("variant", { length: 40 }).notNull().default(""),
    metadata: jsonb("metadata")
      .$type<Record<string, string | number | boolean>>()
      .notNull()
      .default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("analytics_event_time_idx").on(table.eventName, table.createdAt),
    index("analytics_product_time_idx").on(table.productSlug, table.createdAt),
    index("analytics_session_time_idx").on(table.sessionId, table.createdAt),
  ],
);

export const blogPosts = pgTable(
  "blog_posts",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 160 }).notNull().unique(),
    title: varchar("title", { length: 240 }).notNull(),
    excerpt: text("excerpt").notNull(),
    category: varchar("category", { length: 100 }).notNull(),
    author: varchar("author", { length: 120 }).notNull(),
    readingMinutes: integer("reading_minutes").notNull().default(5),
    heroImage: text("hero_image").notNull(),
    publishedAt: timestamp("published_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
    sponsored: boolean("sponsored").notNull().default(false),
    sources: jsonb("sources")
      .$type<{ label: string; url: string }[]>()
      .notNull()
      .default([]),
    content: jsonb("content")
      .$type<
        {
          type: "paragraph" | "heading" | "list" | "tip";
          text?: string;
          items?: string[];
        }[]
      >()
      .notNull(),
    featured: boolean("featured").notNull().default(false),
  },
  (table) => [index("blog_posts_published_idx").on(table.publishedAt)],
);

export type CategoryRow = typeof categories.$inferSelect;
export type ProductRow = typeof products.$inferSelect;
export type ReviewRow = typeof reviews.$inferSelect;
export type OrderRow = typeof orders.$inferSelect;
