import { sql } from "drizzle-orm";
import { db } from "./index";
import { categories, products, reviews, subscribers } from "./schema";
import { seedCategories, seedProducts } from "./seed-data";

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashString(value: string) {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const NAMES = [
  "Ananya Iyer", "Meera Nair", "Divya Reddy", "Sneha Kulkarni", "Ritika Sharma",
  "Pooja Deshmukh", "Kavya Menon", "Shalini Rao", "Farhana Sheikh", "Neha Bhatt",
  "Aditi Chauhan", "Lakshmi Prasad", "Tanvi Joshi", "Harpreet Kaur", "Swati Mishra",
  "Rohit Malhotra", "Vikram Subramanian", "Arjun Pillai", "Nikhil Ghosh", "Sameer Khan",
  "Ishita Banerjee", "Preeti Agarwal", "Deepa Venkatesh", "Manasi Patil", "Zoya Rahman",
  "Chaitra Hegde", "Nandini Gupta", "Reshma Thomas", "Aparna Das", "Kritika Saxena",
];

const CITIES = [
  "Bengaluru", "Chennai", "Mumbai", "Pune", "Hyderabad", "Kochi", "Delhi",
  "Gurugram", "Ahmedabad", "Kolkata", "Coimbatore", "Indore", "Nagpur", "Jaipur",
  "Mangaluru", "Vizag", "Noida", "Surat",
];

const REVIEW_TITLES: Record<string, string[]> = {
  "organic-foods": [
    "My fussy eater finishes the whole bowl",
    "Tastes exactly like my mother made it",
    "Clean ingredients, finally",
    "Worth every rupee",
    "Our new breakfast staple",
  ],
  "baby-care": [
    "Gentle enough for newborn skin",
    "No rash after three days of use",
    "Subtle fragrance, absorbs fast",
    "This is my third repurchase",
    "Paediatrician approved it too",
  ],
  diapers: [
    "Zero leaks through the night",
    "Survived a 6-hour road trip",
    "Soft waistband, no red marks",
    "Genuinely holds 12 hours",
    "Better than the brand we used before",
  ],
  toys: [
    "She plays with this every single day",
    "Beautifully finished, no splinters",
    "Screen-free and he loves it",
    "Sturdy — survived two toddlers",
    "Gifted this twice now",
  ],
  clothes: [
    "Softest cotton we own",
    "Colour hasn't faded after 15 washes",
    "Fits true to size",
    "Perfect for Indian summers",
    "Stitching quality is excellent",
  ],
  footwear: [
    "These actually stay on his feet",
    "Great grip on marble floors",
    "No blisters even on day one",
    "Wide toe box, very comfortable",
    "Podiatrist recommended soft soles — these deliver",
  ],
  "mother-care": [
    "My supply visibly improved",
    "Tastes like my postpartum month at home",
    "Comforting and not too sweet",
    "The belly butter is a must-buy",
    "Felt nourished through the 40 days",
  ],
};

const REVIEW_BODIES: Record<string, string[]> = {
  "organic-foods": [
    "I was skeptical about another health mix, but this one dissolves properly and doesn't leave a chalky aftertaste. My 18-month-old finishes the bowl and asks for more. Ordering the bigger pack next time.",
    "Ordered on a Thursday, delivered Saturday with a handwritten note on the box. The aroma when you open the pouch is unbelievable — you can tell it's freshly roasted. Mixes smooth with warm milk.",
    "We've tried four brands of porridge mix this year and this is the first one my daughter didn't spit out. Ingredient list is just one line, which is exactly what I wanted.",
    "Bought this for my twins after our paediatrician suggested iron-rich foods. Both of them love the taste and I love that there's no added sugar. It's been two months and their haemoglobin is up.",
    "Preparing it takes under five minutes which is all I have in the mornings. Slightly thicker than I expected, so I add a little extra water. Will definitely repurchase.",
  ],
  "baby-care": [
    "My son has eczema-prone skin and most washes left him red and itchy. This one has been gentle from day one, and the smell is very mild. A little goes a long way too.",
    "The massage oil warms up quickly and doesn't feel greasy afterwards. I use it before his bath every morning and his skin is noticeably softer than it was with the branded mineral oil we used earlier.",
    "Used the balm for a stubborn rash that wouldn't clear for a week. Two nights of applying it at every change and the redness was almost gone. Cloth diaper safe, which was the dealbreaker for me.",
    "Packaging is lovely — it actually looks nice on the bathroom shelf. More importantly it doesn't sting his eyes, which makes bath time far less of a battle.",
    "Arrived well protected with no leaks. I appreciate that they list every single ingredient openly instead of hiding behind 'parfum'. Reordered three bottles.",
  ],
  diapers: [
    "We use these overnight and have not had a single leak in six weeks. My toddler sleeps 11 hours, so that's saying something. They're slimmer than the premium brand we used before.",
    "The tabs are stretchy and forgiving when you're changing a baby who will not stay still. No red marks on the tummy in the morning, which we used to get all the time.",
    "Delivery was quick and the pack was well within date. Price per diaper works out cheaper than the supermarket brand and the quality is better.",
    "My daughter is a heavy wetter and these hold up. Only wish the size chart on the site mentioned that they run slightly small — I sized up and it was perfect.",
    "Bought these for a long train journey specifically because of the 12-hour claim. Two changes in 22 hours and no rash, no leaks. Very impressed.",
  ],
  toys: [
    "The finish on the wood is beautiful — properly sanded, nothing catches. My 14-month-old throws it around daily and it hasn't chipped. Would happily buy this as a gift.",
    "No batteries and no horrible electronic music, which is why I bought it. It has held her attention longer than any of the noisy plastic toys we own.",
    "Ordered this for my niece's first birthday and her parents messaged me later to say it's the only toy she carries around the house. The rattle is a nice touch for younger siblings.",
    "Solid, weighty, clearly handmade. There's a tiny variation in colour between rings which I actually like — you can tell it isn't factory made.",
    "Worth the price for something that will last through two kids and then go to a cousin. Assembly was nothing, just unbox and play.",
  ],
  clothes: [
    "The cotton is genuinely soft and breathable — my son wore it through a humid Chennai week with no heat rash. The block print is even prettier in person.",
    "Third wash and the colours are still bright. The envelope neck makes changes so much easier than the snap-shoulder ones we had before.",
    "Sizing is accurate. I ordered 12-18 months for my 11-month-old and there's room to grow. Stitching around the snaps is neat with no loose threads.",
    "Bought two sets for a family function. Got compliments all evening and my daughter was comfortable enough to nap in the kurta afterwards.",
    "Pre-washed so no shrinkage, exactly as promised. The fabric feels thicker than I expected for the price — very good value.",
  ],
  footwear: [
    "These are the only shoes he hasn't managed to kick off. The sole is flexible so he still walks naturally, and they grip our marble floors really well.",
    "My daughter has wide feet and most shoes leave marks. The toe box here is genuinely roomy and she walks without stumbling for the first time.",
    "Ordered two sizes because I wasn't sure, kept one and returned the other. Return was painless and refunded in three days.",
    "After three months of daily play-school use they still look decent. I machine washed the insoles and they came out fine.",
    "The elastic opening is the best part — no more hunting for a missing shoe in the supermarket aisle. Highly recommend for first walkers.",
  ],
  "mother-care": [
    "Third week of having these daily and I can feel the difference in supply. They're not overly sweet, which I was worried about, and the dry ginger is warming rather than sharp.",
    "My mother-in-law made these for me after delivery and now I order them. Tastes almost identical to homemade, which is the highest compliment I can give.",
    "The belly butter absorbs in a couple of minutes and doesn't stain clothes. I'm seven months pregnant and the itching has completely stopped since I started using it.",
    "The tea is now part of my evening routine. Gentle, caffeine-free, and it seems to help with the bloating I get in the evenings. Packaging is plastic-free.",
    "As a second-time mum I was sceptical about lactation foods, but the ingredients list is legit and the taste is genuinely good. My husband keeps stealing them.",
  ],
};

const NEUTRAL_BODIES = [
  "Exactly as described on the site. Good quality, quick delivery and nicely packaged. Would order again.",
  "Happy with the purchase overall. Nothing to complain about — the product does what it promises.",
  "Good value for the price. Delivery took a day longer than expected but the product itself is solid.",
];

type DraftReview = {
  productSlug: string;
  author: string;
  city: string;
  rating: number;
  title: string;
  body: string;
  verified: boolean;
  createdAt: Date;
};

function buildReviews(): DraftReview[] {
  const out: DraftReview[] = [];
  const now = Date.now();

  for (const product of seedProducts) {
    const rand = mulberry32(hashString(product.slug));
    const target = Math.min(6, Math.max(3, Math.round(product.reviewCount / 90) + 3));
    const pool = REVIEW_BODIES[product.categorySlug] ?? NEUTRAL_BODIES;
    const titles = REVIEW_TITLES[product.categorySlug] ?? ["Really happy with this"];

    // Build a rating set whose average is close to the product rating.
    const starTarget = Math.round(product.rating * 10) / 10;
    const ratings: number[] = [];
    for (let i = 0; i < target; i += 1) {
      const drift = rand() - 0.5;
      const r = Math.round(Math.min(5, Math.max(3, starTarget + drift * 1.6)));
      ratings.push(r);
    }
    const avg = ratings.reduce((a, b) => a + b, 0) / ratings.length;
    const diff = starTarget - avg;
    ratings[0] = Math.min(5, Math.max(3, Math.round(ratings[0] + diff)));

    const usedNames = new Set<string>();
    for (let i = 0; i < target; i += 1) {
      let author = NAMES[Math.floor(rand() * NAMES.length)];
      let guard = 0;
      while (usedNames.has(author) && guard < 8) {
        author = NAMES[Math.floor(rand() * NAMES.length)];
        guard += 1;
      }
      usedNames.add(author);
      const bodyIndex = Math.floor(rand() * pool.length);
      const titleIndex = Math.floor(rand() * titles.length);
      const daysAgo = Math.floor(rand() * 150) + 3;
      out.push({
        productSlug: product.slug,
        author,
        city: CITIES[Math.floor(rand() * CITIES.length)],
        rating: ratings[i],
        title: titles[titleIndex],
        body: pool[(bodyIndex + i) % pool.length],
        verified: false,
        createdAt: new Date(now - daysAgo * 86400000),
      });
    }
  }
  return out;
}

async function runSeed() {
  const existing = await db.execute<{ count: string }>(
    sql`select count(*)::text as count from ${products}`,
  );
  const count = Number(existing.rows?.[0]?.count ?? "0");
  if (count > 0) return { seeded: false };

  await db.insert(categories).values(seedCategories).onConflictDoNothing();
  await db.insert(subscribers).values([{ email: "demo@onlinekids.store" }]).onConflictDoNothing();

  const reviewDrafts = buildReviews();

  const rows = seedProducts.map((product) => {
    const productReviews = reviewDrafts.filter((r) => r.productSlug === product.slug);
    const average =
      productReviews.length > 0
        ? productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length
        : product.rating;
    return {
      slug: product.slug,
      name: product.name,
      categorySlug: product.categorySlug,
      brand: product.brand,
      tagline: product.tagline,
      description: product.description,
      price: product.price,
      compareAtPrice: product.compareAtPrice ?? null,
      rating: Math.round(average * 10),
      reviewCount: product.reviewCount,
      stock: product.stock,
      ageMonthsMin: product.ageMonthsMin,
      ageMonthsMax: product.ageMonthsMax,
      badge: product.badge ?? null,
      unitLabel: product.unitLabel,
      images: product.images,
      highlights: product.highlights,
      details: product.details,
      isFeatured: product.isFeatured ?? false,
      isBestseller: product.isBestseller ?? false,
      isNew: product.isNew ?? false,
      soldCount: product.soldCount,
    };
  });

  await db.insert(products).values(rows).onConflictDoNothing();
  await db.insert(reviews).values(reviewDrafts);

  return { seeded: true, products: rows.length, reviews: reviewDrafts.length };
}

let seedPromise: Promise<{ seeded: boolean }> | null = null;

export async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      console.error("[seed] failed", error);
      return { seeded: false };
    });
  }
  return seedPromise;
}
