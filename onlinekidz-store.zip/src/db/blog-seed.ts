import { eq } from "drizzle-orm";
import { db } from "./index";
import { blogPosts } from "./schema";

export type ArticleBlock = {
  type: "paragraph" | "heading" | "list" | "tip";
  text?: string;
  items?: string[];
};

export type ArticleSource = { label: string; url: string };

export const seedBlogPosts = [
  {
    slug: "first-foods-ragi-weaning-guide",
    title: "Starting solids? A gentle guide to ragi for little eaters",
    excerpt:
      "A practical, no-pressure way to introduce sprouted ragi after your baby's first tastes — with texture cues, simple recipes and the reminders parents actually need.",
    category: "Feeding & weaning",
    author: "Dr. Mira Rao, Paediatric Nutritionist",
    readingMinutes: 6,
    heroImage: "/images/products/ragi-porridge.jpg",
    publishedAt: new Date("2026-09-18T09:00:00Z"),
    featured: true,
    sources: [
      {
        label: "WHO Guideline for complementary feeding of infants and young children 6–23 months (2023)",
        url: "https://www.who.int/publications/i/item/9789240081864",
      },
      {
        label: "CDC: When, what, and how to introduce solid foods",
        url: "https://www.cdc.gov/infant-toddler-nutrition/foods-and-drinks/when-what-and-how-to-introduce-solid-foods.html",
      },
    ],
    content: [
      { type: "paragraph", text: "First foods can feel like a big milestone, and there is a lot of advice coming from every direction. Take a breath: your baby's own readiness cues matter more than a perfect menu. This guide is general information, not a substitute for your paediatrician's advice." },
      { type: "heading", text: "Wait for readiness, not a calendar date" },
      { type: "paragraph", text: "Many health organisations recommend starting complementary foods at about six months, once a baby can sit with support, hold their head steady and show interest in food. Keep breast milk or formula as the main source of nutrition through the first year, and ask your doctor if you have any concerns." },
      { type: "heading", text: "Make the first bowl simple" },
      { type: "paragraph", text: "A single-grain sprouted ragi porridge is easy to keep simple. Cook it thoroughly with water until smooth, let it cool to a safe temperature, and offer a small spoonful while your baby is upright and supervised. Follow your baby's lead — tasting, touching and turning away are all part of learning." },
      { type: "list", items: ["Start with a thin, spoonable texture; thicken gradually as your baby learns.", "Offer a small amount when your baby is rested, not ravenous or overtired.", "Keep salt, honey and added sugar out of infant foods.", "Introduce common allergens in age-appropriate forms with medical guidance."] },
      { type: "tip", text: "Ragi is a useful grain, not a complete meal on its own. As your baby grows, offer a varied mix of iron-rich foods, vegetables, fruit, protein sources and familiar family foods." },
      { type: "heading", text: "A few minutes of preparation" },
      { type: "paragraph", text: "Whisk the flour into cool water first to avoid lumps, then cook while stirring until it bubbles gently and thickens. Serve plain at first; once other ingredients have been safely introduced, you can build flavour with foods your family already uses." },
    ],
  },
  {
    slug: "five-easy-millet-breakfasts-for-toddlers",
    title: "Five easy millet breakfasts for busy toddler mornings",
    excerpt:
      "From a warm seven-millet drink to a soft banana pancake, these quick ideas make breakfast feel manageable on the mornings when the clock is winning.",
    category: "Recipes",
    author: "Ammu & the OnlineKids kitchen",
    readingMinutes: 5,
    heroImage: "/images/products/millet-mix.jpg",
    publishedAt: new Date("2026-09-02T09:00:00Z"),
    featured: true,
    content: [
      { type: "paragraph", text: "A good toddler breakfast does not need to be elaborate. Think familiar, soft, and easy to hold. These ideas use millet as one part of a varied breakfast, and can be adapted to the ingredients your family already enjoys." },
      { type: "heading", text: "1. Warm millet and banana bowl" },
      { type: "paragraph", text: "Cook a spoonful of millet flour with water until smooth, then stir in mashed banana after it has cooled a little. Keep the texture soft and offer a preloaded spoon so little hands can practise." },
      { type: "heading", text: "2. Mini ragi pancakes" },
      { type: "paragraph", text: "Mix ragi flour with mashed ripe banana, a little curd and enough water to make a thick batter. Cook small pancakes through on a lightly greased pan and cut into easy-to-grasp strips." },
      { type: "heading", text: "3. Soft savoury millet upma" },
      { type: "paragraph", text: "Cook a mild millet porridge with finely chopped, well-cooked vegetables. Keep the seasoning gentle and the pieces soft enough to squash between your fingers." },
      { type: "heading", text: "4. Millet and fruit yoghurt" },
      { type: "paragraph", text: "Stir a little cooled, fully cooked millet into plain yoghurt and top with soft fruit your child has already tried. This is a lovely option for warmer mornings." },
      { type: "heading", text: "5. A simple warm health-mix drink" },
      { type: "paragraph", text: "Whisk a family millet mix into warm milk or water, following the label for the recommended age and serving size. Check the allergen information carefully if it contains nuts." },
      { type: "tip", text: "Some mixes contain nuts or other allergens. Check the label, introduce new ingredients thoughtfully, and follow your paediatrician's advice for your child." },
    ],
  },
  {
    slug: "diaper-rash-gentle-change-routine",
    title: "A gentle nappy-change routine for sensitive little skin",
    excerpt:
      "Small, practical changes to help keep nappy-area skin clean, dry and comfortable — and clear signs that it's time to call your doctor.",
    category: "Baby care",
    author: "Ananya Iyer, Parent Care Editor",
    readingMinutes: 4,
    heroImage: "/images/products/baby-care-set.jpg",
    publishedAt: new Date("2026-08-12T09:00:00Z"),
    featured: false,
    sources: [
      {
        label: "American Academy of Pediatrics: Common Diaper Rashes & Treatments",
        url: "https://www.healthychildren.org/English/ages-stages/baby/diapers-clothing/Pages/Diaper-Rash.aspx",
      },
    ],
    content: [
      { type: "paragraph", text: "Nappy-area redness is common, and it can make the whole household feel unsettled. A calm, consistent routine can help protect delicate skin, but persistent or severe rashes deserve medical attention." },
      { type: "heading", text: "Keep the routine simple" },
      { type: "list", items: ["Change wet or soiled nappies promptly, especially after a poo.", "Clean gently with lukewarm water or a fragrance-free wipe; avoid scrubbing.", "Pat dry or give skin a little air time before putting on a fresh nappy.", "Fasten the nappy comfortably, not tightly, and choose breathable materials."] },
      { type: "heading", text: "Barrier care, if your doctor recommends it" },
      { type: "paragraph", text: "A thin layer of a suitable barrier cream may help protect skin from moisture. Use products as directed, avoid powders that can be inhaled, and stop anything that seems to irritate your baby's skin." },
      { type: "heading", text: "When to ask for help" },
      { type: "paragraph", text: "Contact your doctor if the rash is severe, blistered, bleeding, spreading beyond the nappy area, accompanied by fever, or not improving after a few days of gentle care. A clinician can check whether another treatment is needed." },
      { type: "tip", text: "If you're unsure whether a new product is right for your baby, ask your paediatrician or pharmacist before using it." },
    ],
  },
  {
    slug: "organic-cotton-baby-clothes-indian-weather",
    title: "Choosing baby clothes for Indian weather: cotton, layers and fit",
    excerpt:
      "A parent-friendly checklist for dressing a baby through hot afternoons, cool evenings and the very real possibility of a surprise change of clothes.",
    category: "Clothing & comfort",
    author: "Kavya Menon, Kidswear Editor",
    readingMinutes: 5,
    heroImage: "/images/products/baby-clothes.jpg",
    publishedAt: new Date("2026-07-28T09:00:00Z"),
    featured: false,
    sources: [
      {
        label: "American Academy of Pediatrics: Safe sleep and keeping babies comfortable",
        url: "https://www.healthychildren.org/English/ages-stages/baby/sleep/Pages/back-to-sleep-tummy-to-play.aspx",
      },
    ],
    content: [
      { type: "paragraph", text: "The right outfit is the one that lets your child move, nap and explore comfortably. Weather and indoor temperatures vary widely across India, so start with breathable layers you can add or remove." },
      { type: "heading", text: "Start with a soft base layer" },
      { type: "paragraph", text: "Lightweight cotton is a familiar choice for warm days. Look for smooth seams, comfortable neck openings and snaps or ties that make changing easier. A relaxed fit leaves room for movement without fabric getting in the way." },
      { type: "heading", text: "Pack for the day you actually have" },
      { type: "list", items: ["Keep a spare outfit and a thin muslin cloth in the day bag.", "Use one light extra layer for air-conditioned rooms or a breezy evening.", "Check your baby's chest or back to gauge comfort; hands and feet can feel cool even when baby is warm.", "Choose easy-care fabrics that can handle frequent washing."] },
      { type: "heading", text: "Wash before the first wear" },
      { type: "paragraph", text: "Wash new clothing before dressing your baby, especially if skin is sensitive. Use a gentle detergent, rinse thoroughly and follow the care label to help clothes keep their shape." },
      { type: "tip", text: "For sleep, follow current safe-sleep guidance from your healthcare professional rather than relying on extra clothing or loose blankets to keep a baby warm." },
    ],
  },
  {
    slug: "screen-free-play-ideas-12-to-36-months",
    title: "Five easy screen-free play ideas for curious toddlers",
    excerpt:
      "You don't need a playroom or a new toy every week. These simple invitations to play use everyday objects to build movement, language and imagination.",
    category: "Play & development",
    author: "Meera Nair, Early Play Guide",
    readingMinutes: 5,
    heroImage: "/images/products/wooden-toys.jpg",
    publishedAt: new Date("2026-07-04T09:00:00Z"),
    featured: true,
    content: [
      { type: "paragraph", text: "Toddlers learn by repeating, testing and making a glorious mess. A few safe household objects and your attention can be more than enough for a good play session." },
      { type: "heading", text: "1. Posting and sorting" },
      { type: "paragraph", text: "Offer large, age-appropriate objects and a wide container. Model putting one in, then let your child try. Stay close and avoid small items that could be a choking hazard." },
      { type: "heading", text: "2. A kitchen orchestra" },
      { type: "paragraph", text: "A wooden spoon and a sturdy pot can become a drum. Take turns making a sound, then pause and let your toddler answer." },
      { type: "heading", text: "3. Picture-book pointing" },
      { type: "paragraph", text: "You don't need to read every word. Point to familiar objects, name them, and follow your child's interest from page to page." },
      { type: "heading", text: "4. Laundry basket delivery" },
      { type: "paragraph", text: "A light basket can be pushed or filled with soft toys under supervision. Narrate where the toys are going and invite your toddler to help." },
      { type: "heading", text: "5. Water painting" },
      { type: "paragraph", text: "With an adult right beside them, let your child paint a patio or tray with a damp brush. The marks disappear as they dry, so the activity can begin again." },
      { type: "tip", text: "Supervise play closely, follow age labels, and keep small parts, cords, hot drinks and water out of reach." },
    ],
  },
  {
    slug: "postpartum-nourishment-small-meals",
    title: "Postpartum nourishment when a full meal feels impossible",
    excerpt:
      "Gentle, practical ways to make snacks and meals easier during the early weeks with a new baby — with no pressure to follow a perfect routine.",
    category: "Mother care",
    author: "Divya Reddy, Family Wellness Writer",
    readingMinutes: 6,
    heroImage: "/images/products/mother-care.jpg",
    publishedAt: new Date("2026-06-15T09:00:00Z"),
    featured: false,
    content: [
      { type: "paragraph", text: "In the early weeks after birth, eating well can be hard to fit between feeds, recovery and very little sleep. There is no single postpartum menu that suits everyone. Start with what feels manageable and ask your care team for individual advice." },
      { type: "heading", text: "Make food easier to reach" },
      { type: "list", items: ["Keep a water bottle and a snack where you usually feed the baby.", "Choose a few low-effort foods you already like: fruit, yoghurt, a sandwich or a warm bowl of rice and dal.", "Ask a friend or family member to prep one dish rather than asking what they can do.", "Use safe, labelled storage for prepared foods and leftovers."] },
      { type: "heading", text: "A snack is still a win" },
      { type: "paragraph", text: "A small snack can be more realistic than waiting for a perfect sit-down meal. If you have dietary restrictions, allergies, medication considerations or concerns about milk supply, talk to your doctor or a registered dietitian." },
      { type: "heading", text: "Be gentle with yourself" },
      { type: "paragraph", text: "Recovery is not a productivity challenge. Let other people help, take the rest you can, and remember that one missed meal does not define your health or your parenting." },
      { type: "tip", text: "Food products and herbal blends can interact with medication or affect people differently. Check with your healthcare professional before adding supplements or herbs while pregnant or breastfeeding." },
    ],
  },
] satisfies {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  readingMinutes: number;
  heroImage: string;
  publishedAt: Date;
  updatedAt?: Date;
  featured: boolean;
  sponsored?: boolean;
  sources?: ArticleSource[];
  content: ArticleBlock[];
}[];

let seedPromise: Promise<void> | null = null;

export async function ensureBlogSeeded() {
  if (!seedPromise) {
    seedPromise = (async () => {
      await db.insert(blogPosts).values(seedBlogPosts).onConflictDoNothing();
      for (const seededPost of seedBlogPosts) {
        if (!seededPost.sources?.length) continue;
        const [existing] = await db
          .select({ sources: blogPosts.sources })
          .from(blogPosts)
          .where(eq(blogPosts.slug, seededPost.slug))
          .limit(1);
        if (existing && existing.sources.length === 0) {
          await db
            .update(blogPosts)
            .set({ sources: seededPost.sources })
            .where(eq(blogPosts.slug, seededPost.slug));
        }
      }
    })().catch((error) => {
      seedPromise = null;
      console.error("[blog-seed] failed", error);
    });
  }
  return seedPromise;
}
