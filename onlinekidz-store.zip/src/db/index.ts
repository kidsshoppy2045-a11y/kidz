import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, type PoolConfig } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

/**
 * Hosted PostgreSQL (e.g. Supabase, used with Hostinger Node.js hosting)
 * requires SSL. Set DATABASE_SSL=require to enable it. The sslmode query
 * parameter is removed so it cannot override the explicit SSL settings.
 */
function poolConfig(url: string): PoolConfig {
  if (process.env.DATABASE_SSL !== "require") {
    return { connectionString: url, max: 10 };
  }
  const parsed = new URL(url);
  parsed.searchParams.delete("sslmode");
  return {
    connectionString: parsed.toString(),
    ssl: { rejectUnauthorized: false },
    max: 5,
  };
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool = globalForDb.__arenaNextJsPostgresqlPool ?? new Pool(poolConfig(databaseUrl));

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
