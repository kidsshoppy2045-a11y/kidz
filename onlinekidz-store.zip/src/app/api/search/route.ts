import { NextResponse } from "next/server";
import { getProducts } from "@/lib/data";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = (url.searchParams.get("q") ?? "").trim().slice(0, 80);
  if (query.length < 2) return NextResponse.json({ products: [] });

  const matches = await getProducts({ search: query, sort: "popular", limit: 5 });
  return NextResponse.json(
    {
      products: matches.map((product) => ({
        slug: product.slug,
        name: product.name,
        image: product.images[0] ?? "",
        price: product.price,
        categorySlug: product.categorySlug,
        tagline: product.tagline,
      })),
    },
    { headers: { "Cache-Control": "private, max-age=15" } },
  );
}
