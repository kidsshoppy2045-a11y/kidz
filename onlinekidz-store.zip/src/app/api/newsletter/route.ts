import { NextResponse } from "next/server";
import { addSubscriber } from "@/lib/data";

export async function POST(request: Request) {
  try {
    const { email } = (await request.json()) as { email?: string };
    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "Enter a valid email" }, { status: 400 });
    }
    await addSubscriber(email);
    return NextResponse.json({ ok: true, coupon: "LITTLE10" });
  } catch (error) {
    console.error("[api/newsletter] failed", error);
    return NextResponse.json({ error: "Could not subscribe right now" }, { status: 500 });
  }
}
