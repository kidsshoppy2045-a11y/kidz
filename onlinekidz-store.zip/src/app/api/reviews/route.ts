import { NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { getProductBySlug } from "@/lib/data";

export async function POST(request: Request) {
  let payload: {
    slug?: string;
    author?: string;
    city?: string;
    title?: string;
    body?: string;
    rating?: number;
  };

  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const slug = String(payload.slug ?? "");
  const author = String(payload.author ?? "").trim();
  const title = String(payload.title ?? "").trim();
  const body = String(payload.body ?? "").trim();
  const rating = Math.min(5, Math.max(1, Math.round(Number(payload.rating ?? 5))));

  if (!slug || !author || !title || body.length < 4) {
    return NextResponse.json({ error: "Please fill in every field" }, { status: 400 });
  }

  const product = await getProductBySlug(slug);
  if (!product) {
    return NextResponse.json({ error: "Unknown product" }, { status: 404 });
  }

  try {
    const [row] = await db
      .insert(reviews)
      .values({
        productSlug: slug,
        author,
        city: String(payload.city ?? "").trim(),
        rating,
        title,
        body,
        verified: false,
      })
      .returning();
    return NextResponse.json({ review: row });
  } catch (error) {
    console.error("[api/reviews] failed", error);
    return NextResponse.json({ error: "Could not save the review" }, { status: 500 });
  }
}
