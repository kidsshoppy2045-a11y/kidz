import { NextResponse } from "next/server";
import { computeTotals } from "@/lib/format";
import { createOrder, getProductsBySlugs } from "@/lib/data";

type IncomingItem = {
  slug?: string;
  quantity?: number;
  variant?: string;
};

export async function POST(request: Request) {
  let payload: {
    customer?: Record<string, string>;
    items?: IncomingItem[];
    express?: boolean;
  };

  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const items = (payload.items ?? []).filter(
    (item): item is { slug: string; quantity: number; variant?: string } =>
      typeof item.slug === "string" && typeof item.quantity === "number" && item.quantity > 0,
  );

  if (items.length === 0) {
    return NextResponse.json({ error: "Your basket is empty" }, { status: 400 });
  }

  const customer = payload.customer ?? {};
  const required = ["customerName", "email", "address1", "city", "state", "pincode"];
  const missing = required.filter((key) => !String(customer[key] ?? "").trim());
  if (missing.length > 0) {
    return NextResponse.json({ error: `Missing fields: ${missing.join(", ")}` }, { status: 400 });
  }

  const catalog = await getProductsBySlugs(items.map((item) => item.slug));
  const priced = items
    .map((item) => {
      const match = catalog.find((product) => product.slug === item.slug);
      if (!match) return null;
      return {
        slug: match.slug,
        name: match.name,
        image: match.images[0] ?? "",
        price: match.price,
        quantity: Math.min(20, Math.max(1, Math.round(item.quantity))),
        variant: item.variant,
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null);

  if (priced.length === 0) {
    return NextResponse.json({ error: "None of those products are available" }, { status: 400 });
  }

  const subtotal = priced.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totals = computeTotals(subtotal, customer.couponCode);
  const express = payload.express ? 149 : 0;
  const total = totals.total + express;

  try {
    const order = await createOrder({
      customerName: String(customer.customerName),
      email: String(customer.email),
      phone: String(customer.phone ?? ""),
      address1: String(customer.address1),
      address2: String(customer.address2 ?? ""),
      city: String(customer.city),
      state: String(customer.state),
      pincode: String(customer.pincode),
      notes: String(customer.notes ?? ""),
      paymentMethod: String(customer.paymentMethod ?? "upi"),
      couponCode: String(customer.couponCode ?? ""),
      items: priced,
      subtotal,
      shipping: totals.shipping,
      discount: totals.discount,
      total,
    });

    return NextResponse.json({
      orderNumber: order.orderNumber,
      total: order.total,
      etaDays: express ? 2 : 5,
    });
  } catch (error) {
    console.error("[api/orders] failed", error);
    return NextResponse.json({ error: "Could not place the order" }, { status: 500 });
  }
}
