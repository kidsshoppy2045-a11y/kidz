import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { subscribers } from "@/db/schema";
import { isAdmin } from "@/lib/admin-auth";

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db.select().from(subscribers).orderBy(desc(subscribers.createdAt));
  const escape = (value: string) => `"${value.replace(/"/g, '""')}"`;
  const csv = ["email,joined_at", ...rows.map((row) => `${escape(row.email)},${row.createdAt.toISOString()}`)].join("\n");
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="onlinekidz-subscribers.csv"',
      "Cache-Control": "no-store",
    },
  });
}
