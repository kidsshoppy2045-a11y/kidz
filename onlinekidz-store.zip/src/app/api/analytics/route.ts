import { NextResponse } from "next/server";
import { db } from "@/db";
import { analyticsEvents } from "@/db/schema";

const EVENT_NAMES = new Set([
  "page_view",
  "site_search",
  "product_click",
  "category_click",
  "hero_cta_click",
  "newsletter_signup",
  "article_click",
  "scroll_depth",
  "journal_engaged",
  "product_view",
  "cta_click",
  "add_to_cart",
  "buy_now",
  "checkout_start",
  "checkout_error",
  "purchase_complete",
  "cart_abandonment",
  "experiment_impression",
]);

const METADATA_KEYS = new Set([
  "placement",
  "experiment",
  "variant",
  "cta_variant",
  "cta_label",
  "quantity",
  "unit_price",
  "cart_count",
  "cart_value",
  "payment_method",
  "express",
  "step",
  "category",
  "term_length",
  "depth",
  "article_slug",
  "reading_seconds",
]);

function safeText(value: unknown, maxLength: number, fallback = "") {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : fallback;
}

function safeMetadata(value: unknown) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {} as Record<string, string | number | boolean>;
  }

  const result: Record<string, string | number | boolean> = {};
  for (const [key, entry] of Object.entries(value)) {
    if (!METADATA_KEYS.has(key)) continue;
    if (typeof entry === "string") result[key] = entry.slice(0, 120);
    else if (typeof entry === "number" && Number.isFinite(entry)) result[key] = entry;
    else if (typeof entry === "boolean") result[key] = entry;
  }
  return result;
}

export async function POST(request: Request) {
  let payload: Record<string, unknown>;
  try {
    payload = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const eventName = safeText(payload.eventName, 48);
  const sessionId = safeText(payload.sessionId, 64);
  if (!EVENT_NAMES.has(eventName) || sessionId.length < 8) {
    return NextResponse.json({ error: "Invalid analytics event" }, { status: 400 });
  }

  const slug = safeText(payload.productSlug, 140);
  const device = safeText(payload.deviceType, 24, "unknown");
  const path = safeText(payload.pagePath, 500);
  const metadata = safeMetadata(payload.metadata);

  try {
    await db.insert(analyticsEvents).values({
      eventName,
      sessionId,
      productSlug: slug || null,
      pagePath: path.startsWith("/") ? path : "",
      referrer: safeText(payload.referrer, 500),
      source: safeText(payload.source, 100, "direct").replace(/[^a-zA-Z0-9._-]/g, ""),
      deviceType: ["mobile", "tablet", "desktop"].includes(device) ? device : "unknown",
      experiment: safeText(metadata.experiment, 80),
      variant: safeText(metadata.cta_variant ?? metadata.variant, 40),
      metadata,
    });
    return NextResponse.json({ ok: true }, { status: 202 });
  } catch (error) {
    console.error("[api/analytics] failed", error);
    return NextResponse.json({ error: "Analytics unavailable" }, { status: 503 });
  }
}
