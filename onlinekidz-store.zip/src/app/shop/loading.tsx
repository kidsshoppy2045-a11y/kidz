export default function ShopLoading() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-20 pt-10 sm:px-6 lg:px-10">
      <div className="h-3 w-40 animate-pulse rounded-full bg-shell" />
      <div className="mt-5 h-10 w-2/3 animate-pulse rounded-2xl bg-shell" />
      <div className="mt-3 h-4 w-1/2 animate-pulse rounded-full bg-shell" />
      <div className="mt-8 grid gap-8 lg:grid-cols-[262px_1fr] lg:gap-10">
        <div className="hidden lg:block">
          <div className="h-[520px] animate-pulse rounded-3xl border border-sand bg-white/60" />
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 9 }).map((_, index) => (
            <div
              key={index}
              className="overflow-hidden rounded-3xl border border-sand bg-white/60"
              style={{ animationDelay: `${index * 60}ms` }}
            >
              <div className="aspect-square animate-pulse bg-shell" />
              <div className="space-y-2.5 p-5">
                <div className="h-2.5 w-20 animate-pulse rounded-full bg-shell" />
                <div className="h-4 w-4/5 animate-pulse rounded-full bg-shell" />
                <div className="h-3 w-2/3 animate-pulse rounded-full bg-shell" />
                <div className="h-5 w-24 animate-pulse rounded-full bg-shell" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
