import type { Metadata } from "next";
import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import { Pagination } from "@/components/pagination";
import { Reveal } from "@/components/reveal";
import { ShopFilters } from "@/components/shop-filters";
import { SortSelect } from "@/components/sort-select";
import { getCategories, getFacets, getProductCount, getProducts } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop all baby & kids essentials",
  description:
    "Browse 35+ curated organic foods, baby care, diapers, toys, clothing and footwear essentials for children aged 0–12.",
};

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const one = (value: string | string[] | undefined) =>
  Array.isArray(value) ? value[0] : value || undefined;

const PAGE_SIZE = 12;

function parsePage(value: string | undefined) {
  const parsed = Number(value ?? "1");
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 1;
}

export default async function ShopPage({ searchParams }: { searchParams: SearchParams }) {
  const resolved = await searchParams;
  const query = {
    category: one(resolved.category),
    search: one(resolved.q),
    age: one(resolved.age),
    price: one(resolved.price),
    rating: one(resolved.rating),
    sort: one(resolved.sort),
    tag: one(resolved.tag),
  };
  const requestedPage = parsePage(one(resolved.page));

  const [categories, facets, totalItems] = await Promise.all([
    getCategories(),
    getFacets(),
    getProductCount(query),
  ]);
  const totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));
  const currentPage = Math.min(requestedPage, totalPages);
  const products = await getProducts({
    ...query,
    limit: PAGE_SIZE,
    offset: (currentPage - 1) * PAGE_SIZE,
  });

  const activeCategory = categories.find((category) => category.slug === query.category);
  const heading = query.search
    ? `Results for “${query.search}”`
    : query.tag === "bestsellers"
      ? "Bestsellers"
      : query.tag === "new"
        ? "New & most loved arrivals"
        : (activeCategory?.name ?? "Everything for little ones");

  const subheading =
    activeCategory?.description ??
    "Handpicked by a paediatric nutritionist and two very opinionated mothers. Every label read, every claim checked.";

  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-20 pt-10 sm:px-6 lg:px-10">
      <nav className="flex items-center gap-2 text-[12px] text-ink-soft/70">
        <Link href="/" className="transition hover:text-clay">
          Home
        </Link>
        <span>/</span>
        <span className="text-ink">Shop</span>
        {activeCategory ? (
          <>
            <span>/</span>
            <span className="text-ink">{activeCategory.name}</span>
          </>
        ) : null}
      </nav>

      <header className="mt-5 max-w-3xl">
        <h1 className="font-display text-[34px] leading-[1.08] text-ink sm:text-[46px]">{heading}</h1>
        <p className="mt-3 text-[15.5px] leading-relaxed text-ink-soft">{subheading}</p>
      </header>

      <div className="mt-8 grid gap-8 lg:grid-cols-[262px_1fr] lg:gap-10">
        <ShopFilters
          categories={categories}
          facets={facets}
          params={{
            category: query.category,
            age: query.age,
            price: query.price,
            rating: query.rating,
            q: query.search,
            tag: query.tag,
            sort: query.sort,
          }}
          resultCount={totalItems}
        />

        <div>
          <div className="mb-5 hidden items-center justify-between gap-4 lg:flex">
            <p className="text-[13.5px] text-ink-soft">
              Showing{" "}
              <strong className="font-semibold text-ink">
                {totalItems === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1}–
                {Math.min(currentPage * PAGE_SIZE, totalItems)}
              </strong>{" "}
              of {totalItems} matching products
            </p>
            <SortSelect value={query.sort ?? "featured"} />
          </div>

          {products.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-sand bg-white/60 px-6 py-20 text-center">
              <span className="text-4xl">🔍</span>
              <h2 className="mt-4 font-display text-2xl text-ink">No matches just yet</h2>
              <p className="mt-2 max-w-sm text-sm text-ink-soft">
                Try removing a filter, or explore our bestsellers — there&apos;s usually something
                there.
              </p>
              <Link
                href="/shop"
                className="mt-6 rounded-full bg-clay px-6 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark"
              >
                Reset the shop
              </Link>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {products.map((product, index) => (
                <Reveal key={product.slug} delay={(index % 3) * 60}>
                  <ProductCard product={product} priority={index < 3} />
                </Reveal>
              ))}
            </div>
          )}
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalItems={totalItems}
            pageSize={PAGE_SIZE}
            pathname="/shop"
            itemLabel="products"
            query={{
              category: query.category,
              q: query.search,
              age: query.age,
              price: query.price,
              rating: query.rating,
              sort: query.sort,
              tag: query.tag,
            }}
          />
        </div>
      </div>
    </div>
  );
}
