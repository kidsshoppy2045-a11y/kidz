export default function ProductLoading() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-20 pt-8 sm:px-6 lg:px-10">
      <div className="h-3 w-64 animate-pulse rounded-full bg-shell" />
      <div className="mt-6 grid gap-10 lg:grid-cols-[minmax(0,1fr)_460px] lg:gap-14">
        <div className="aspect-square animate-pulse rounded-[2rem] bg-shell" />
        <div className="space-y-4">
          <div className="h-3 w-24 animate-pulse rounded-full bg-shell" />
          <div className="h-9 w-4/5 animate-pulse rounded-2xl bg-shell" />
          <div className="h-4 w-2/3 animate-pulse rounded-full bg-shell" />
          <div className="h-5 w-32 animate-pulse rounded-full bg-shell" />
          <div className="h-14 w-full animate-pulse rounded-2xl bg-shell" />
          <div className="h-12 w-full animate-pulse rounded-full bg-shell" />
          <div className="h-32 w-full animate-pulse rounded-2xl bg-shell" />
        </div>
      </div>
    </div>
  );
}
