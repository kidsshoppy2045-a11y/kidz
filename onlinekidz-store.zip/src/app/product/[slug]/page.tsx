import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/product-card";
import { ProductGallery } from "@/components/product-gallery";
import { ProductPurchase } from "@/components/product-purchase";
import { ProductTabs } from "@/components/product-tabs";
import { ProductViewAnalytics } from "@/components/product-view-analytics";
import { Reveal } from "@/components/reveal";
import { ReviewSummary } from "@/components/review-form";
import { Stars } from "@/components/stars";
import { CheckIcon, LeafIcon, ShieldIcon, TruckIcon } from "@/components/icons";
import { getCategory, getProductBySlug, getRelatedProducts, getReviews } from "@/lib/data";
import { discountPercent, formatAgeRange, formatDate, formatINR, formatRating } from "@/lib/format";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

const SIZE_VARIANTS: Record<string, string[]> = {
  clothes: ["0–6 mo", "6–12 mo", "12–18 mo", "18–24 mo", "2–3 yr", "3–4 yr", "5–6 yr", "7–8 yr"],
  footwear: ["EU 17", "EU 19", "EU 21", "EU 23", "EU 25", "EU 27", "EU 29", "EU 31"],
  diapers: ["Newborn · up to 5 kg", "Small · 4–8 kg", "Medium · 6–11 kg", "Large · 9–14 kg"],
};

const PRODUCT_DEMO_VIDEOS: Record<string, { src: string; poster: string; title: string }> = {
  "organic-foods": {
    src: "https://videos.pexels.com/video-files/7508622/7508622-uhd_2160_4096_25fps.mp4",
    poster: "https://images.pexels.com/videos/7508622/pexels-photo-7508622.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "A first-food feeding moment",
  },
  "baby-care": {
    src: "https://videos.pexels.com/video-files/8909638/8909638-uhd_2160_4096_25fps.mp4",
    poster: "https://images.pexels.com/videos/8909638/adolescence-adult-affection-baby-8909638.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "A gentle after-bath routine",
  },
  diapers: {
    src: "https://videos.pexels.com/video-files/7279103/7279103-uhd_2160_3840_24fps.mp4",
    poster: "https://images.pexels.com/videos/7279103/pexels-photo-7279103.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "A changing-time routine",
  },
  toys: {
    src: "https://videos.pexels.com/video-files/8046397/8046397-hd_1080_1920_25fps.mp4",
    poster: "https://images.pexels.com/videos/8046397/adult-artisan-arts-and-crafts-baby-8046397.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "Little hands at play",
  },
  clothes: {
    src: "https://videos.pexels.com/video-files/7280836/7280836-uhd_2160_3840_24fps.mp4",
    poster: "https://images.pexels.com/videos/7280836/pexels-photo-7280836.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "A getting-dressed moment",
  },
  footwear: {
    src: "https://videos.pexels.com/video-files/8046147/8046147-hd_1080_1920_25fps.mp4",
    poster: "https://images.pexels.com/videos/8046147/adolescence-adult-affection-baby-8046147.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "A toddler on the move",
  },
  "mother-care": {
    src: "https://videos.pexels.com/video-files/6386571/6386571-uhd_2160_3840_24fps.mp4",
    poster: "https://images.pexels.com/videos/6386571/pexels-photo-6386571.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    title: "A quiet moment with baby",
  },
};

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: product.name,
    description: product.tagline || product.description.slice(0, 150),
    openGraph: { title: product.name, description: product.tagline, images: [product.images[0]] },
  };
}

export default async function ProductPage({ params }: { params: Params }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [category, related, reviewRows] = await Promise.all([
    getCategory(product.categorySlug),
    getRelatedProducts(product, 4),
    getReviews(product.slug),
  ]);

  const off = discountPercent(product.price, product.compareAtPrice);
  const distribution = [5, 4, 3, 2, 1].map((stars) => ({
    stars,
    count:
      stars === 5
        ? Math.round(product.reviewCount * (product.rating / 10 >= 4.8 ? 0.86 : 0.7))
        : stars === 4
          ? Math.round(product.reviewCount * 0.2)
          : stars === 3
            ? Math.round(product.reviewCount * 0.06)
            : stars === 2
              ? Math.round(product.reviewCount * 0.02)
              : Math.round(product.reviewCount * 0.01),
  }));

  const variants = SIZE_VARIANTS[product.categorySlug] ?? [];
  const relevantVariants =
    variants.length > 0
      ? variants.slice(0, product.categorySlug === "diapers" ? 4 : 6)
      : [];
  const careInstruction =
    product.details.find((detail) => /how to use|serving|storage|care/i.test(detail.label))?.value ??
    product.highlights[0] ??
    "Follow the product label and your healthcare professional's guidance.";
  const productStructuredData = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description,
    image: product.images,
    sku: product.slug,
    brand: { "@type": "Brand", name: product.brand },
    offers: {
      "@type": "Offer",
      url: `https://onlinekids.store/product/${product.slug}`,
      priceCurrency: "INR",
      price: product.price,
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      itemCondition: "https://schema.org/NewCondition",
    },
  };
  const faqs = [
    {
      question: "How do I use or care for this product?",
      answer: careInstruction,
    },
    {
      question: "What age is it suitable for?",
      answer: `This product is listed for ${formatAgeRange(product.ageMonthsMin, product.ageMonthsMax)}. Every child is different; follow the product label and ask your paediatrician if you are unsure.`,
    },
    {
      question: "When will my order arrive?",
      answer: "Orders are usually dispatched within 24 hours. Delivery takes 2–5 working days across India; enter your pincode above for an estimate.",
    },
    {
      question: "Can I return it if it is not right for us?",
      answer: "Unopened products can be returned within 30 days. Contact our parent-support team to arrange a return pickup.",
    },
  ];

  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-20 pt-8 sm:px-6 lg:px-10">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productStructuredData) }}
      />
      <ProductViewAnalytics
        product={{
          slug: product.slug,
          name: product.name,
          image: product.images[0] ?? "",
          price: product.price,
          brand: product.brand,
          tagline: product.tagline,
        }}
      />
      <nav className="flex flex-wrap items-center gap-2 text-[12px] text-ink-soft/70">
        <Link href="/" className="transition hover:text-clay">
          Home
        </Link>
        <span>/</span>
        <Link href="/shop" className="transition hover:text-clay">
          Shop
        </Link>
        <span>/</span>
        <Link href={`/collections/${product.categorySlug}`} className="transition hover:text-clay">
          {category?.name ?? product.categorySlug}
        </Link>
        <span>/</span>
        <span className="text-ink">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-[minmax(0,1fr)_460px] lg:gap-14">
        <ProductGallery
          images={product.images}
          name={product.name}
          badge={product.badge ?? (product.isNew ? "New arrival" : null)}
          demoVideo={PRODUCT_DEMO_VIDEOS[product.categorySlug]}
        />

        <div className="lg:pt-2">
          <Link
            href={`/collections/${product.categorySlug}`}
            className="text-[11px] font-semibold uppercase tracking-[0.18em] text-clay transition hover:text-ink"
          >
            {product.brand}
          </Link>
          <h1 className="mt-2 font-display text-[30px] leading-[1.12] text-ink sm:text-[38px]">
            {product.name}
          </h1>
          <p className="mt-2.5 text-[15.5px] leading-relaxed text-ink-soft">{product.tagline}</p>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Stars rating={product.rating / 10} size={16} />
              <span className="text-[13.5px] font-semibold text-ink">
                {formatRating(product.rating)}
              </span>
            </div>
            <a href="#reviews" className="text-[13px] text-ink-soft underline hover:text-clay">
              {product.reviewCount} reviews
            </a>
            <span className="text-[13px] text-ink-soft">·</span>
            <span className="text-[13px] text-ink-soft">
              {product.soldCount.toLocaleString("en-IN")} sold
            </span>
          </div>

          <div className="mt-5 flex flex-wrap items-baseline gap-3 border-y border-sand py-5">
            <span className="font-display text-[34px] leading-none text-ink">
              {formatINR(product.price)}
            </span>
            {product.compareAtPrice ? (
              <span className="text-[17px] text-ink-soft/55 line-through">
                {formatINR(product.compareAtPrice)}
              </span>
            ) : null}
            {off ? (
              <span className="rounded-full bg-brand-orange/15 px-2.5 py-1 text-[12px] font-bold text-[#a8520a]">
                Save {off}%
              </span>
            ) : null}
            <span className="w-full text-[12.5px] text-ink-soft/80">
              {product.unitLabel} · inclusive of all taxes
            </span>
          </div>

          <ProductPurchase
            slug={product.slug}
            name={product.name}
            image={product.images[0]}
            price={product.price}
            compareAtPrice={product.compareAtPrice}
            unitLabel={product.unitLabel}
            variants={relevantVariants}
            inStock={product.stock > 0}
            brand={product.brand}
            tagline={product.tagline}
            rating={product.rating}
            reviewCount={product.reviewCount}
            ageMonthsMin={product.ageMonthsMin}
            ageMonthsMax={product.ageMonthsMax}
            categorySlug={product.categorySlug}
          />

          <div className="mt-6 grid grid-cols-2 gap-3">
            {[
              { icon: LeafIcon, title: "Clean label", body: "No preservatives or added sugar" },
              { icon: ShieldIcon, title: "Lab tested", body: "Every batch, every quarter" },
              { icon: TruckIcon, title: "Ships in 24 hrs", body: "From Coorg, across India" },
              { icon: CheckIcon, title: "30-day returns", body: "Unopened packs, free pickup" },
            ].map((item) => (
              <div
                key={item.title}
                className="flex items-start gap-2.5 rounded-2xl border border-sand/80 bg-white p-3"
              >
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-shell text-clay">
                  <item.icon width={14} height={14} />
                </span>
                <span>
                  <span className="block text-[12.5px] font-semibold text-ink">{item.title}</span>
                  <span className="block text-[11.5px] leading-snug text-ink-soft/80">
                    {item.body}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <ProductTabs
        tabs={[
          {
            id: "about",
            label: "The details",
            content: (
              <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
                <div>
                  <p className="max-w-2xl text-[15.5px] leading-[1.75] text-ink-soft">
                    {product.description}
                  </p>
                  <h3 className="mt-7 font-display text-xl text-ink">What makes it different</h3>
                  <ul className="mt-3 grid gap-2.5 sm:grid-cols-2">
                    {product.highlights.map((point) => (
                      <li
                        key={point}
                        className="flex items-start gap-2.5 rounded-2xl border border-sand/70 bg-white p-3.5"
                      >
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-sage/20 text-teal">
                          <CheckIcon width={12} height={12} />
                        </span>
                        <span className="text-[13.5px] leading-relaxed text-ink-soft">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <dl className="rounded-3xl border border-sand bg-white p-5 shadow-soft">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-soft/70">
                    At a glance
                  </p>
                  <div className="mt-3 divide-y divide-sand">
                    {product.details.map((detail) => (
                      <div key={detail.label} className="py-3">
                        <dt className="text-[12px] font-semibold uppercase tracking-wider text-ink-soft/70">
                          {detail.label}
                        </dt>
                        <dd className="mt-0.5 text-[13.5px] leading-relaxed text-ink">
                          {detail.value}
                        </dd>
                      </div>
                    ))}
                    <div className="py-3">
                      <dt className="text-[12px] font-semibold uppercase tracking-wider text-ink-soft/70">
                        Suitable for
                      </dt>
                      <dd className="mt-0.5 text-[13.5px] text-ink">
                        {formatAgeRange(product.ageMonthsMin, product.ageMonthsMax)}
                      </dd>
                    </div>
                  </div>
                  <Link
                    href={`/collections/${product.categorySlug}`}
                    className="mt-4 inline-flex text-[13px] font-semibold text-clay hover:text-ink"
                  >
                    More from {category?.name ?? "this collection"} →
                  </Link>
                </dl>
              </div>
            ),
          },
          {
            id: "faq",
            label: "FAQs",
            content: (
              <div className="mx-auto max-w-3xl space-y-3">
                {faqs.map((faq) => (
                  <details key={faq.question} className="group rounded-2xl border border-sand bg-white p-5 shadow-soft">
                    <summary className="flex cursor-pointer list-none items-center justify-between gap-4">
                      <span className="text-[14px] font-semibold text-ink">{faq.question}</span>
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-shell text-clay transition-transform group-open:rotate-45">
                        +
                      </span>
                    </summary>
                    <p className="mt-3 text-[14px] leading-relaxed text-ink-soft">{faq.answer}</p>
                  </details>
                ))}
              </div>
            ),
          },
          {
            id: "reviews",
            label: `Reviews (${product.reviewCount})`,
            content: (
              <div id="reviews" className="space-y-6">
                <ReviewSummary
                  slug={product.slug}
                  rating={product.rating}
                  count={product.reviewCount}
                  distribution={distribution}
                />
                <ul className="space-y-4">
                  {reviewRows.map((review) => (
                    <li
                      key={review.id}
                      className="rounded-3xl border border-sand/80 bg-white p-5 shadow-soft"
                    >
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-shell text-[12px] font-bold text-clay">
                          {review.author.charAt(0)}
                        </span>
                        <span>
                          <span className="block text-[13.5px] font-semibold text-ink">
                            {review.author}
                            {review.city ? (
                              <span className="font-normal text-ink-soft/70"> · {review.city}</span>
                            ) : null}
                          </span>
                          <span className="block text-[11.5px] text-ink-soft/70">
                            {formatDate(review.createdAt)}
                          </span>
                        </span>
                        <span className="ml-auto flex items-center gap-2">
                          <Stars rating={review.rating} size={13} />
                          {review.verified ? (
                            <span className="rounded-full bg-sage/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-teal">
                              Verified
                            </span>
                          ) : null}
                        </span>
                      </div>
                      <p className="mt-3 font-display text-[17px] text-ink">{review.title}</p>
                      <p className="mt-1.5 text-[14px] leading-relaxed text-ink-soft">{review.body}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ),
          },
          {
            id: "shipping",
            label: "Shipping & returns",
            content: (
              <div className="grid gap-4 sm:grid-cols-3">
                {[
                  {
                    title: "Dispatched in 24 hours",
                    body: "Freshly milled stock leaves our Coorg unit within a working day. You'll get a tracking link by SMS and email.",
                  },
                  {
                    title: "Free over ₹999",
                    body: `Orders below ₹999 carry a flat ₹79 delivery fee. Cash on delivery is available on all pin codes we serve.`,
                  },
                  {
                    title: "30-day easy returns",
                    body: "Unopened packs can be returned within 30 days for a full refund — we arrange the pickup, no courier run for you.",
                  },
                ].map((card) => (
                  <div key={card.title} className="rounded-3xl border border-sand bg-white p-5">
                    <p className="font-display text-[17px] text-ink">{card.title}</p>
                    <p className="mt-2 text-[13.5px] leading-relaxed text-ink-soft">{card.body}</p>
                  </div>
                ))}
              </div>
            ),
          },
        ]}
      />

      {related.length > 0 ? (
        <section className="mt-20">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 className="font-display text-[26px] text-ink sm:text-[32px]">
              Pairs nicely with these
            </h2>
            <Link
              href={`/collections/${product.categorySlug}`}
              className="text-[13.5px] font-semibold text-clay hover:text-ink"
            >
              See the whole collection →
            </Link>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((item, index) => (
              <Reveal key={item.slug} delay={index * 60}>
                <ProductCard product={item} compact />
              </Reveal>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
