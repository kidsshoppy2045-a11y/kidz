import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-28 text-center">
      <span className="text-5xl">🧸</span>
      <h1 className="mt-5 font-display text-4xl text-ink">This shelf is empty</h1>
      <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">
        The page you were looking for has wandered off. Let&apos;s get you back to the good stuff.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Link
          href="/shop"
          className="rounded-full bg-clay px-6 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark"
        >
          Browse the shop
        </Link>
        <Link
          href="/"
          className="rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:border-clay hover:text-clay"
        >
          Back home
        </Link>
      </div>
    </div>
  );
}
