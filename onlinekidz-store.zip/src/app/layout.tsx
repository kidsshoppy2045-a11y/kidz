import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/cart-context";
import { PageAnalytics } from "@/components/page-analytics";
import { CartDrawer } from "@/components/cart-drawer";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { Toaster } from "@/components/toaster";
import { getCategories } from "@/lib/data";

export const metadata: Metadata = {
  title: {
    default: "OnlineKidz.Store · Organic baby, kids & mother essentials",
    template: "%s · OnlineKidz.Store",
  },
  description:
    "Homemade organic millet mixes, porridges, baby care, diapers, clothes, footwear and toys for children aged 0–12 — and honest nourishment for new mothers.",
  keywords: [
    "baby products online",
    "organic baby food India",
    "millet porridge mix",
    "sprouted ragi",
    "baby diapers",
    "kids clothing",
    "mother care",
  ],
  openGraph: {
    title: "OnlineKidz.Store · Organic baby, kids & mother essentials",
    description:
      "Trusted, health-conscious essentials for expecting parents, new mothers and families with children aged 0–12.",
    type: "website",
  },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const categories = await getCategories();
  const structuredData = [
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "OnlineKidz.Store",
      url: "https://onlinekids.store",
      email: "hello@onlinekids.store",
      description:
        "Thoughtful baby, kids and mother-care essentials, including homemade Indian-inspired foods.",
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: "OnlineKidz.Store",
      url: "https://onlinekids.store",
      potentialAction: {
        "@type": "SearchAction",
        target: "https://onlinekids.store/shop?q={search_term_string}",
        "query-input": "required name=search_term_string",
      },
    },
  ];

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Nunito+Sans:opsz,wght@6..12,400;6..12,600;6..12,700;6..12,800&display=swap"
          rel="stylesheet"
        />
        {structuredData.map((schema, index) => (
          <script
            key={index}
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
          />
        ))}
      </head>
      <body className="min-h-screen antialiased">
        <CartProvider>
          <PageAnalytics />
          <SiteHeader categories={categories} />
          <main>{children}</main>
          <SiteFooter />
          <CartDrawer />
          <Toaster />
        </CartProvider>
      </body>
    </html>
  );
}
