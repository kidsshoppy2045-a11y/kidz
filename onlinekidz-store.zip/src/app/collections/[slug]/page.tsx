import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/product-card";
import { Pagination } from "@/components/pagination";
import { Reveal } from "@/components/reveal";
import { SortSelect } from "@/components/sort-select";
import { getCategories, getCategory, getProductCount, getProducts } from "@/lib/data";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;
type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const one = (value: string | string[] | undefined) =>
  Array.isArray(value) ? value[0] : value || undefined;

const PAGE_SIZE = 12;

function parsePage(value: string | undefined) {
  const parsed = Number(value ?? "1");
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 1;
}

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) return { title: "Collection not found" };
  return { title: category.name, description: category.description };
}

export default async function CollectionPage({
  params,
  searchParams,
}: {
  params: Params;
  searchParams: SearchParams;
}) {
  const { slug } = await params;
  const resolved = await searchParams;
  const category = await getCategory(slug);
  if (!category) notFound();

  const sort = one(resolved.sort);
  const requestedPage = parsePage(one(resolved.page));
  const [totalItems, categories] = await Promise.all([
    getProductCount({ category: slug }),
    getCategories(),
  ]);
  const totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));
  const currentPage = Math.min(requestedPage, totalPages);
  const products = await getProducts({
    category: slug,
    sort,
    limit: PAGE_SIZE,
    offset: (currentPage - 1) * PAGE_SIZE,
  });

  return (
    <div className="pb-20">
      <section className="relative overflow-hidden border-b border-sand bg-shell/60">
        <div className="mx-auto grid max-w-[1400px] items-center gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[1.2fr_1fr] lg:px-10 lg:py-16">
          <div className="animate-fade-up">
            <nav className="flex items-center gap-2 text-[12px] text-ink-soft/70">
              <Link href="/" className="transition hover:text-clay">
                Home
              </Link>
              <span>/</span>
              <Link href="/shop" className="transition hover:text-clay">
                Shop
              </Link>
              <span>/</span>
              <span className="text-ink">{category.name}</span>
            </nav>
            <p className="mt-5 text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              {category.tagline}
            </p>
            <h1 className="mt-2 font-display text-[34px] leading-[1.08] text-ink sm:text-[48px]">
              {category.name}
            </h1>
            <p className="mt-4 max-w-xl text-[15.5px] leading-relaxed text-ink-soft">
              {category.description}
            </p>
          </div>
          <div className="relative overflow-hidden rounded-[2rem] border border-white/70 shadow-lift animate-fade-in">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={category.image}
              alt={category.name}
              className="h-[240px] w-full object-cover sm:h-[320px]"
            />
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-[1400px] px-4 pt-8 sm:px-6 lg:px-10">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <p className="text-[13.5px] text-ink-soft">
            Showing{" "}
            <strong className="font-semibold text-ink">
              {totalItems === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1}–
              {Math.min(currentPage * PAGE_SIZE, totalItems)}
            </strong>{" "}
            of {totalItems} products in {category.name}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1.5">
              {categories
                .filter((item) => item.slug !== slug)
                .slice(0, 4)
                .map((item) => (
                  <Link
                    key={item.slug}
                    href={`/collections/${item.slug}`}
                    className="rounded-full border border-sand bg-white px-3.5 py-2 text-[12.5px] font-medium text-ink transition hover:border-clay hover:text-clay"
                  >
                    {item.name}
                  </Link>
                ))}
            </div>
            <SortSelect value={sort ?? "featured"} pathname={`/collections/${slug}`} />
          </div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((product, index) => (
            <Reveal key={product.slug} delay={(index % 4) * 60}>
              <ProductCard product={product} priority={index < 4} />
            </Reveal>
          ))}
        </div>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={totalItems}
          pageSize={PAGE_SIZE}
          pathname={`/collections/${slug}`}
          itemLabel="collection products"
          query={{ sort }}
        />

        <div className="mt-12 rounded-3xl border border-sand bg-white p-7 text-center shadow-soft">
          <h2 className="font-display text-2xl text-ink">Not sure where to start?</h2>
          <p className="mx-auto mt-2 max-w-xl text-[14.5px] leading-relaxed text-ink-soft">
            Tell us your child&apos;s age and we&apos;ll shortlist the essentials — or take the whole
            shop for a spin with every filter off.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <Link
              href={`/shop?category=${category.slug}&sort=rating`}
              className="rounded-full bg-clay px-6 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark"
            >
              Top rated in {category.name}
            </Link>
            <Link
              href="/shop"
              className="rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:border-clay hover:text-clay"
            >
              Browse everything
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
