import { redirect } from "next/navigation";
import { adminConfigured, isAdmin } from "@/lib/admin-auth";
import { login } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminLogin({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  if (await isAdmin()) redirect("/admin");
  const { error } = await searchParams;
  const configured = adminConfigured();

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm rounded-3xl border border-sand bg-white p-7 shadow-lift">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/brand/cart-mark.svg" alt="" className="h-12 w-12" />
        <h1 className="mt-4 font-display text-2xl text-ink">OnlineKidz admin</h1>
        <p className="mt-1 text-[13px] text-ink-soft">Sign in to manage the store.</p>

        {!configured ? (
          <p role="alert" className="mt-5 rounded-xl bg-brand-orange/10 p-3 text-[13px] text-ink">
            Set an <code>ADMIN_PASSWORD</code> environment variable (8+ characters) to enable the admin panel.
          </p>
        ) : (
          <form action={login} className="mt-5 space-y-3">
            <label htmlFor="password" className="block text-[12px] font-semibold uppercase tracking-wider text-ink-soft">
              Password
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              autoComplete="current-password"
              className="w-full rounded-xl border border-sand bg-cream px-4 py-3 text-sm outline-none focus:border-clay"
            />
            {error ? (
              <p role="alert" className="text-[12.5px] font-medium text-brand-pink">
                That password didn&apos;t match. Please try again.
              </p>
            ) : null}
            <button type="submit" className="w-full rounded-full bg-clay py-3 text-sm font-semibold text-white transition hover:bg-clay-dark">
              Sign in
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
