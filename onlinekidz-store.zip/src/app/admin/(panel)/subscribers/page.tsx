import { desc } from "drizzle-orm";
import { db } from "@/db";
import { subscribers } from "@/db/schema";
import { formatDate } from "@/lib/format";
import { deleteSubscriber } from "../../actions";

export const dynamic = "force-dynamic";

export default async function AdminSubscribers() {
  const rows = await db.select().from(subscribers).orderBy(desc(subscribers.createdAt)).limit(1000);
  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl text-ink">Subscribers</h1>
          <p className="mt-1 text-[13.5px] text-ink-soft">{rows.length} newsletter subscribers</p>
        </div>
        <a href="/api/admin/subscribers" className="rounded-full bg-clay px-5 py-2.5 text-[13px] font-semibold text-white hover:bg-clay-dark">
          Export CSV
        </a>
      </header>
      <ul className="divide-y divide-sand rounded-2xl border border-sand bg-white shadow-soft">
        {rows.map((subscriber) => (
          <li key={subscriber.id} className="flex items-center justify-between gap-3 p-4 text-[13px]">
            <span>
              <span className="block font-medium text-ink">{subscriber.email}</span>
              <span className="text-ink-soft">Joined {formatDate(subscriber.createdAt)}</span>
            </span>
            <form action={deleteSubscriber}>
              <input type="hidden" name="id" value={subscriber.id} />
              <button type="submit" className="rounded-full border border-sand px-3.5 py-2 text-[12px] font-semibold text-brand-pink hover:border-brand-pink">
                Remove
              </button>
            </form>
          </li>
        ))}
      </ul>
    </div>
  );
}
