import Link from "next/link";
import { asc, count, desc, gte, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { analyticsEvents, blogPosts, orders, products, subscribers } from "@/db/schema";
import { formatDate, formatINR } from "@/lib/format";

export const dynamic = "force-dynamic";

const FUNNEL = [
  { key: "product_view", label: "Product views" },
  { key: "add_to_cart", label: "Add to cart" },
  { key: "checkout_start", label: "Checkouts started" },
  { key: "purchase_complete", label: "Purchases" },
];

export default async function AdminDashboard() {
  const since = new Date(Date.now() - 30 * 86400000);
  const [[sales], [productCount], [subscriberCount], [postCount], events, recent, lowStock] = await Promise.all([
    db
      .select({
        revenue: sql<number>`coalesce(sum(${orders.total}), 0)::int`,
        total: count(),
      })
      .from(orders)
      .where(ne(orders.status, "cancelled")),
    db.select({ total: count() }).from(products),
    db.select({ total: count() }).from(subscribers),
    db.select({ total: count() }).from(blogPosts),
    db
      .select({ name: analyticsEvents.eventName, total: count() })
      .from(analyticsEvents)
      .where(gte(analyticsEvents.createdAt, since))
      .groupBy(analyticsEvents.eventName),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(6),
    db.select().from(products).orderBy(asc(products.stock)).limit(5),
  ]);

  const eventCount = (name: string) => Number(events.find((event) => event.name === name)?.total ?? 0);
  const orderTotal = Number(sales?.total ?? 0);
  const revenue = Number(sales?.revenue ?? 0);
  const views = eventCount("product_view");
  const purchases = eventCount("purchase_complete");

  const kpis = [
    { label: "Revenue (all time)", value: formatINR(revenue) },
    { label: "Orders", value: orderTotal.toLocaleString("en-IN") },
    { label: "Average order", value: orderTotal ? formatINR(revenue / orderTotal) : "—" },
    { label: "Products", value: Number(productCount?.total ?? 0) },
    { label: "Subscribers", value: Number(subscriberCount?.total ?? 0) },
    { label: "Journal articles", value: Number(postCount?.total ?? 0) },
  ];

  return (
    <div className="space-y-8">
      <header>
        <h1 className="font-display text-3xl text-ink">Dashboard</h1>
        <p className="mt-1 text-[13.5px] text-ink-soft">Store performance at a glance.</p>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="rounded-2xl border border-sand bg-white p-5 shadow-soft">
            <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-ink-soft">{kpi.label}</p>
            <p className="mt-2 font-display text-2xl text-ink">{kpi.value}</p>
          </div>
        ))}
      </section>

      <section className="rounded-2xl border border-sand bg-white p-5 shadow-soft">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <h2 className="font-display text-xl text-ink">Conversion funnel · last 30 days</h2>
          <p className="text-[12px] text-ink-soft">
            View → purchase rate: <strong className="text-ink">{views ? `${((purchases / views) * 100).toFixed(1)}%` : "—"}</strong>
          </p>
        </div>
        <div className="mt-4 space-y-3">
          {FUNNEL.map((step) => {
            const value = eventCount(step.key);
            const width = views ? Math.max(2, Math.round((value / views) * 100)) : 0;
            return (
              <div key={step.key} className="grid grid-cols-[140px_1fr_60px] items-center gap-3 text-[13px]">
                <span className="text-ink-soft">{step.label}</span>
                <span className="h-2.5 overflow-hidden rounded-full bg-shell">
                  <span className="block h-full rounded-full bg-clay" style={{ width: `${width}%` }} />
                </span>
                <span className="text-right font-semibold text-ink">{value}</span>
              </div>
            );
          })}
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <section className="rounded-2xl border border-sand bg-white p-5 shadow-soft">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl text-ink">Recent orders</h2>
            <Link href="/admin/orders" className="text-[12.5px] font-semibold text-clay hover:underline">All orders →</Link>
          </div>
          {recent.length === 0 ? (
            <p className="mt-4 text-[13px] text-ink-soft">No orders yet.</p>
          ) : (
            <ul className="mt-3 divide-y divide-sand">
              {recent.map((order) => (
                <li key={order.id} className="flex items-center justify-between gap-3 py-3 text-[13px]">
                  <span>
                    <span className="block font-semibold text-ink">{order.orderNumber}</span>
                    <span className="text-ink-soft">{order.customerName} · {formatDate(order.createdAt)}</span>
                  </span>
                  <span className="text-right">
                    <span className="block font-semibold text-ink">{formatINR(order.total)}</span>
                    <span className="text-[11px] uppercase tracking-wider text-ink-soft">{order.status}</span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-sand bg-white p-5 shadow-soft">
          <h2 className="font-display text-xl text-ink">Lowest stock</h2>
          <ul className="mt-3 divide-y divide-sand">
            {lowStock.map((product) => (
              <li key={product.id} className="flex items-center justify-between gap-3 py-3 text-[13px]">
                <Link href={`/admin/products/${product.id}`} className="line-clamp-1 font-medium text-ink hover:text-clay">
                  {product.name}
                </Link>
                <span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold ${product.stock < 20 ? "bg-brand-orange/15 text-[#a8520a]" : "bg-shell text-ink"}`}>
                  {product.stock} left
                </span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
