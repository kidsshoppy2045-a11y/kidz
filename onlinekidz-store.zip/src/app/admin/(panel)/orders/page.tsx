import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { ORDER_STATUSES } from "@/lib/admin-content";
import { formatDate, formatINR } from "@/lib/format";
import { updateOrderStatus } from "../../actions";

export const dynamic = "force-dynamic";

export default async function AdminOrders({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;
  const filter = (ORDER_STATUSES as readonly string[]).includes(status ?? "") ? status : undefined;
  const rows = await db
    .select()
    .from(orders)
    .where(filter ? eq(orders.status, filter) : undefined)
    .orderBy(desc(orders.createdAt))
    .limit(200);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl text-ink">Orders</h1>
        <p className="mt-1 text-[13.5px] text-ink-soft">{rows.length} order{rows.length === 1 ? "" : "s"} shown</p>
      </header>

      <div className="flex flex-wrap gap-2">
        {["all", ...ORDER_STATUSES].map((name) => {
          const active = (name === "all" && !filter) || name === filter;
          return (
            <Link
              key={name}
              href={name === "all" ? "/admin/orders" : `/admin/orders?status=${name}`}
              className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold capitalize ${
                active ? "bg-clay text-white" : "border border-sand bg-white text-ink hover:border-clay"
              }`}
            >
              {name}
            </Link>
          );
        })}
      </div>

      {rows.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-sand bg-white p-8 text-center text-[13px] text-ink-soft">
          No orders in this view.
        </p>
      ) : (
        <div className="space-y-3">
          {rows.map((order) => (
            <details key={order.id} className="group rounded-2xl border border-sand bg-white shadow-soft">
              <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-6 gap-y-2 p-4">
                <span className="min-w-[150px]">
                  <span className="block font-semibold text-ink">{order.orderNumber}</span>
                  <span className="text-[12px] text-ink-soft">{formatDate(order.createdAt)}</span>
                </span>
                <span className="min-w-[160px] text-[13px] text-ink">{order.customerName}</span>
                <span className="text-[13px] text-ink-soft">{order.items.reduce((sum, item) => sum + item.quantity, 0)} items · {order.paymentMethod.toUpperCase()}</span>
                <span className="ml-auto font-semibold text-ink">{formatINR(order.total)}</span>
                <span className="rounded-full bg-shell px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-ink">{order.status}</span>
              </summary>
              <div className="grid gap-5 border-t border-sand p-4 md:grid-cols-2">
                <div className="text-[13px] leading-relaxed text-ink-soft">
                  <p className="font-semibold text-ink">Customer</p>
                  <p>{order.customerName} · {order.email} · {order.phone}</p>
                  <p>{order.address1}{order.address2 ? `, ${order.address2}` : ""}, {order.city}, {order.state} {order.pincode}</p>
                  {order.notes ? <p className="mt-1 italic">“{order.notes}”</p> : null}
                  <p className="mt-3 font-semibold text-ink">Items</p>
                  <ul>
                    {order.items.map((item) => (
                      <li key={`${item.slug}-${item.variant ?? ""}`}>
                        {item.quantity} × {item.name}{item.variant ? ` (${item.variant})` : ""} — {formatINR(item.price * item.quantity)}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2">
                    Subtotal {formatINR(order.subtotal)} · Discount {formatINR(order.discount)}
                    {order.couponCode ? ` (${order.couponCode})` : ""} · Shipping {formatINR(order.shipping)}
                  </p>
                </div>
                <form action={updateOrderStatus} className="flex items-end gap-2 md:justify-end">
                  <input type="hidden" name="id" value={order.id} />
                  <label className="text-[12px] font-semibold text-ink-soft">
                    Status
                    <select name="status" defaultValue={order.status} className="mt-1 block rounded-xl border border-sand bg-white px-3 py-2.5 text-sm capitalize text-ink">
                      {ORDER_STATUSES.map((value) => (
                        <option key={value} value={value}>{value}</option>
                      ))}
                    </select>
                  </label>
                  <button type="submit" className="rounded-full bg-clay px-4 py-2.5 text-[13px] font-semibold text-white hover:bg-clay-dark">
                    Update
                  </button>
                </form>
              </div>
            </details>
          ))}
        </div>
      )}
    </div>
  );
}
