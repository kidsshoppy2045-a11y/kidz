import Link from "next/link";
import type { ReactNode } from "react";
import { requireAdmin } from "@/lib/admin-auth";
import { logout } from "../actions";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/reviews", label: "Reviews" },
  { href: "/admin/journal", label: "Journal" },
  { href: "/admin/subscribers", label: "Subscribers" },
];

export default async function AdminPanelLayout({ children }: { children: ReactNode }) {
  await requireAdmin();

  return (
    <div className="lg:flex">
      <aside className="border-b border-sand bg-white lg:sticky lg:top-0 lg:h-screen lg:w-60 lg:shrink-0 lg:border-b-0 lg:border-r">
        <div className="flex items-center justify-between gap-3 px-5 py-4">
          <Link href="/admin" className="flex items-center gap-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/brand/cart-mark.svg" alt="" className="h-8 w-8" />
            <span className="font-display text-lg text-ink">Admin</span>
          </Link>
          <Link href="/" className="text-[12px] font-semibold text-clay hover:underline">
            View store ↗
          </Link>
        </div>
        <nav aria-label="Admin" className="flex gap-1 overflow-x-auto px-3 pb-3 no-scrollbar lg:flex-col lg:overflow-visible">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="shrink-0 rounded-xl px-3 py-2.5 text-[13.5px] font-semibold text-ink transition hover:bg-shell"
            >
              {item.label}
            </Link>
          ))}
          <form action={logout} className="shrink-0 lg:mt-4">
            <button type="submit" className="w-full rounded-xl px-3 py-2.5 text-left text-[13.5px] font-semibold text-ink-soft transition hover:bg-shell">
              Sign out
            </button>
          </form>
        </nav>
      </aside>
      <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-10 lg:py-8">{children}</main>
    </div>
  );
}
