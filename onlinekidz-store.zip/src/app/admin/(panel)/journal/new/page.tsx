import Link from "next/link";
import { PostForm } from "@/components/admin/post-form";
import { Notice } from "@/components/admin/form-fields";

export const dynamic = "force-dynamic";

export default async function NewPost({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return (
    <div className="space-y-6">
      <Link href="/admin/journal" className="text-[13px] font-semibold text-clay hover:underline">← Journal</Link>
      <h1 className="font-display text-3xl text-ink">New article</h1>
      <Notice error={error} />
      <PostForm />
    </div>
  );
}
