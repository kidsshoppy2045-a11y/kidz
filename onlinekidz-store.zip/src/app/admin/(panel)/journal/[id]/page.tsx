import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { PostForm } from "@/components/admin/post-form";
import { Notice } from "@/components/admin/form-fields";
import { deletePost } from "../../../actions";

export const dynamic = "force-dynamic";

export default async function EditPost({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; saved?: string }>;
}) {
  const { id } = await params;
  const { error, saved } = await searchParams;
  const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, Number(id) || 0));
  if (!post) notFound();

  return (
    <div className="space-y-6">
      <Link href="/admin/journal" className="text-[13px] font-semibold text-clay hover:underline">← Journal</Link>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-3xl text-ink">{post.title}</h1>
        <Link href={`/blog/${post.slug}`} className="text-[13px] font-semibold text-clay hover:underline">View article ↗</Link>
      </div>
      <Notice error={error} saved={saved} />
      <PostForm post={post} />
      <form action={deletePost} className="border-t border-sand pt-6">
        <input type="hidden" name="id" value={post.id} />
        <button type="submit" className="rounded-full border border-brand-pink px-5 py-2.5 text-[13px] font-semibold text-brand-pink hover:bg-brand-pink hover:text-white">
          Delete article
        </button>
      </form>
    </div>
  );
}
