import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminJournal() {
  const rows = await db.select().from(blogPosts).orderBy(desc(blogPosts.publishedAt));
  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl text-ink">Journal</h1>
          <p className="mt-1 text-[13.5px] text-ink-soft">{rows.length} articles</p>
        </div>
        <Link href="/admin/journal/new" className="rounded-full bg-clay px-5 py-2.5 text-[13px] font-semibold text-white hover:bg-clay-dark">
          + New article
        </Link>
      </header>
      <ul className="divide-y divide-sand rounded-2xl border border-sand bg-white shadow-soft">
        {rows.map((post) => (
          <li key={post.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="min-w-0">
              <Link href={`/admin/journal/${post.id}`} className="font-semibold text-ink hover:text-clay">{post.title}</Link>
              <p className="text-[12px] text-ink-soft">
                {post.category} · {post.author} · {formatDate(post.publishedAt)}
                {post.featured ? " · Featured" : ""}{post.sponsored ? " · Sponsored" : ""}
              </p>
            </div>
            <Link href={`/admin/journal/${post.id}`} className="text-[13px] font-semibold text-clay hover:underline">Edit</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
