import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { formatDate } from "@/lib/format";
import { deleteReview, toggleReviewVerified } from "../../actions";

export const dynamic = "force-dynamic";

export default async function AdminReviews() {
  const rows = await db
    .select({ review: reviews, productName: products.name })
    .from(reviews)
    .leftJoin(products, eq(products.slug, reviews.productSlug))
    .orderBy(desc(reviews.createdAt))
    .limit(150);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl text-ink">Reviews</h1>
        <p className="mt-1 text-[13.5px] text-ink-soft">
          Mark a review verified only after confirming a matching purchase.
        </p>
      </header>
      <ul className="space-y-3">
        {rows.map(({ review, productName }) => (
          <li key={review.id} className="rounded-2xl border border-sand bg-white p-4 shadow-soft">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[12px] text-ink-soft">
                  <span className="font-semibold text-ink">{review.author}</span>
                  {review.city ? ` · ${review.city}` : ""} · {formatDate(review.createdAt)} · {"★".repeat(review.rating)}
                </p>
                <p className="mt-0.5 text-[11.5px] text-clay">{productName ?? review.productSlug}</p>
                <p className="mt-2 font-semibold text-ink">{review.title}</p>
                <p className="mt-1 text-[13px] leading-relaxed text-ink-soft">{review.body}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                <form action={toggleReviewVerified}>
                  <input type="hidden" name="id" value={review.id} />
                  <input type="hidden" name="verified" value={String(review.verified)} />
                  <button
                    type="submit"
                    className={`rounded-full px-3.5 py-2 text-[12px] font-semibold ${
                      review.verified ? "bg-brand-green text-white" : "border border-sand bg-white text-ink hover:border-brand-green"
                    }`}
                  >
                    {review.verified ? "Verified ✓" : "Mark verified"}
                  </button>
                </form>
                <form action={deleteReview}>
                  <input type="hidden" name="id" value={review.id} />
                  <button type="submit" className="rounded-full border border-sand px-3.5 py-2 text-[12px] font-semibold text-brand-pink hover:border-brand-pink">
                    Delete
                  </button>
                </form>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
