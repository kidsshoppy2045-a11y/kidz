import Link from "next/link";
import { asc, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { formatINR } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminProducts({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const term = q?.trim();
  const rows = await db
    .select()
    .from(products)
    .where(term ? or(ilike(products.name, `%${term}%`), ilike(products.slug, `%${term}%`)) : undefined)
    .orderBy(asc(products.categorySlug), asc(products.name))
    .limit(300);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl text-ink">Products</h1>
          <p className="mt-1 text-[13.5px] text-ink-soft">{rows.length} products</p>
        </div>
        <Link href="/admin/products/new" className="rounded-full bg-clay px-5 py-2.5 text-[13px] font-semibold text-white hover:bg-clay-dark">
          + Add product
        </Link>
      </header>

      <form className="flex max-w-md gap-2">
        <label htmlFor="product-search" className="sr-only">Search products</label>
        <input id="product-search" name="q" defaultValue={term} placeholder="Search by name or slug" className="min-w-0 flex-1 rounded-full border border-sand bg-white px-4 py-2.5 text-sm" />
        <button type="submit" className="rounded-full border border-sand bg-white px-4 py-2.5 text-sm font-semibold text-ink">Search</button>
      </form>

      <div className="overflow-x-auto rounded-2xl border border-sand bg-white shadow-soft">
        <table className="w-full min-w-[720px] text-left text-[13px]">
          <thead className="border-b border-sand bg-shell/60 text-[11px] uppercase tracking-wider text-ink-soft">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Stock</th>
              <th className="px-4 py-3">Tags</th>
              <th className="px-4 py-3"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-sand">
            {rows.map((product) => (
              <tr key={product.id}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={product.images[0]} alt="" className="h-10 w-10 rounded-lg object-cover" loading="lazy" />
                    <span className="font-medium text-ink">{product.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-ink-soft">{product.categorySlug}</td>
                <td className="px-4 py-3 font-semibold text-ink">{formatINR(product.price)}</td>
                <td className={`px-4 py-3 font-semibold ${product.stock < 20 ? "text-[#a8520a]" : "text-ink"}`}>{product.stock}</td>
                <td className="px-4 py-3 text-[11px] text-ink-soft">
                  {[product.isFeatured && "Featured", product.isBestseller && "Bestseller", product.isNew && "New"].filter(Boolean).join(" · ") || "—"}
                </td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/products/${product.id}`} className="font-semibold text-clay hover:underline">Edit</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
