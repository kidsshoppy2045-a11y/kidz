import Link from "next/link";
import { ProductForm } from "@/components/admin/product-form";
import { Notice } from "@/components/admin/form-fields";
import { getCategories } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function NewProduct({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  const categories = await getCategories();
  return (
    <div className="space-y-6">
      <Link href="/admin/products" className="text-[13px] font-semibold text-clay hover:underline">← Products</Link>
      <h1 className="font-display text-3xl text-ink">Add product</h1>
      <Notice error={error} />
      <ProductForm categories={categories} />
    </div>
  );
}
