import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ProductForm } from "@/components/admin/product-form";
import { Notice } from "@/components/admin/form-fields";
import { getCategories } from "@/lib/data";
import { deleteProduct } from "../../../actions";

export const dynamic = "force-dynamic";

export default async function EditProduct({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; saved?: string }>;
}) {
  const { id } = await params;
  const { error, saved } = await searchParams;
  const [product] = await db.select().from(products).where(eq(products.id, Number(id) || 0));
  if (!product) notFound();
  const categories = await getCategories();

  return (
    <div className="space-y-6">
      <Link href="/admin/products" className="text-[13px] font-semibold text-clay hover:underline">← Products</Link>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-3xl text-ink">{product.name}</h1>
        <Link href={`/product/${product.slug}`} className="text-[13px] font-semibold text-clay hover:underline">View in store ↗</Link>
      </div>
      <Notice error={error} saved={saved} />
      <ProductForm product={product} categories={categories} />
      <form action={deleteProduct} className="border-t border-sand pt-6">
        <input type="hidden" name="id" value={product.id} />
        <button type="submit" className="rounded-full border border-brand-pink px-5 py-2.5 text-[13px] font-semibold text-brand-pink hover:bg-brand-pink hover:text-white">
          Delete product and its reviews
        </button>
      </form>
    </div>
  );
}
