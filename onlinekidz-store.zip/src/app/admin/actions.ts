"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { blogPosts, orders, products, reviews, subscribers } from "@/db/schema";
import {
  adminConfigured,
  endSession,
  passwordMatches,
  requireAdmin,
  startSession,
} from "@/lib/admin-auth";
import { ORDER_STATUSES, textToBlocks } from "@/lib/admin-content";

const str = (form: FormData, key: string) => String(form.get(key) ?? "").trim();
const num = (form: FormData, key: string, fallback = 0) => {
  const value = Number(form.get(key));
  return Number.isFinite(value) ? Math.round(value) : fallback;
};
const lines = (form: FormData, key: string) =>
  str(form, key).split("\n").map((line) => line.trim()).filter(Boolean);
const bool = (form: FormData, key: string) => form.get(key) === "on";
const slugify = (value: string) =>
  value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 140);

function refresh() {
  revalidatePath("/", "layout");
}

// ── Auth ─────────────────────────────────────────────────────────────────
export async function login(form: FormData) {
  if (!adminConfigured() || !passwordMatches(str(form, "password"))) {
    redirect("/admin/login?error=1");
  }
  await startSession();
  redirect("/admin");
}

export async function logout() {
  await endSession();
  redirect("/admin/login");
}

// ── Orders ───────────────────────────────────────────────────────────────
export async function updateOrderStatus(form: FormData) {
  await requireAdmin();
  const status = str(form, "status");
  if (!(ORDER_STATUSES as readonly string[]).includes(status)) return;
  await db.update(orders).set({ status }).where(eq(orders.id, num(form, "id")));
  refresh();
}

// ── Products ─────────────────────────────────────────────────────────────
export async function saveProduct(form: FormData) {
  await requireAdmin();
  const id = num(form, "id");
  const name = str(form, "name");
  const slug = slugify(str(form, "slug") || name);
  const price = num(form, "price");
  const compareAt = num(form, "compareAtPrice");
  const images = lines(form, "images");
  const back = id ? `/admin/products/${id}` : "/admin/products/new";

  if (!name || !slug || price <= 0 || images.length === 0) {
    redirect(`${back}?error=${encodeURIComponent("Name, price and at least one image URL are required.")}`);
  }

  const values = {
    name,
    slug,
    categorySlug: str(form, "categorySlug"),
    brand: str(form, "brand") || "OnlineKidz",
    tagline: str(form, "tagline"),
    description: str(form, "description"),
    price,
    compareAtPrice: compareAt > price ? compareAt : null,
    stock: Math.max(0, num(form, "stock")),
    ageMonthsMin: Math.max(0, num(form, "ageMonthsMin")),
    ageMonthsMax: Math.max(1, num(form, "ageMonthsMax", 144)),
    badge: str(form, "badge") || null,
    unitLabel: str(form, "unitLabel"),
    images,
    highlights: lines(form, "highlights"),
    details: lines(form, "details")
      .map((line) => {
        const [label, ...rest] = line.split(":");
        return { label: label.trim(), value: rest.join(":").trim() };
      })
      .filter((detail) => detail.label && detail.value),
    isFeatured: bool(form, "isFeatured"),
    isBestseller: bool(form, "isBestseller"),
    isNew: bool(form, "isNew"),
  };

  let error = "";
  let savedId = id;
  try {
    if (id) {
      const [existing] = await db.select({ slug: products.slug }).from(products).where(eq(products.id, id));
      await db.update(products).set(values).where(eq(products.id, id));
      if (existing && existing.slug !== slug) {
        await db.update(reviews).set({ productSlug: slug }).where(eq(reviews.productSlug, existing.slug));
      }
    } else {
      const [created] = await db.insert(products).values(values).returning({ id: products.id });
      savedId = created.id;
    }
  } catch {
    error = "That URL slug is already used by another product.";
  }
  if (error) redirect(`${back}?error=${encodeURIComponent(error)}`);
  refresh();
  redirect(`/admin/products/${savedId}?saved=1`);
}

export async function deleteProduct(form: FormData) {
  await requireAdmin();
  const [product] = await db.select({ slug: products.slug }).from(products).where(eq(products.id, num(form, "id")));
  if (product) {
    await db.delete(reviews).where(eq(reviews.productSlug, product.slug));
    await db.delete(products).where(eq(products.slug, product.slug));
  }
  refresh();
  redirect("/admin/products");
}

// ── Reviews ──────────────────────────────────────────────────────────────
export async function toggleReviewVerified(form: FormData) {
  await requireAdmin();
  await db
    .update(reviews)
    .set({ verified: str(form, "verified") !== "true" })
    .where(eq(reviews.id, num(form, "id")));
  refresh();
}

export async function deleteReview(form: FormData) {
  await requireAdmin();
  await db.delete(reviews).where(eq(reviews.id, num(form, "id")));
  refresh();
}

// ── Journal ──────────────────────────────────────────────────────────────
export async function savePost(form: FormData) {
  await requireAdmin();
  const id = num(form, "id");
  const title = str(form, "title");
  const slug = slugify(str(form, "slug") || title);
  const content = textToBlocks(str(form, "content"));
  const back = id ? `/admin/journal/${id}` : "/admin/journal/new";

  if (!title || !slug || content.length === 0) {
    redirect(`${back}?error=${encodeURIComponent("Title and article content are required.")}`);
  }

  const values = {
    title,
    slug,
    excerpt: str(form, "excerpt"),
    category: str(form, "category") || "Parenting",
    author: str(form, "author") || "OnlineKidz team",
    readingMinutes: Math.max(1, num(form, "readingMinutes", 5)),
    heroImage: str(form, "heroImage") || "/images/hero.jpg",
    featured: bool(form, "featured"),
    sponsored: bool(form, "sponsored"),
    sources: lines(form, "sources")
      .map((line) => {
        const [label, url] = line.split("|").map((part) => part.trim());
        return { label: label || url, url: url || label };
      })
      .filter((source) => /^https?:\/\//.test(source.url)),
    content,
  };

  let error = "";
  let savedId = id;
  try {
    if (id) {
      await db.update(blogPosts).set({ ...values, updatedAt: new Date() }).where(eq(blogPosts.id, id));
    } else {
      const [created] = await db.insert(blogPosts).values(values).returning({ id: blogPosts.id });
      savedId = created.id;
    }
  } catch {
    error = "That URL slug is already used by another article.";
  }
  if (error) redirect(`${back}?error=${encodeURIComponent(error)}`);
  refresh();
  redirect(`/admin/journal/${savedId}?saved=1`);
}

export async function deletePost(form: FormData) {
  await requireAdmin();
  await db.delete(blogPosts).where(eq(blogPosts.id, num(form, "id")));
  refresh();
  redirect("/admin/journal");
}

// ── Subscribers ──────────────────────────────────────────────────────────
export async function deleteSubscriber(form: FormData) {
  await requireAdmin();
  await db.delete(subscribers).where(eq(subscribers.id, num(form, "id")));
  refresh();
}
