import type { Metadata } from "next";
import Link from "next/link";
import { Reveal } from "@/components/reveal";
import { ArrowRightIcon, CheckIcon, LeafIcon, ShieldIcon, SparkIcon } from "@/components/icons";
import { getProducts } from "@/lib/data";
import { formatINR } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Our story",
  description:
    "How OnlineKidz.Store started in a Coorg kitchen with one jar of sprouted ragi — and why we read every label so you don't have to.",
};

const FAQS = [
  {
    q: "Are your millet mixes safe for a 6-month-old?",
    a: "Our sprouted ragi porridge is a single-ingredient food recommended from 6 months, once your paediatrician has cleared solids. The seven-millet health mix is better from 12 months because of the nuts. Every product page lists the exact age window.",
  },
  {
    q: "How fresh is the stock you ship?",
    a: "Millet mixes are stone-milled weekly in batches of 40 kg or less. Nothing sits in a warehouse longer than ten days, and each pouch carries its milling date on the back.",
  },
  {
    q: "Do you test for heavy metals?",
    a: "Yes. Every quarter we send samples from three different batches to an NABL-accredited lab for lead, arsenic, cadmium and mercury screening. Reports are available on request.",
  },
  {
    q: "What if my baby doesn't like it?",
    a: "Unopened packs can be returned within 30 days for a full refund. If a pack is opened, message us anyway — nine times out of ten we'll find something that works and swap it.",
  },
  {
    q: "Is cash on delivery available?",
    a: "Yes, on every pin code we serve, with no extra charge. UPI, cards and net banking are all encrypted through our payment partner.",
  },
];

export default async function AboutPage() {
  const foods = await getProducts({ category: "organic-foods", sort: "popular", limit: 3 });

  return (
    <div className="pb-20">
      <section className="border-b border-sand bg-shell/60">
        <div className="mx-auto grid max-w-[1400px] items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:px-10 lg:py-20">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-clay/25 bg-white/70 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-clay">
              <SparkIcon width={13} height={13} /> Est. 2019 · Coorg, Karnataka
            </span>
            <h1 className="mt-5 font-display text-[36px] leading-[1.06] text-ink sm:text-[52px]">
              It started with one jar of ragi and a lot of frustration
            </h1>
            <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-ink-soft">
              In 2019, Ammu — a grandmother of four in Coorg — was milling sprouted ragi for her
              granddaughter because nothing on the shelf was good enough. Neighbours asked for jars.
              Then their sisters did. Six years later we work with 14 artisan families across Karnataka,
              Tamil Nadu and Rajasthan, and we still roast the millets in the same brass vessels.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/shop"
                className="inline-flex items-center gap-2 rounded-full bg-clay px-6 py-3.5 text-sm font-semibold text-cream transition hover:bg-clay-dark"
              >
                Shop the collection <ArrowRightIcon width={16} height={16} />
              </Link>
              <Link
                href="/collections/organic-foods"
                className="inline-flex items-center gap-2 rounded-full border border-ink/15 px-6 py-3.5 text-sm font-semibold text-ink transition hover:border-clay hover:text-clay"
              >
                Meet the millets
              </Link>
            </div>
          </div>
          <div className="relative animate-fade-in">
            <div className="overflow-hidden rounded-[2rem] border border-white/70 shadow-lift">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/story-kitchen.jpg"
                alt="Roasting millets in a brass vessel"
                className="h-[320px] w-full object-cover sm:h-[460px]"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              icon: LeafIcon,
              title: "We read every label",
              body: "If a product has an ingredient we wouldn't feed our own children, it doesn't go on the shelf. That rule has rejected roughly 4 in 10 brands we evaluate.",
            },
            {
              icon: ShieldIcon,
              title: "We publish the boring details",
              body: "Milling dates, lab reports, sourcing villages and allergen warnings are all on the product page. No proprietary blends hiding behind marketing.",
            },
            {
              icon: SparkIcon,
              title: "We keep it affordable",
              body: "Working directly with farmer groups and artisan collectives means no distributor margin — and prices that stay honest for a monthly basket.",
            },
          ].map((item, index) => (
            <Reveal key={item.title} delay={index * 80}>
              <div className="h-full rounded-3xl border border-sand bg-white p-6 shadow-soft">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-shell text-clay">
                  <item.icon width={20} height={20} />
                </span>
                <h2 className="mt-4 font-display text-xl text-ink">{item.title}</h2>
                <p className="mt-2 text-[14px] leading-relaxed text-ink-soft">{item.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="feeding" className="scroll-mt-28 bg-shell/60 py-16">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              Feeding guide
            </p>
            <h2 className="mt-2 font-display text-[30px] leading-tight text-ink sm:text-[40px]">
              What to introduce, and when
            </h2>
            <p className="mt-3 text-[15.5px] leading-relaxed text-ink-soft">
              A quick timeline our paediatric nutritionist put together. Always check with your own
              doctor first — every baby is different.
            </p>
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { age: "6 months", title: "Single grains", body: "Sprouted ragi porridge, thin and runny at first. One new food every 4 days." },
              { age: "8 months", title: "Soft khichdi", body: "Rice and moong dal with a spoon of ghee. Mash rather than purée to build chewing." },
              { age: "12 months", title: "Family food", body: "Millet health mixes, dry fruit ladoos, soft rusks. Watch out for whole nuts." },
              { age: "24 months+", title: "Real snacks", body: "Multigrain chikki, fruit purée cups and everything off your own plate." },
            ].map((stage, index) => (
              <Reveal key={stage.age} delay={index * 70}>
                <div className="h-full rounded-3xl border border-sand bg-white p-5 shadow-soft">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-clay">
                    {stage.age}
                  </p>
                  <h3 className="mt-1.5 font-display text-lg text-ink">{stage.title}</h3>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-ink-soft">{stage.body}</p>
                </div>
              </Reveal>
            ))}
          </div>

          {foods.length > 0 ? (
            <div className="mt-8 flex flex-wrap items-center gap-4 rounded-3xl border border-sand bg-white p-6 shadow-soft">
              <div className="flex flex-1 flex-wrap gap-3">
                {foods.map((food) => (
                  <Link
                    key={food.slug}
                    href={`/product/${food.slug}`}
                    className="flex items-center gap-3 rounded-2xl border border-sand p-2.5 transition hover:border-clay"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={food.images[0]}
                      alt={food.name}
                      className="h-12 w-12 rounded-xl object-cover"
                      loading="lazy"
                    />
                    <span className="pr-2">
                      <span className="block max-w-[180px] truncate text-[13px] font-semibold text-ink">
                        {food.name}
                      </span>
                      <span className="block text-[12px] text-clay">{formatINR(food.price)}</span>
                    </span>
                  </Link>
                ))}
              </div>
              <Link
                href="/collections/organic-foods"
                className="rounded-full bg-clay px-6 py-3 text-sm font-semibold text-white transition hover:bg-clay-dark"
              >
                Shop the millet shelf
              </Link>
            </div>
          ) : null}
        </div>
      </section>

      <section id="shipping" className="mx-auto max-w-[1400px] scroll-mt-28 px-4 py-16 sm:px-6 lg:px-10">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              title: "Shipping",
              body: "Orders leave Coorg within 24 hours on working days. Metro cities get deliveries in 2 days, the rest of India in 3–5. Free above ₹999, flat ₹79 below that.",
            },
            {
              title: "Returns",
              body: "Unopened packs can go back within 30 days for a full refund — we arrange the reverse pickup. Opened food packs can't be resold, so message us and we'll find a swap.",
            },
            {
              title: "Cold-chain & summer",
              body: "Ghee-based ladoos can soften in transit during April and June. We pack them with insulated liners between March and July at no extra cost.",
            },
          ].map((card, index) => (
            <Reveal key={card.title} delay={index * 80}>
              <div className="h-full rounded-3xl border border-sand bg-white p-6 shadow-soft">
                <h2 className="font-display text-xl text-ink">{card.title}</h2>
                <p className="mt-2 text-[14px] leading-relaxed text-ink-soft">{card.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-3xl scroll-mt-28 px-4 sm:px-6">
        <Reveal className="text-center">
          <h2 className="font-display text-[30px] text-ink sm:text-[40px]">Questions parents ask</h2>
        </Reveal>
        <div className="mt-8 space-y-3">
          {FAQS.map((faq, index) => (
            <Reveal key={faq.q} delay={index * 50}>
              <details className="group rounded-2xl border border-sand bg-white p-5 shadow-soft">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4">
                  <span className="text-[15px] font-semibold text-ink">{faq.q}</span>
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-shell text-clay transition-transform duration-300 group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-[14px] leading-relaxed text-ink-soft">{faq.a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="contact" className="mx-auto mt-16 max-w-[1400px] scroll-mt-28 px-4 sm:px-6 lg:px-10">
        <Reveal className="overflow-hidden rounded-[2rem] border border-sand bg-gradient-to-br from-ink to-clay-dark px-7 py-10 text-cream sm:px-12">
          <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
            <div>
              <h2 className="font-display text-[28px] leading-tight sm:text-[36px]">
                Talk to a real person
              </h2>
              <p className="mt-3 max-w-lg text-[15px] leading-relaxed text-cream/80">
                Our parent-support team is three mothers who work school hours. Message us and you&apos;ll
                hear back the same day — usually within a couple of hours.
              </p>
              <ul className="mt-6 space-y-2.5 text-[14px]">
                {[
                  "WhatsApp +91 98450 11223 · 9am to 7pm IST",
                  "hello@onlinekids.store",
                  "Ammiji's Kitchen, Madikeri, Coorg 571201",
                ].map((line) => (
                  <li key={line} className="flex items-start gap-2.5">
                    <span className="mt-0.5 text-saffron">
                      <CheckIcon width={15} height={15} />
                    </span>
                    {line}
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex items-center justify-center">
              <Link
                href="/shop"
                className="inline-flex items-center gap-2 rounded-full bg-cream px-7 py-3.5 text-sm font-semibold text-ink transition hover:bg-saffron"
              >
                Start shopping <ArrowRightIcon width={16} height={16} />
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
