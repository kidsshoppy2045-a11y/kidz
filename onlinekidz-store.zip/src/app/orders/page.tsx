import type { Metadata } from "next";
import Link from "next/link";
import { CheckIcon, TruckIcon } from "@/components/icons";
import { getOrderByNumber } from "@/lib/data";
import { formatDate, formatINR } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Track your order",
  description: "Look up the status of your OnlineKidz.Store order.",
};

type SearchParams = Promise<{ q?: string }>;

const STAGES = [
  { id: "confirmed", label: "Order confirmed", body: "We have your order" },
  { id: "packed", label: "Packed in Coorg", body: "Freshly milled & sealed" },
  { id: "shipped", label: "Handed to courier", body: "On the move" },
  { id: "delivered", label: "Delivered", body: "Enjoy!" },
];

export default async function OrdersPage({ searchParams }: { searchParams: SearchParams }) {
  const { q } = await searchParams;
  const order = q ? await getOrderByNumber(q) : null;

  return (
    <div className="mx-auto max-w-3xl px-4 pb-20 pt-12 sm:px-6">
      <header className="text-center">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">Order desk</p>
        <h1 className="mt-2 font-display text-[32px] text-ink sm:text-[42px]">Track your order</h1>
        <p className="mx-auto mt-3 max-w-lg text-[15px] leading-relaxed text-ink-soft">
          Enter the order number from your confirmation email — it looks like{" "}
          <span className="font-mono text-[13px] text-ink">OKS-XXXXXX12</span>.
        </p>
      </header>

      <form
        method="get"
        className="mx-auto mt-7 flex max-w-md flex-col gap-2 sm:flex-row"
      >
        <input
          name="q"
          defaultValue={q ?? ""}
          placeholder="OKS-ABC12345"
          className="min-w-0 flex-1 rounded-full border border-sand bg-white px-5 py-3.5 text-[14.5px] outline-none transition focus:border-clay"
        />
        <button
          type="submit"
          className="rounded-full bg-clay px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-clay-dark"
        >
          Find order
        </button>
      </form>

      {q && !order ? (
        <div className="mt-10 rounded-3xl border border-dashed border-sand bg-white/70 px-6 py-12 text-center">
          <span className="text-4xl">🔍</span>
          <p className="mt-4 font-display text-xl text-ink">No order matches “{q}”</p>
          <p className="mx-auto mt-2 max-w-sm text-[14px] text-ink-soft">
            Try the demo order flow — add something to your basket and check out, then come back with
            the number.
          </p>
          <Link
            href="/shop"
            className="mt-6 inline-block rounded-full bg-clay px-6 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark"
          >
            Browse the shop
          </Link>
        </div>
      ) : null}

      {order ? (
        <div className="mt-10 overflow-hidden rounded-[2rem] border border-sand bg-white shadow-lift">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-sand bg-shell/50 px-6 py-5">
            <div>
              <p className="font-mono text-[13px] text-ink-soft">{order.orderNumber}</p>
              <p className="mt-1 font-display text-2xl text-ink">
                {formatINR(order.total)} · {order.items.length} item
                {order.items.length > 1 ? "s" : ""}
              </p>
              <p className="mt-0.5 text-[12.5px] text-ink-soft">
                Placed {formatDate(order.createdAt)} · {order.city}
              </p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-sage/15 px-3 py-1.5 text-[11.5px] font-semibold uppercase tracking-wider text-teal">
              <CheckIcon width={13} height={13} /> {order.status}
            </span>
          </div>

          <ol className="grid gap-4 px-6 py-7 sm:grid-cols-4">
            {STAGES.map((stage, index) => (
              <li key={stage.id} className="relative">
                <div className="flex items-center gap-2">
                  <span
                    className={`flex h-7 w-7 items-center justify-center rounded-full text-[11px] font-bold ${
                      index === 0
                        ? "bg-sage text-white"
                        : index === 1
                          ? "bg-saffron/30 text-ink"
                          : "bg-sand text-ink-soft/60"
                    }`}
                  >
                    {index === 0 ? <CheckIcon width={13} height={13} /> : index + 1}
                  </span>
                  {index < STAGES.length - 1 ? (
                    <span className="hidden h-px flex-1 bg-sand sm:block" />
                  ) : null}
                </div>
                <p className="mt-2 text-[13px] font-semibold text-ink">{stage.label}</p>
                <p className="text-[11.5px] text-ink-soft/80">{stage.body}</p>
              </li>
            ))}
          </ol>

          <div className="border-t border-sand px-6 py-6">
            <p className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-soft/75">
              <TruckIcon width={15} height={15} className="text-teal" /> Shipping to
            </p>
            <p className="mt-2 text-[14px] text-ink">
              {order.customerName}, {order.address1}
              {order.address2 ? `, ${order.address2}` : ""}, {order.city}, {order.state}{" "}
              {order.pincode}
            </p>
            <Link
              href="/shop"
              className="mt-5 inline-block rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:border-clay hover:text-clay"
            >
              Order these again
            </Link>
          </div>
        </div>
      ) : null}
    </div>
  );
}
