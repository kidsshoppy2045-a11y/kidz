"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { useCart } from "@/components/cart-context";
import { trackEvent } from "@/lib/analytics";
import { ArrowRightIcon, CheckIcon, MinusIcon, PlusIcon, ShieldIcon, TruckIcon } from "@/components/icons";
import { COUPONS, FREE_SHIPPING_THRESHOLD, formatINR } from "@/lib/format";

type Form = {
  email: string;
  name: string;
  phone: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  pincode: string;
  notes: string;
  payment: "upi" | "card" | "cod" | "netbanking";
  express: boolean;
};

const STATES = [
  "Karnataka", "Tamil Nadu", "Kerala", "Maharashtra", "Delhi", "Telangana",
  "Gujarat", "West Bengal", "Rajasthan", "Uttar Pradesh", "Punjab", "Haryana",
];

const STEPS = ["Contact", "Delivery", "Payment"];

export default function CheckoutPage() {
  const { items, subtotal, discount, shipping, total, coupon, applyCoupon, removeCoupon, updateQuantity, clearCart, hydrated } =
    useCart();
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [code, setCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const submitLock = useRef(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<Form>({
    email: "",
    name: "",
    phone: "",
    address1: "",
    address2: "",
    city: "",
    state: "Karnataka",
    pincode: "",
    notes: "",
    payment: "upi",
    express: false,
  });

  const set = <K extends keyof Form>(key: K, value: Form[K]) =>
    setForm((current) => ({ ...current, [key]: value }));
  const checkoutTracked = useRef(false);

  useEffect(() => {
    if (!hydrated || items.length === 0 || checkoutTracked.current) return;
    checkoutTracked.current = true;
    trackEvent("checkout_start", undefined, {
      cart_count: items.reduce((sum, item) => sum + item.quantity, 0),
      cart_value: subtotal,
    });
  }, [hydrated, items, subtotal]);

  const expressFee = form.express ? 149 : 0;
  const grandTotal = total + expressFee;

  const stepValid = useMemo(() => {
    if (step === 0) {
      return form.email.includes("@") && form.name.trim().length > 1 && /^\d{10}$/.test(form.phone.replace(/\D/g, "").slice(-10));
    }
    if (step === 1) {
      return (
        form.address1.trim().length > 4 &&
        form.city.trim().length > 1 &&
        form.state.trim().length > 1 &&
        /^\d{6}$/.test(form.pincode)
      );
    }
    return true;
  }, [step, form]);

  const placeOrder = async () => {
    if (submitLock.current) return;
    submitLock.current = true;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: {
            customerName: form.name,
            email: form.email,
            phone: form.phone,
            address1: form.address1,
            address2: form.address2,
            city: form.city,
            state: form.state,
            pincode: form.pincode,
            notes: form.notes,
            paymentMethod: form.payment,
            couponCode: coupon,
          },
          items: items.map((item) => ({
            slug: item.slug,
            name: item.name,
            image: item.image,
            price: item.price,
            quantity: item.quantity,
            variant: item.variant,
          })),
          express: form.express,
        }),
      });
      if (!response.ok) throw new Error("Order failed");
      const data = (await response.json()) as { orderNumber: string };
      trackEvent("purchase_complete", undefined, {
        cart_count: items.reduce((sum, item) => sum + item.quantity, 0),
        cart_value: grandTotal,
        payment_method: form.payment,
        express: form.express,
      });
      clearCart();
      router.push(`/checkout/success?order=${data.orderNumber}`);
    } catch {
      trackEvent("checkout_error", undefined, {
        step,
        payment_method: form.payment,
      });
      setError("We couldn't place that order. Please try again in a moment.");
      submitLock.current = false;
      setSubmitting(false);
    }
  };

  if (hydrated && items.length === 0) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-24 text-center">
        <span className="text-5xl">🧺</span>
        <h1 className="mt-5 font-display text-3xl text-ink">Your basket is empty</h1>
        <p className="mt-2 text-[15px] text-ink-soft">
          Add a jar of sprouted ragi or a soft pair of first walkers and come right back.
        </p>
        <Link
          href="/shop"
          className="mt-7 inline-flex items-center gap-2 rounded-full bg-clay px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-clay-dark"
        >
          Start shopping <ArrowRightIcon width={16} height={16} />
        </Link>
      </div>
    );
  }

  const field =
    "w-full rounded-xl border border-sand bg-white px-4 py-3 text-[14.5px] outline-none transition focus:border-clay";
  const label = "block text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-soft/75";

  return (
    <div className="mx-auto max-w-[1200px] px-4 pb-20 pt-10 sm:px-6 lg:px-10">
      <header className="text-center">
        <h1 className="font-display text-[32px] text-ink sm:text-[40px]">Checkout</h1>
        <p className="mt-2 text-[14.5px] text-ink-soft">
          Secure checkout · UPI, cards, net banking & cash on delivery
        </p>
      </header>

      <ol className="mx-auto mt-7 flex max-w-lg items-center justify-between gap-2">
        {STEPS.map((name, index) => (
          <li key={name} className="flex flex-1 items-center gap-2">
            <button
              type="button"
              onClick={() => index < step && setStep(index)}
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[12.5px] font-bold transition ${
                index < step
                  ? "bg-sage text-white"
                  : index === step
                    ? "bg-ink text-cream"
                    : "bg-sand text-ink-soft/60"
              }`}
            >
              {index < step ? <CheckIcon width={14} height={14} /> : index + 1}
            </button>
            <span
              className={`text-[12.5px] font-semibold ${index <= step ? "text-ink" : "text-ink-soft/50"}`}
            >
              {name}
            </span>
            {index < STEPS.length - 1 ? (
              <span
                className={`h-px flex-1 transition-colors ${index < step ? "bg-sage" : "bg-sand"}`}
              />
            ) : null}
          </li>
        ))}
      </ol>

      <div className="mt-9 grid gap-8 lg:grid-cols-[1fr_390px] lg:gap-12">
        <div className="rounded-3xl border border-sand bg-white p-6 shadow-soft sm:p-8">
          {step === 0 ? (
            <div className="animate-fade-up space-y-5">
              <h2 className="font-display text-2xl text-ink">Who are we shipping to?</h2>
              <div>
                <label className={label} htmlFor="email">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(event) => set("email", event.target.value)}
                  placeholder="you@email.com"
                  className={`mt-1.5 ${field}`}
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className={label} htmlFor="name">
                    Full name
                  </label>
                  <input
                    id="name"
                    value={form.name}
                    onChange={(event) => set("name", event.target.value)}
                    placeholder="Ananya Iyer"
                    className={`mt-1.5 ${field}`}
                  />
                </div>
                <div>
                  <label className={label} htmlFor="phone">
                    Mobile number
                  </label>
                  <input
                    id="phone"
                    inputMode="numeric"
                    value={form.phone}
                    onChange={(event) => set("phone", event.target.value)}
                    placeholder="98765 43210"
                    className={`mt-1.5 ${field}`}
                  />
                </div>
              </div>
              <p className="rounded-2xl bg-shell/70 p-4 text-[13px] leading-relaxed text-ink-soft">
                We&apos;ll send your invoice and tracking link here. No marketing unless you ask for
                it — we promise.
              </p>
            </div>
          ) : null}

          {step === 1 ? (
            <div className="animate-fade-up space-y-5">
              <h2 className="font-display text-2xl text-ink">Delivery address</h2>
              <div>
                <label className={label} htmlFor="address1">
                  Flat, house no., building
                </label>
                <input
                  id="address1"
                  value={form.address1}
                  onChange={(event) => set("address1", event.target.value)}
                  placeholder="12/A, Brindavan Layout"
                  className={`mt-1.5 ${field}`}
                />
              </div>
              <div>
                <label className={label} htmlFor="address2">
                  Area, landmark (optional)
                </label>
                <input
                  id="address2"
                  value={form.address2}
                  onChange={(event) => set("address2", event.target.value)}
                  placeholder="Near Sarjapur Lake"
                  className={`mt-1.5 ${field}`}
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <label className={label} htmlFor="city">
                    City
                  </label>
                  <input
                    id="city"
                    value={form.city}
                    onChange={(event) => set("city", event.target.value)}
                    placeholder="Bengaluru"
                    className={`mt-1.5 ${field}`}
                  />
                </div>
                <div>
                  <label className={label} htmlFor="state">
                    State
                  </label>
                  <select
                    id="state"
                    value={form.state}
                    onChange={(event) => set("state", event.target.value)}
                    className={`mt-1.5 ${field}`}
                  >
                    {STATES.map((state) => (
                      <option key={state}>{state}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={label} htmlFor="pincode">
                    Pincode
                  </label>
                  <input
                    id="pincode"
                    inputMode="numeric"
                    maxLength={6}
                    value={form.pincode}
                    onChange={(event) => set("pincode", event.target.value)}
                    placeholder="560102"
                    className={`mt-1.5 ${field}`}
                  />
                </div>
              </div>

              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => set("express", false)}
                  className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition ${
                    !form.express ? "border-clay bg-clay/5" : "border-sand"
                  }`}
                >
                  <span className="mt-0.5 text-clay">
                    <TruckIcon width={18} height={18} />
                  </span>
                  <span className="flex-1">
                    <span className="block text-[14px] font-semibold text-ink">
                      Standard delivery · Free
                    </span>
                    <span className="block text-[12.5px] text-ink-soft">
                      Arrives in 2–5 working days across India
                    </span>
                  </span>
                  {!form.express ? (
                    <span className="text-clay">
                      <CheckIcon width={17} height={17} />
                    </span>
                  ) : null}
                </button>
                <button
                  type="button"
                  onClick={() => set("express", true)}
                  className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition ${
                    form.express ? "border-clay bg-clay/5" : "border-sand"
                  }`}
                >
                  <span className="mt-0.5 text-clay">
                    <TruckIcon width={18} height={18} />
                  </span>
                  <span className="flex-1">
                    <span className="block text-[14px] font-semibold text-ink">
                      Express delivery · {formatINR(149)}
                    </span>
                    <span className="block text-[12.5px] text-ink-soft">
                      Dispatched today, delivered in 1–2 days
                    </span>
                  </span>
                  {form.express ? (
                    <span className="text-clay">
                      <CheckIcon width={17} height={17} />
                    </span>
                  ) : null}
                </button>
              </div>

              <div>
                <label className={label} htmlFor="notes">
                  Delivery notes (optional)
                </label>
                <textarea
                  id="notes"
                  rows={3}
                  value={form.notes}
                  onChange={(event) => set("notes", event.target.value)}
                  placeholder="Leave with the guard if we're out. Baby naps 2–4pm."
                  className={`mt-1.5 ${field}`}
                />
              </div>
            </div>
          ) : null}

          {step === 2 ? (
            <div className="animate-fade-up space-y-5">
              <h2 className="font-display text-2xl text-ink">How would you like to pay?</h2>
              <div className="space-y-2.5">
                {[
                  { id: "upi", title: "UPI", body: "GPay, PhonePe, Paytm — instant confirmation", icon: "▣" },
                  { id: "card", title: "Credit / debit card", body: "Visa, Mastercard, RuPay, Amex", icon: "▤" },
                  { id: "netbanking", title: "Net banking", body: "58 banks supported", icon: "▥" },
                  { id: "cod", title: "Cash on delivery", body: "Pay the courier, ₹0 extra", icon: "▦" },
                ].map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => set("payment", option.id as Form["payment"])}
                    className={`flex w-full items-center gap-3 rounded-2xl border p-4 text-left transition ${
                      form.payment === option.id ? "border-clay bg-clay/5" : "border-sand"
                    }`}
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-shell text-clay">
                      {option.icon}
                    </span>
                    <span className="flex-1">
                      <span className="block text-[14px] font-semibold text-ink">{option.title}</span>
                      <span className="block text-[12.5px] text-ink-soft">{option.body}</span>
                    </span>
                    {form.payment === option.id ? (
                      <span className="text-clay">
                        <CheckIcon width={17} height={17} />
                      </span>
                    ) : null}
                  </button>
                ))}
              </div>

              {form.payment === "card" ? (
                <div className="grid gap-3 rounded-2xl bg-shell/60 p-4 sm:grid-cols-[1fr_100px_90px]">
                  <input placeholder="Card number" className={field} />
                  <input placeholder="MM / YY" className={field} />
                  <input placeholder="CVV" className={field} />
                </div>
              ) : null}

              <div className="rounded-2xl border border-sand p-4">
                <p className="text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-soft/75">
                  Review
                </p>
                <div className="mt-2 space-y-1 text-[13.5px] text-ink-soft">
                  <p className="text-ink">{form.name}</p>
                  <p>
                    {form.address1}
                    {form.address2 ? `, ${form.address2}` : ""}
                  </p>
                  <p>
                    {form.city}, {form.state} {form.pincode}
                  </p>
                  <p>
                    {form.email} · {form.phone}
                  </p>
                </div>
              </div>
            </div>
          ) : null}

          {error ? <p className="mt-4 text-[13.5px] font-medium text-clay">{error}</p> : null}

          <div className="mt-8 flex flex-wrap items-center gap-3 border-t border-sand pt-6">
            {step > 0 ? (
              <button
                type="button"
                onClick={() => setStep((s) => s - 1)}
                className="rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:bg-shell"
              >
                Back
              </button>
            ) : (
              <Link
                href="/shop"
                className="rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:bg-shell"
              >
                Keep shopping
              </Link>
            )}
            {step < 2 ? (
              <button
                type="button"
                disabled={!stepValid}
                onClick={() => setStep((s) => s + 1)}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-clay px-7 py-3.5 text-sm font-semibold text-cream transition-all duration-300 hover:bg-clay-dark disabled:cursor-not-allowed disabled:opacity-45 sm:flex-none"
              >
                Continue to {STEPS[step + 1]} <ArrowRightIcon width={16} height={16} />
              </button>
            ) : (
              <button
                type="button"
                disabled={submitting}
                onClick={placeOrder}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-clay px-7 py-3.5 text-sm font-semibold text-white transition-all duration-300 hover:bg-clay-dark disabled:opacity-60"
              >
                {submitting ? "Placing order…" : `Pay ${formatINR(grandTotal)}`}
                {!submitting ? <ArrowRightIcon width={16} height={16} /> : null}
              </button>
            )}
          </div>
        </div>

        {/* Summary */}
        <aside className="lg:sticky lg:top-32 lg:self-start">
          <div className="rounded-3xl border border-sand bg-white p-6 shadow-soft">
            <h2 className="font-display text-xl text-ink">Order summary</h2>
            <ul className="mt-4 space-y-3">
              {items.map((item) => {
                const id = `${item.slug}::${item.variant ?? ""}`;
                return (
                  <li key={id} className="flex gap-3">
                    <span className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-shell">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                      <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-ink px-1 text-[10px] font-bold text-cream">
                        {item.quantity}
                      </span>
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="line-clamp-2 text-[13px] font-medium leading-snug text-ink">
                        {item.name}
                      </span>
                      {item.variant ? (
                        <span className="block text-[11.5px] text-ink-soft/75">{item.variant}</span>
                      ) : null}
                      <span className="mt-1 flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.slug, item.quantity - 1, item.variant)}
                          className="flex h-5 w-5 items-center justify-center rounded-full border border-sand text-ink-soft transition hover:bg-shell"
                          aria-label="Decrease"
                        >
                          <MinusIcon width={10} height={10} />
                        </button>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.slug, item.quantity + 1, item.variant)}
                          className="flex h-5 w-5 items-center justify-center rounded-full border border-sand text-ink-soft transition hover:bg-shell"
                          aria-label="Increase"
                        >
                          <PlusIcon width={10} height={10} />
                        </button>
                      </span>
                    </span>
                    <span className="text-[13.5px] font-semibold text-ink">
                      {formatINR(item.price * item.quantity)}
                    </span>
                  </li>
                );
              })}
            </ul>

            <div className="mt-5 border-t border-sand pt-4">
              {coupon ? (
                <div className="flex items-center justify-between rounded-xl bg-sage/12 px-3 py-2 text-[12.5px] text-teal">
                  <span className="inline-flex items-center gap-1.5 font-medium">
                    <CheckIcon width={13} height={13} /> {coupon}
                  </span>
                  <button type="button" onClick={removeCoupon} className="underline">
                    remove
                  </button>
                </div>
              ) : (
                <form
                  className="flex gap-2"
                  onSubmit={(event) => {
                    event.preventDefault();
                    if (applyCoupon(code)) setCode("");
                  }}
                >
                  <input
                    value={code}
                    onChange={(event) => setCode(event.target.value)}
                    placeholder="Coupon code"
                    className="min-w-0 flex-1 rounded-xl border border-sand bg-cream px-3 py-2.5 text-[13px] outline-none focus:border-clay"
                  />
                  <button
                    type="submit"
                    className="rounded-xl border border-ink/15 px-3.5 py-2.5 text-[13px] font-semibold text-ink transition hover:bg-shell"
                  >
                    Apply
                  </button>
                </form>
              )}
              <p className="mt-2 text-[11.5px] text-ink-soft/75">
                Try {Object.keys(COUPONS).join(" or ")}
                {subtotal < FREE_SHIPPING_THRESHOLD
                  ? ` · add ${formatINR(FREE_SHIPPING_THRESHOLD - subtotal)} for free delivery`
                  : " · free delivery applied"}
              </p>
            </div>

            <dl className="mt-4 space-y-2 border-t border-sand pt-4 text-[13.5px]">
              <div className="flex justify-between text-ink-soft">
                <dt>Subtotal</dt>
                <dd className="font-medium text-ink">{formatINR(subtotal)}</dd>
              </div>
              {discount > 0 ? (
                <div className="flex justify-between text-teal">
                  <dt>Coupon discount</dt>
                  <dd>-{formatINR(discount)}</dd>
                </div>
              ) : null}
              <div className="flex justify-between text-ink-soft">
                <dt>Delivery</dt>
                <dd className="font-medium text-ink">{shipping === 0 ? "Free" : formatINR(shipping)}</dd>
              </div>
              {expressFee > 0 ? (
                <div className="flex justify-between text-ink-soft">
                  <dt>Express handling</dt>
                  <dd className="font-medium text-ink">{formatINR(expressFee)}</dd>
                </div>
              ) : null}
              <div className="flex items-baseline justify-between border-t border-sand pt-3 font-display text-xl text-ink">
                <dt>Total</dt>
                <dd>{formatINR(grandTotal)}</dd>
              </div>
            </dl>

            <div className="mt-4 flex items-center gap-2 rounded-2xl bg-shell/70 p-3 text-[12px] text-ink-soft">
              <ShieldIcon width={16} height={16} className="text-teal" />
              256-bit encrypted payments · Free 30-day returns on unopened packs
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
