import type { Metadata } from "next";
import Link from "next/link";
import { CheckIcon, ShieldIcon, TruckIcon } from "@/components/icons";
import { getOrderByNumber } from "@/lib/data";
import { formatINR } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Order confirmed",
  description: "Your OnlineKidz.Store order is confirmed.",
};

type SearchParams = Promise<{ order?: string }>;

export default async function CheckoutSuccessPage({ searchParams }: { searchParams: SearchParams }) {
  const { order: orderNumber } = await searchParams;
  const order = orderNumber ? await getOrderByNumber(orderNumber) : null;

  if (!order) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-24 text-center">
        <span className="text-5xl">📦</span>
        <h1 className="mt-5 font-display text-3xl text-ink">We couldn&apos;t find that order</h1>
        <p className="mt-2 text-[15px] text-ink-soft">
          Double-check the order number in your confirmation email, or look it up below.
        </p>
        <Link
          href="/orders"
          className="mt-7 rounded-full bg-clay px-7 py-3.5 text-sm font-semibold text-cream transition hover:bg-clay-dark"
        >
          Track an order
        </Link>
      </div>
    );
  }

  const eta = new Date(order.createdAt.getTime() + 4 * 86400000);
  const etaLabel = new Intl.DateTimeFormat("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(eta);

  return (
    <div className="mx-auto max-w-3xl px-4 pb-20 pt-12 sm:px-6">
      <div className="overflow-hidden rounded-[2rem] border border-sand bg-white shadow-lift">
        <div className="relative bg-gradient-to-br from-sage/25 via-shell to-clay/15 px-7 py-10 text-center">
          <span className="mx-auto flex h-16 w-16 animate-pop items-center justify-center rounded-full bg-sage text-white shadow-soft">
            <CheckIcon width={30} height={30} />
          </span>
          <h1 className="mt-5 font-display text-[30px] leading-tight text-ink sm:text-[38px]">
            Thank you, {order.customerName.split(" ")[0]}!
          </h1>
          <p className="mx-auto mt-2 max-w-md text-[15px] leading-relaxed text-ink-soft">
            Your order is confirmed and already being packed in Coorg. A confirmation is on its way to{" "}
            <strong className="font-semibold text-ink">{order.email}</strong>.
          </p>
          <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-sand bg-white/80 px-4 py-2 text-[13px] font-semibold text-ink backdrop-blur">
            Order {order.orderNumber}
          </p>
        </div>

        <div className="grid gap-6 border-t border-sand p-7 sm:grid-cols-2">
          <div>
            <p className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-soft/75">
              <TruckIcon width={15} height={15} className="text-teal" /> Arriving by
            </p>
            <p className="mt-2 font-display text-xl text-ink">{etaLabel}</p>
            <p className="mt-1 text-[13px] text-ink-soft">
              {order.address1}
              {order.address2 ? `, ${order.address2}` : ""}, {order.city}, {order.state}{" "}
              {order.pincode}
            </p>
          </div>
          <div>
            <p className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-soft/75">
              <ShieldIcon width={15} height={15} className="text-teal" /> Payment
            </p>
            <p className="mt-2 font-display text-xl capitalize text-ink">
              {order.paymentMethod === "cod" ? "Cash on delivery" : order.paymentMethod}
            </p>
            <p className="mt-1 text-[13px] text-ink-soft">{formatINR(order.total)} paid</p>
          </div>
        </div>

        <div className="border-t border-sand p-7">
          <p className="text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-soft/75">
            {order.items.length} item{order.items.length > 1 ? "s" : ""}
          </p>
          <ul className="mt-4 space-y-3">
            {order.items.map((item) => (
              <li key={`${item.slug}-${item.variant ?? ""}`} className="flex items-center gap-3">
                <Link
                  href={`/product/${item.slug}`}
                  className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-shell"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                </Link>
                <span className="min-w-0 flex-1">
                  <Link
                    href={`/product/${item.slug}`}
                    className="line-clamp-1 text-[13.5px] font-medium text-ink hover:text-clay"
                  >
                    {item.name}
                  </Link>
                  <span className="block text-[12px] text-ink-soft/80">
                    {item.variant ? `${item.variant} · ` : ""}Qty {item.quantity}
                  </span>
                </span>
                <span className="text-[13.5px] font-semibold text-ink">
                  {formatINR(item.price * item.quantity)}
                </span>
              </li>
            ))}
          </ul>

          <dl className="mt-5 space-y-2 border-t border-sand pt-4 text-[13.5px]">
            <div className="flex justify-between text-ink-soft">
              <dt>Subtotal</dt>
              <dd className="font-medium text-ink">{formatINR(order.subtotal)}</dd>
            </div>
            {order.discount > 0 ? (
              <div className="flex justify-between text-teal">
                <dt>Discount {order.couponCode ? `(${order.couponCode})` : ""}</dt>
                <dd>-{formatINR(order.discount)}</dd>
              </div>
            ) : null}
            <div className="flex justify-between text-ink-soft">
              <dt>Delivery</dt>
              <dd className="font-medium text-ink">
                {order.shipping === 0 ? "Free" : formatINR(order.shipping)}
              </dd>
            </div>
            <div className="flex items-baseline justify-between border-t border-sand pt-3 font-display text-xl text-ink">
              <dt>Total</dt>
              <dd>{formatINR(order.total)}</dd>
            </div>
          </dl>
        </div>

        <div className="flex flex-wrap gap-3 border-t border-sand bg-shell/50 px-7 py-6">
          <Link
            href="/shop"
            className="rounded-full bg-clay px-6 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark"
          >
            Continue shopping
          </Link>
          <Link
            href={`/orders?q=${order.orderNumber}`}
            className="rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:border-clay hover:text-clay"
          >
            Track this order
          </Link>
        </div>
      </div>
    </div>
  );
}
