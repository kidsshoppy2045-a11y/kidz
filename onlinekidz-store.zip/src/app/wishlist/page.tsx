import type { Metadata } from "next";
import { WishlistContent } from "@/components/wishlist-content";

export const metadata: Metadata = {
  title: "Your wishlist",
  description: "Save trusted baby, kids and mother-care essentials for later.",
};

export default function WishlistPage() {
  return <WishlistContent />;
}
