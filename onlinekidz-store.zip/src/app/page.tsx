import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import { BlogCard } from "@/components/blog-card";
import { HeroCta } from "@/components/hero-cta";
import { HomeSearch } from "@/components/home-search";
import { RecentlyViewed } from "@/components/recently-viewed";
import { TrackedLink } from "@/components/tracked-link";
import { Reveal } from "@/components/reveal";
import { Stars } from "@/components/stars";
import { VideoTestimonials } from "@/components/video-testimonials";
import {
  ArrowRightIcon,
  CheckIcon,
  LeafIcon,
  ShieldIcon,
  SparkIcon,
  TruckIcon,
} from "@/components/icons";
import { AGE_BANDS, getCategories, getProducts } from "@/lib/data";
import { getBlogPosts } from "@/lib/blog-data";
import { formatINR } from "@/lib/format";

export const dynamic = "force-dynamic";

const STATS = [
  { value: "7", label: "Thoughtful collections" },
  { value: "35+", label: "Curated product picks" },
  { value: "10%", label: "First order with LITTLE10" },
  { value: "0", label: "Added preservatives in pantry mixes" },
];

const PROMISES = [
  {
    icon: LeafIcon,
    title: "Milled the week we ship",
    body: "Our millets are sprouted, roasted and stone-ground in micro-batches — never stored for months.",
  },
  {
    icon: ShieldIcon,
    title: "Paediatrician reviewed",
    body: "Every formula is checked by a practising paediatric nutritionist before it reaches the shop.",
  },
  {
    icon: TruckIcon,
    title: "Free delivery over ₹999",
    body: "Dispatched within 24 hours from Coorg, delivered across India in 2–5 days.",
  },
];

export default async function HomePage() {
  const [categories, featured, bestsellers, newArrivals, foods, articles] = await Promise.all([
    getCategories(),
    getProducts({ sort: "featured", limit: 8 }),
    getProducts({ tag: "bestsellers", sort: "popular", limit: 8 }),
    getProducts({ tag: "new", sort: "popular", limit: 4 }),
    getProducts({ category: "organic-foods", limit: 4 }),
    getBlogPosts(4),
  ]);

  const hero = foods[0];
  const shelf = (featured.length >= 6 ? featured : bestsellers).slice(0, 8);

  return (
    <>
      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-gradient-to-b from-shell/80 via-cream to-cream">
        <div className="pointer-events-none absolute -left-24 top-10 h-72 w-72 rounded-full bg-saffron/20 blur-3xl" />
        <div className="pointer-events-none absolute -right-16 bottom-0 h-80 w-80 rounded-full bg-clay/15 blur-3xl" />
        <div className="relative mx-auto grid max-w-[1400px] items-center gap-10 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:gap-14 lg:px-10 lg:pb-24 lg:pt-16">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-clay/25 bg-white/70 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-clay backdrop-blur">
              <SparkIcon width={13} height={13} /> Homemade in India · Since 2019
            </span>
            <h1 className="mt-5 font-display text-[40px] leading-[1.04] text-ink sm:text-[56px] lg:text-[66px]">
              Everything little ones need,
              <span className="relative ml-2 inline-block">
                <span className="relative z-10 italic text-clay">honestly made</span>
                <svg
                  className="absolute -bottom-1 left-0 z-0 w-full text-saffron/50"
                  viewBox="0 0 200 12"
                  fill="none"
                  aria-hidden
                >
                  <path
                    d="M2 8c40-6 80-6 120-2s56 4 76-2"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </h1>
            <p className="mt-6 max-w-xl text-[16px] leading-relaxed text-ink-soft sm:text-[17px]">
              Sprouted ragi porridges, cold-pressed massage oils, rash-free diapers, hand-block printed
              cotton and heirloom wooden toys — one trusted shop for families with children aged 0–12,
              and for the mothers doing the hard part.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <HeroCta />
              <TrackedLink
                href="/collections/organic-foods"
                eventName="category_click"
                metadata={{ placement: "home-hero", category: "organic-foods" }}
                className="inline-flex items-center gap-2 rounded-full border border-ink/15 bg-white/70 px-6 py-3.5 text-[15px] font-semibold text-ink backdrop-blur transition hover:border-clay hover:text-clay"
              >
                Explore millet mixes
              </TrackedLink>
            </div>
            <div className="mt-5 inline-flex flex-wrap items-center gap-2 rounded-full border border-saffron/35 bg-saffron/10 px-3.5 py-2 text-[11px] text-ink">
              <span aria-hidden>✦</span>
              <strong className="font-bold">First order?</strong> Take 10% off with code LITTLE10
            </div>
            <HomeSearch />
            <div className="mt-9 flex items-center gap-4">
              <div className="flex -space-x-2.5">
                {["#e39c2b", "#c2603f", "#7c9a80", "#8e3b5b", "#2f6f6a"].map((color, index) => (
                  <span
                    key={color}
                    className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-cream text-[11px] font-bold text-white"
                    style={{ background: color }}
                  >
                    {["A", "M", "D", "K", "P"][index]}
                  </span>
                ))}
              </div>
              <div>
                <Stars rating={4.8} size={15} />
                <p className="mt-0.5 text-[13px] text-ink-soft">
                  <strong className="font-semibold text-ink">4.8 out of 5</strong> average catalog rating
                  · Parent notes on product pages
                </p>
              </div>
            </div>
          </div>

          <div className="relative animate-fade-in">
            <div className="relative overflow-hidden rounded-[2rem] border border-white/60 shadow-lift">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/hero.jpg"
                alt="Mother holding her baby in a sunlit Indian home"
                className="h-[380px] w-full object-cover sm:h-[480px] lg:h-[560px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/25 via-transparent to-transparent" />
            </div>

            {hero ? (
              <TrackedLink
                href={`/product/${hero.slug}`}
                eventName="product_click"
                productSlug={hero.slug}
                metadata={{ placement: "home-hero-featured" }}
                className="absolute -bottom-6 left-2 flex w-[260px] items-center gap-3 rounded-2xl border border-sand bg-white/95 p-3 shadow-lift backdrop-blur transition hover:-translate-y-1 sm:left-6"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={hero.images[0]}
                  alt={hero.name}
                  className="h-14 w-14 rounded-xl object-cover"
                />
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-semibold text-ink">
                    {hero.name}
                  </span>
                  <span className="block text-[12px] text-clay">{formatINR(hero.price)}</span>
                  <span className="mt-0.5 flex items-center gap-1 text-[10px] uppercase tracking-wider text-teal">
                    <CheckIcon width={11} height={11} /> Bestseller
                  </span>
                </span>
              </TrackedLink>
            ) : null}

            <div className="absolute -right-2 top-6 hidden w-[190px] rounded-2xl border border-sand bg-white/95 p-3.5 shadow-lift backdrop-blur sm:block lg:-right-8">
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-sage/20 text-teal">
                  <LeafIcon width={16} height={16} />
                </span>
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-soft">
                  Small batch
                </p>
              </div>
              <p className="mt-2 text-[12px] leading-relaxed text-ink-soft">
                Millets roasted in brass vessels by the same three women who started it all.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats ────────────────────────────────────────────────────────── */}
      <section className="border-y border-sand bg-white/70">
        <div className="mx-auto grid max-w-[1400px] grid-cols-2 divide-sand px-4 py-8 sm:px-6 md:grid-cols-4 md:divide-x lg:px-10">
          {STATS.map((stat) => (
            <div key={stat.label} className="px-2 text-center">
              <p className="font-display text-[28px] text-ink sm:text-[34px]">{stat.value}</p>
              <p className="mt-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-soft/70">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Collections ──────────────────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10 lg:py-20">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              Shop by collection
            </p>
            <h2 className="mt-2 max-w-xl font-display text-[30px] leading-tight text-ink sm:text-[40px]">
              Seven aisles, all of them trustworthy
            </h2>
          </div>
          <TrackedLink
            href="/shop"
            eventName="cta_click"
            metadata={{ placement: "home-collections", cta_label: "View everything" }}
            className="group inline-flex items-center gap-2 text-sm font-semibold text-ink transition hover:text-clay"
          >
            View everything
            <ArrowRightIcon
              width={16}
              height={16}
              className="transition-transform duration-300 group-hover:translate-x-1"
            />
          </TrackedLink>
        </Reveal>

        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((category, index) => (
            <Reveal
              key={category.slug}
              delay={index * 60}
              className={index === 0 ? "sm:col-span-2 lg:row-span-2" : ""}
            >
              <TrackedLink
                href={`/collections/${category.slug}`}
                eventName="category_click"
                metadata={{ placement: "home-collection-grid", category: category.slug }}
                className={`group relative flex h-full flex-col justify-end overflow-hidden rounded-3xl border border-sand/70 bg-shell shadow-soft transition-all duration-500 hover:shadow-lift ${
                  index === 0 ? "min-h-[280px] lg:min-h-[420px]" : "min-h-[200px]"
                }`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={category.image}
                  alt={category.name}
                  loading={index < 3 ? "eager" : "lazy"}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.08]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/25 to-transparent" />
                <div className="relative p-5">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-cream/70">
                    {category.tagline}
                  </p>
                  <h3
                    className={`mt-1.5 font-display text-cream ${
                      index === 0 ? "text-[26px] sm:text-[32px]" : "text-[20px]"
                    }`}
                  >
                    {category.name}
                  </h3>
                  {index === 0 ? (
                    <p className="mt-2 max-w-sm text-[13px] leading-relaxed text-cream/85">
                      {category.description}
                    </p>
                  ) : null}
                  <span className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-[0.12em] text-saffron">
                    Shop now
                    <ArrowRightIcon
                      width={14}
                      height={14}
                      className="transition-transform duration-300 group-hover:translate-x-1"
                    />
                  </span>
                </div>
              </TrackedLink>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── Bestsellers ──────────────────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6 lg:px-10 lg:pb-20">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              Loved by parents
            </p>
            <h2 className="mt-2 font-display text-[30px] leading-tight text-ink sm:text-[40px]">
              This month&apos;s bestsellers
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            <TrackedLink
              href="/shop?tag=bestsellers"
              eventName="cta_click"
              metadata={{ placement: "home-bestsellers", cta_label: "All bestsellers" }}
              className="rounded-full border border-ink/15 bg-white px-4 py-2 text-[13px] font-medium text-ink transition hover:border-clay hover:text-clay"
            >
              All bestsellers
            </TrackedLink>
            <TrackedLink
              href="/shop?sort=rating"
              eventName="cta_click"
              metadata={{ placement: "home-bestsellers", cta_label: "Top rated" }}
              className="rounded-full border border-ink/15 bg-white px-4 py-2 text-[13px] font-medium text-ink transition hover:border-clay hover:text-clay"
            >
              Top rated
            </TrackedLink>
          </div>
        </Reveal>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {shelf.map((product, index) => (
            <Reveal key={product.slug} delay={(index % 4) * 60}>
              <ProductCard product={product} priority={index < 4} />
            </Reveal>
          ))}
        </div>
      </section>

      {newArrivals.length > 0 ? (
        <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6 lg:px-10 lg:pb-20">
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">Fresh on the shelf</p>
              <h2 className="mt-2 font-display text-[30px] leading-tight text-ink sm:text-[40px]">New arrivals</h2>
              <p className="mt-2 text-[14px] text-ink-soft">Thoughtful new finds for little ones and the people who love them.</p>
            </div>
            <TrackedLink
              href="/shop?tag=new"
              eventName="cta_click"
              metadata={{ placement: "home-new-arrivals", cta_label: "View new arrivals" }}
              className="group inline-flex items-center gap-2 text-sm font-semibold text-ink transition hover:text-clay"
            >
              View all new arrivals
              <ArrowRightIcon width={16} height={16} className="transition-transform duration-300 group-hover:translate-x-1" />
            </TrackedLink>
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {newArrivals.map((product, index) => (
              <Reveal key={product.slug} delay={index * 60}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </section>
      ) : null}

      <RecentlyViewed />

      {/* ── Millet story ─────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-shell/60 py-16 lg:py-24">
        <div className="mx-auto grid max-w-[1400px] items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-10">
          <Reveal className="relative">
            <div className="overflow-hidden rounded-[2rem] border border-white/70 shadow-lift">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/story-kitchen.jpg"
                alt="Millets being slow roasted in a brass vessel"
                loading="lazy"
                className="h-[320px] w-full object-cover sm:h-[440px] lg:h-[520px]"
              />
            </div>
            <div className="absolute bottom-5 right-5 rounded-2xl border border-sand bg-white/95 p-4 shadow-lift backdrop-blur">
              <p className="font-display text-2xl text-clay">6 hrs</p>
              <p className="mt-0.5 max-w-[9rem] text-[11px] leading-snug text-ink-soft">
                from sprouting to stone-milling, never longer
              </p>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              Why the millet matters
            </p>
            <h2 className="mt-2 font-display text-[30px] leading-tight text-ink sm:text-[42px]">
              Ancient grains, made modern enough for a two-year-old
            </h2>
            <p className="mt-5 text-[15.5px] leading-relaxed text-ink-soft">
              We started in a Coorg kitchen with one problem: everything labelled &ldquo;baby
              food&rdquo; had sugar hiding in it. So we went back to what our grandmothers already
              knew — sprouted ragi, foxtail millet, jaggery and patience. Nothing is fortifed in a
              lab, because nothing needs to be.
            </p>
            <ul className="mt-7 space-y-3.5">
              {[
                "Sprouted for 24 hours so minerals are actually absorbed",
                "Slow-roasted in brass vessels to bring out the nutty aroma",
                "Stone-milled weekly — every pouch carries its milling date",
                "Independently lab-tested for heavy metals every quarter",
              ].map((point) => (
                <li key={point} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-sage/20 text-teal">
                    <CheckIcon width={12} height={12} />
                  </span>
                  <span className="text-[14.5px] leading-relaxed text-ink-soft">{point}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/collections/organic-foods"
                className="inline-flex items-center gap-2 rounded-full bg-clay px-6 py-3 text-sm font-semibold text-white transition hover:bg-clay-dark"
              >
                Shop the millet shelf <ArrowRightIcon width={16} height={16} />
              </Link>
              <Link
                href="/about"
                className="inline-flex items-center gap-2 rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold text-ink transition hover:border-clay hover:text-clay"
              >
                Read our story
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Shop by age ──────────────────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10 lg:py-20">
        <Reveal className="text-center">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
            Right thing, right stage
          </p>
          <h2 className="mx-auto mt-2 max-w-2xl font-display text-[30px] leading-tight text-ink sm:text-[40px]">
            Shop by your child&apos;s age
          </h2>
        </Reveal>
        <div className="mt-9 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {AGE_BANDS.map((band, index) => (
            <Reveal key={band.id} delay={index * 70}>
              <Link
                href={`/shop?age=${band.id}`}
                className="group flex h-full flex-col justify-between rounded-3xl border border-sand bg-white p-5 shadow-soft transition-all duration-400 hover:-translate-y-1.5 hover:border-clay/40 hover:shadow-lift"
              >
                <span className="text-3xl">{["🍼", "🥣", "🧸", "🎨", "👟"][index]}</span>
                <span className="mt-5">
                  <span className="block font-display text-lg text-ink">{band.label}</span>
                  <span className="mt-1.5 block text-[12.5px] leading-relaxed text-ink-soft/85">
                    {
                      [
                        "Feeding, swaddles and newborn diapers",
                        "First porridges, teethers and soft soles",
                        "Wooden toys, pants and toddler foods",
                        "Puzzles, crayons and play-school shoes",
                        "School sneakers, kurtas and lunchbox snacks",
                      ][index]
                    }
                  </span>
                  <span className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-clay">
                    Shop
                    <ArrowRightIcon
                      width={13}
                      height={13}
                      className="transition-transform duration-300 group-hover:translate-x-1"
                    />
                  </span>
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── Mother care banner ───────────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6 lg:px-10 lg:pb-20">
        <Reveal className="overflow-hidden rounded-[2rem] border border-sand bg-gradient-to-br from-ink via-[#0a4f96] to-clay-dark text-cream">
          <div className="grid items-center gap-8 p-8 sm:p-12 lg:grid-cols-[1.15fr_1fr] lg:p-14">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-cream/25 px-3 py-1.5 text-[10.5px] font-semibold uppercase tracking-[0.18em] text-saffron">
                <SparkIcon width={13} height={13} /> The fourth trimester
              </span>
              <h2 className="mt-4 font-display text-[30px] leading-tight sm:text-[40px]">
                Mothers are on the menu too
              </h2>
              <p className="mt-4 max-w-lg text-[15.5px] leading-relaxed text-cream/80">
                Lactation ladoos with fenugreek and gond, caffeine-free postnatal teas, iron-rich
                prenatal mixes and a belly butter that actually absorbs. Made with the same
                stubbornness as everything else in the shop.
              </p>
              <Link
                href="/collections/mother-care"
                className="group mt-7 inline-flex items-center gap-2 rounded-full bg-cream px-6 py-3 text-sm font-semibold text-ink transition hover:bg-saffron"
              >
                Shop mother care
                <ArrowRightIcon
                  width={16}
                  height={16}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/products/mother-care.jpg"
                alt="Mother care products"
                loading="lazy"
                className="col-span-2 h-44 w-full rounded-2xl object-cover shadow-lift sm:h-52"
              />
            </div>
          </div>
        </Reveal>
      </section>

      {/* ── Video testimonials ───────────────────────────────────────────── */}
      <VideoTestimonials />

      {/* ── Journal ──────────────────────────────────────────────────────── */}
      {articles.length > 0 ? (
        <section className="border-y border-sand bg-shell/55 py-16 lg:py-20">
          <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
            <Reveal className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
                  The OnlineKidz journal
                </p>
                <h2 className="mt-2 max-w-2xl font-display text-[30px] leading-tight text-ink sm:text-[40px]">
                  Thoughtful answers for the little questions
                </h2>
                <p className="mt-2 max-w-xl text-[14px] leading-relaxed text-ink-soft">
                  Feeding notes, gentle care guides and play ideas from people who live the parent life.
                </p>
              </div>
              <Link
                href="/blog"
                className="group inline-flex items-center gap-2 text-sm font-semibold text-ink transition hover:text-clay"
              >
                Visit the journal
                <ArrowRightIcon width={16} height={16} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </Reveal>
            <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {articles.slice(0, 3).map((post, index) => (
                <Reveal key={post.slug} delay={index * 70}>
                  <BlogCard post={post} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      ) : null}

      {/* ── Promises ─────────────────────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 pb-20 sm:px-6 lg:px-10">
        <div className="grid gap-4 md:grid-cols-3">
          {PROMISES.map((promise, index) => (
            <Reveal key={promise.title} delay={index * 80}>
              <div className="flex h-full gap-4 rounded-3xl border border-sand bg-white p-6 shadow-soft">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-shell text-clay">
                  <promise.icon width={20} height={20} />
                </span>
                <div>
                  <h3 className="font-display text-lg text-ink">{promise.title}</h3>
                  <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-soft/90">
                    {promise.body}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
