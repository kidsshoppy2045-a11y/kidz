import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { BlogCard } from "@/components/blog-card";
import { JournalAnalytics } from "@/components/journal-analytics";
import { JournalNewsletter } from "@/components/journal-newsletter";
import { ProductCard } from "@/components/product-card";
import { TrackedLink } from "@/components/tracked-link";
import { getBlogPost, getBlogPosts } from "@/lib/blog-data";
import { getProducts } from "@/lib/data";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

const SHOP_CATEGORY: Record<string, string> = {
  "Feeding & weaning": "organic-foods",
  Recipes: "organic-foods",
  "Baby care": "baby-care",
  "Clothing & comfort": "clothes",
  "Play & development": "toys",
  "Mother care": "mother-care",
};

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const post = await getBlogPost(slug);
  if (!post) return { title: "Article not found" };
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `https://onlinekids.store/blog/${post.slug}` },
    openGraph: {
      type: "article",
      title: post.title,
      description: post.excerpt,
      images: [post.heroImage],
      publishedTime: post.publishedAt.toISOString(),
      modifiedTime: (post.updatedAt ?? post.publishedAt).toISOString(),
      authors: [post.author],
    },
  };
}

export default async function BlogArticlePage({ params }: { params: Params }) {
  const { slug } = await params;
  const post = await getBlogPost(slug);
  if (!post) notFound();

  const [allPosts, relatedProducts] = await Promise.all([
    getBlogPosts(8),
    getProducts({ category: SHOP_CATEGORY[post.category] ?? "organic-foods", sort: "popular", limit: 3 }),
  ]);
  const moreReads = allPosts.filter((item) => item.slug !== post.slug).slice(0, 3);
  const modifiedAt = post.updatedAt ?? post.publishedAt;
  const articleStructuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    image: post.heroImage,
    datePublished: post.publishedAt.toISOString(),
    dateModified: modifiedAt.toISOString(),
    author: { "@type": "Person", name: post.author },
    publisher: { "@type": "Organization", name: "OnlineKidz.Store", url: "https://onlinekids.store" },
    articleSection: post.category,
    citation: post.sources.map((source) => source.url),
    mainEntityOfPage: `https://onlinekids.store/blog/${post.slug}`,
  };
  const breadcrumbStructuredData = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: "https://onlinekids.store/" },
      { "@type": "ListItem", position: 2, name: "Journal", item: "https://onlinekids.store/blog" },
      { "@type": "ListItem", position: 3, name: post.category, item: `https://onlinekids.store/blog?category=${encodeURIComponent(post.category)}` },
      { "@type": "ListItem", position: 4, name: post.title, item: `https://onlinekids.store/blog/${post.slug}` },
    ],
  };

  return (
    <article className="pb-20">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleStructuredData).replace(/</g, "\\u003c") }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbStructuredData).replace(/</g, "\\u003c") }}
      />
      <JournalAnalytics articleSlug={post.slug} />
      <header className="border-b border-sand bg-shell/60">
        <div className="mx-auto max-w-[1100px] px-4 py-9 sm:px-6 lg:px-10">
          <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-2 text-[12px] text-ink-soft/70">
            <Link href="/" className="transition hover:text-clay">Home</Link>
            <span aria-hidden>/</span>
            <Link href="/blog" className="transition hover:text-clay">Journal</Link>
            <span aria-hidden>/</span>
            <TrackedLink
              href={`/blog?category=${encodeURIComponent(post.category)}`}
              eventName="category_click"
              metadata={{ placement: "article-breadcrumb", category: post.category }}
              className="transition hover:text-clay"
            >
              {post.category}
            </TrackedLink>
            <span aria-hidden>/</span>
            <span aria-current="page" className="max-w-[220px] truncate text-ink">{post.title}</span>
          </nav>
          <div className="mx-auto mt-8 max-w-3xl text-center animate-fade-up">
            <Link
              href={`/blog?category=${encodeURIComponent(post.category)}`}
              className="inline-flex rounded-full border border-clay/25 bg-white/70 px-3.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.17em] text-clay"
            >
              {post.category}
            </Link>
            <h1 className="mt-4 font-display text-[34px] leading-[1.08] text-ink sm:text-[48px]">
              {post.title}
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-soft">
              {post.excerpt}
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-[12px] text-ink-soft/75">
              <span className="font-semibold text-ink">{post.author}</span>
              <span>·</span>
              <span>Published {formatDate(post.publishedAt)}</span>
              {post.updatedAt && post.updatedAt.getTime() > post.publishedAt.getTime() ? (
                <>
                  <span>·</span>
                  <span>Updated {formatDate(post.updatedAt)}</span>
                </>
              ) : null}
              <span>·</span>
              <span>{post.readingMinutes} min read</span>
            </div>
            {post.sponsored ? (
              <p className="mx-auto mt-3 inline-flex rounded-full border border-sand bg-white/70 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-soft">
                Sponsored content
              </p>
            ) : null}
          </div>
          <div className="mx-auto mt-8 max-w-5xl overflow-hidden rounded-[2rem] border border-white/70 shadow-lift">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={post.heroImage}
              alt={post.title}
              className="h-[260px] w-full object-cover sm:h-[390px] lg:h-[480px]"
            />
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1100px] gap-10 px-4 pt-10 sm:px-6 lg:grid-cols-[minmax(0,720px)_260px] lg:gap-14 lg:px-10">
        <div className="min-w-0">
          <div className="prose-kids space-y-5">
            {post.content.map((block, index) => {
              if (block.type === "heading") {
                return (
                  <h2 key={index} className="pt-3 font-display text-[25px] leading-snug text-ink sm:text-[29px]">
                    {block.text}
                  </h2>
                );
              }
              if (block.type === "list") {
                return (
                  <ul key={index} className="space-y-3 rounded-3xl border border-sand bg-white p-5 shadow-soft">
                    {(block.items ?? []).map((item) => (
                      <li key={item} className="flex items-start gap-3 text-[15px] leading-relaxed text-ink-soft">
                        <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-clay" />
                        {item}
                      </li>
                    ))}
                  </ul>
                );
              }
              if (block.type === "tip") {
                return (
                  <aside key={index} className="rounded-2xl border-l-4 border-saffron bg-shell/70 p-5 text-[14.5px] leading-relaxed text-ink-soft">
                    <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-clay">A gentle reminder</p>
                    {block.text}
                  </aside>
                );
              }
              return (
                <p key={index} className="text-[15.5px] leading-[1.85] text-ink-soft">
                  {block.text}
                </p>
              );
            })}
          </div>

          <div className="mt-10 rounded-2xl border border-sand bg-shell/50 p-5 text-[12.5px] leading-relaxed text-ink-soft">
            Our journal is for general information and family inspiration. It is not medical advice or
            a substitute for care from your child&apos;s doctor. Always follow current guidance from your
            healthcare professional.
          </div>

          {post.sources.length > 0 ? (
            <section aria-labelledby="article-sources-title" className="mt-6 rounded-2xl border border-sand bg-white p-5">
              <h2 id="article-sources-title" className="text-[11px] font-bold uppercase tracking-[0.15em] text-ink-soft/75">
                Sources & further reading
              </h2>
              <ul className="mt-3 space-y-2">
                {post.sources.map((source) => (
                  <li key={source.url}>
                    <a href={source.url} target="_blank" rel="noreferrer" className="text-[13px] font-medium text-clay underline underline-offset-2 hover:text-ink">
                      {source.label} <span aria-hidden>↗</span>
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          <div className="mt-10">
            <JournalNewsletter />
          </div>

          {relatedProducts.length > 0 ? (
            <section className="mt-12">
              <div className="mb-5 flex items-end justify-between gap-3">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-clay">Thoughtful picks</p>
                  <h2 className="mt-1 font-display text-2xl text-ink">Explore this shelf</h2>
                </div>
                <Link href={`/collections/${SHOP_CATEGORY[post.category] ?? "organic-foods"}`} className="text-[12px] font-semibold text-clay hover:text-ink">
                  Browse all →
                </Link>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {relatedProducts.map((product) => (
                  <ProductCard key={product.slug} product={product} compact />
                ))}
              </div>
            </section>
          ) : null}
        </div>

        <aside className="space-y-6 lg:sticky lg:top-32 lg:self-start">
          <div className="rounded-3xl border border-sand bg-white p-5 shadow-soft">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-clay">Contributor</p>
            <div className="mt-3 flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-shell font-display text-sm text-clay">
                {post.author.trim().charAt(0)}
              </span>
              <div>
                <h2 className="text-[13px] font-semibold leading-snug text-ink">{post.author}</h2>
                <p className="mt-1 text-[11.5px] leading-relaxed text-ink-soft">
                  Contributor on {post.category.toLowerCase()} for the OnlineKidz journal.
                </p>
              </div>
            </div>
          </div>
          <div className="rounded-3xl border border-sand bg-white p-5 shadow-soft">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-clay">Keep reading</p>
            <ul className="mt-3 divide-y divide-sand">
              {moreReads.map((item) => (
                <li key={item.slug} className="py-3 first:pt-0 last:pb-0">
                  <TrackedLink
                    href={`/blog/${item.slug}`}
                    eventName="article_click"
                    metadata={{ article_slug: item.slug, placement: "related-article" }}
                    className="text-[13px] font-semibold leading-snug text-ink transition hover:text-clay"
                  >
                    {item.title}
                  </TrackedLink>
                  <p className="mt-1 text-[10.5px] text-ink-soft/70">{item.readingMinutes} min · {item.category}</p>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl bg-gradient-to-br from-ink to-clay-dark p-5 text-cream">
            <p className="font-display text-xl">Find your little one&apos;s next favourite</p>
            <p className="mt-2 text-[13px] leading-relaxed text-cream/75">Explore family-tested picks, chosen with care.</p>
            <Link href="/shop" className="mt-4 inline-flex items-center gap-2 rounded-full bg-cream px-4 py-2.5 text-[12px] font-semibold text-ink transition hover:bg-saffron">
              Browse the shop →
            </Link>
          </div>
        </aside>
      </div>
    </article>
  );
}
