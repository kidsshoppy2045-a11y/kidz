import type { Metadata } from "next";
import Link from "next/link";
import { BlogCard } from "@/components/blog-card";
import { JournalAnalytics } from "@/components/journal-analytics";
import { JournalNewsletter } from "@/components/journal-newsletter";
import { JournalSearch } from "@/components/journal-search";
import { Pagination } from "@/components/pagination";
import { Reveal } from "@/components/reveal";
import { TrackedLink } from "@/components/tracked-link";
import { VideoTestimonials } from "@/components/video-testimonials";
import { getBlogPostCount, getBlogPosts, getPopularBlogPosts, getTrendingBlogCategories } from "@/lib/blog-data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "The OnlineKidz journal | Feeding, care & play guides",
  description:
    "Search practical, expert-informed guides to baby feeding, Indian millets, gentle care, play and postpartum nourishment from OnlineKidz.Store.",
  alternates: { canonical: "https://onlinekids.store/blog" },
  openGraph: {
    title: "The OnlineKidz journal",
    description: "Thoughtful guides for the little questions parents wonder about.",
    type: "website",
  },
};

type SearchParams = Promise<{ category?: string; page?: string; q?: string }>;
const PAGE_SIZE = 4;

function parsePage(value?: string) {
  const parsed = Number(value ?? "1");
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 1;
}

export default async function BlogIndex({ searchParams }: { searchParams: SearchParams }) {
  const { category, page: pageParam, q } = await searchParams;
  const search = q?.trim().slice(0, 100) || undefined;
  const allPosts = await getBlogPosts(100);
  const categories = Array.from(new Set(allPosts.map((post) => post.category)));
  const [totalItems, trendingTopics, popularPosts] = await Promise.all([
    getBlogPostCount(category, search),
    getTrendingBlogCategories(5),
    !category && !search ? getPopularBlogPosts(4) : Promise.resolve([]),
  ]);
  const totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));
  const currentPage = Math.min(parsePage(pageParam), totalPages);
  const posts = await getBlogPosts(PAGE_SIZE, (currentPage - 1) * PAGE_SIZE, category, search, "latest");
  const featured = !category && !search && currentPage === 1
    ? posts.find((post) => post.featured)
    : undefined;
  const discoveryPosts = !category && !search && currentPage === 1
    ? (popularPosts.length > 0 ? popularPosts : allPosts.filter((post) => post.featured))
        .filter((post) => post.slug !== featured?.slug && posts.some((item) => item.slug === post.slug))
        .slice(0, 3)
    : [];
  const discoverySlugs = new Set(discoveryPosts.map((post) => post.slug));
  const latestPosts = posts.filter(
    (post) => post.slug !== featured?.slug && !discoverySlugs.has(post.slug),
  );
  const topicOrder = [...trendingTopics, ...categories.filter((name) => !trendingTopics.includes(name))];

  return (
    <div className="pb-20">
      <JournalAnalytics />
      <section className="relative overflow-hidden border-b border-sand bg-shell/60">
        <div className="pointer-events-none absolute -right-20 top-0 h-72 w-72 rounded-full bg-saffron/20 blur-3xl" />
        <div className="relative mx-auto max-w-[1400px] px-4 py-12 sm:px-6 lg:px-10 lg:py-16">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-[12px] text-ink-soft/70">
            <Link href="/" className="transition hover:text-clay">Home</Link>
            <span aria-hidden>/</span>
            <span aria-current="page" className="text-ink">Journal</span>
          </nav>
          <div className="mt-5 max-w-3xl animate-fade-up">
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              Notes for growing together
            </p>
            <h1 className="mt-2 font-display text-[36px] leading-[1.06] text-ink sm:text-[54px]">
              The little things parents wonder about
            </h1>
            <p className="mt-4 max-w-2xl text-[15.5px] leading-relaxed text-ink-soft">
              Thoughtful, practical guides for first foods, gentle care, Indian family recipes and
              everyday play—written for expecting parents, new mothers and growing families.
            </p>
            <JournalSearch query={search} category={category} />
            <Link href="#topics" className="mt-3 inline-flex text-[12px] font-semibold text-clay underline underline-offset-2 hover:text-ink">
              Explore journal topics
            </Link>
          </div>
          <div id="topics" className="mt-7 scroll-mt-28">
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.17em] text-ink-soft/70">
              {trendingTopics.length > 0 ? "Trending topics" : "Explore topics"}
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              <TrackedLink
                href={search ? `/blog?q=${encodeURIComponent(search)}` : "/blog"}
                eventName="category_click"
                metadata={{ placement: "journal-topic-filter" }}
                className={`shrink-0 rounded-full px-4 py-2 text-[12.5px] font-semibold transition ${
                  !category ? "bg-ink text-cream" : "border border-sand bg-white text-ink hover:border-clay"
                }`}
              >
                All topics
              </TrackedLink>
              {topicOrder.map((name) => {
                const activeParams = new URLSearchParams();
                activeParams.set("category", name);
                if (search) activeParams.set("q", search);
                return (
                  <TrackedLink
                    key={name}
                    href={`/blog?${activeParams.toString()}`}
                    eventName="category_click"
                    metadata={{ placement: "journal-topic-filter", category: name }}
                    className={`shrink-0 rounded-full px-4 py-2 text-[12.5px] font-semibold transition ${
                      category === name
                        ? "bg-ink text-cream"
                        : "border border-sand bg-white text-ink hover:border-clay"
                    }`}
                  >
                    {name}
                  </TrackedLink>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-[1400px] px-4 pt-10 sm:px-6 lg:px-10">
        {featured ? (
          <section aria-labelledby="featured-article-heading">
            <div className="mb-4 flex items-end justify-between gap-3">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-clay">Start here</p>
                <h2 id="featured-article-heading" className="mt-1 font-display text-2xl text-ink">Featured guide</h2>
              </div>
            </div>
            <Reveal><BlogCard post={featured} featured /></Reveal>
          </section>
        ) : null}

        {discoveryPosts.length > 0 ? (
          <section aria-labelledby="popular-articles-heading" className="mt-12">
            <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.17em] text-clay">
                  {popularPosts.length > 0 ? "Based on article-card clicks" : "Selected by our editors"}
                </p>
                <h2 id="popular-articles-heading" className="mt-1 font-display text-2xl text-ink">
                  {popularPosts.length > 0 ? "Popular reads" : "Editor picks"}
                </h2>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {discoveryPosts.map((post, index) => (
                <Reveal key={post.slug} delay={index * 60}><BlogCard post={post} /></Reveal>
              ))}
            </div>
          </section>
        ) : null}

        {totalItems === 0 ? (
          <div className="mt-10 rounded-3xl border border-dashed border-sand bg-white p-12 text-center">
            <h2 className="font-display text-2xl text-ink">No articles found</h2>
            <p className="mt-2 text-[14px] text-ink-soft">Try another phrase or browse all journal notes.</p>
            <Link href="/blog" className="mt-4 inline-block text-sm font-semibold text-clay">Show all notes →</Link>
          </div>
        ) : latestPosts.length > 0 ? (
          <section aria-labelledby="latest-articles-heading" className="mt-12">
            <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.17em] text-clay">
                  {search ? `Search results for “${search}”` : category ?? "Fresh from the journal"}
                </p>
                <h2 id="latest-articles-heading" className="mt-1 font-display text-2xl text-ink">
                  {search ? "Helpful reads" : category ? `${category} guides` : "Latest articles"}
                </h2>
              </div>
              <span className="text-[12.5px] text-ink-soft">
                {totalItems} article{totalItems === 1 ? "" : "s"}
              </span>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {latestPosts.map((post, index) => (
                <Reveal key={post.slug} delay={(index % 3) * 60}><BlogCard post={post} /></Reveal>
              ))}
            </div>
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={totalItems}
              pageSize={PAGE_SIZE}
              pathname="/blog"
              itemLabel="journal articles"
              query={{ category, q: search }}
            />
          </section>
        ) : null}

        <div className="mt-12">
          <JournalNewsletter />
        </div>
        <div className="mt-12">
          <VideoTestimonials />
        </div>

        <aside className="mt-4 rounded-3xl border border-sand bg-gradient-to-br from-ink to-clay-dark p-7 text-cream sm:p-10">
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-saffron">Need a little more help?</p>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-5">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl">Ask a real parent on our team</h2>
              <p className="mt-2 max-w-xl text-[14px] leading-relaxed text-cream/75">
                Feeding questions are personal. Our team can help you find product details and point you toward trusted health guidance.
              </p>
            </div>
            <Link href="/about#contact" className="rounded-full bg-cream px-6 py-3 text-sm font-semibold text-ink transition hover:bg-saffron">
              Get in touch
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
