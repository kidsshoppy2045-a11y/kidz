import type { MetadataRoute } from "next";
import { getCategories, getProducts } from "@/lib/data";
import { getBlogPosts } from "@/lib/blog-data";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://onlinekids.store";
  const [categories, products, articles] = await Promise.all([
    getCategories(),
    getProducts({ limit: 100 }),
    getBlogPosts(100),
  ]);

  const staticRoutes = ["", "/shop", "/about", "/orders", "/checkout", "/blog"].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: path === "" ? 1 : 0.7,
  }));

  return [
    ...staticRoutes,
    ...categories.map((category) => ({
      url: `${base}/collections/${category.slug}`,
      lastModified: new Date(),
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
    ...products.map((product) => ({
      url: `${base}/product/${product.slug}`,
      lastModified: product.createdAt,
      changeFrequency: "weekly" as const,
      priority: 0.6,
    })),
    ...articles.map((article) => ({
      url: `${base}/blog/${article.slug}`,
      lastModified: article.publishedAt,
      changeFrequency: "monthly" as const,
      priority: 0.5,
    })),
  ];
}
