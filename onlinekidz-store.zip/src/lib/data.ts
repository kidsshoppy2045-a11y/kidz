import { and, asc, count, desc, eq, gte, ilike, inArray, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import {
  categories,
  orders,
  products,
  reviews,
  subscribers,
  type OrderRow,
} from "@/db/schema";
import type { Category, Facets, Product, Review, ShopQuery } from "@/lib/catalog";
import { AGE_BANDS, PRICE_BANDS } from "@/lib/catalog";

export type { Product, Category, Review };
export type { Facets, ShopQuery } from "@/lib/catalog";
export { AGE_BANDS, PRICE_BANDS, SORT_OPTIONS } from "@/lib/catalog";
export type Order = OrderRow;

async function ready() {
  await ensureSeeded();
}

export async function getCategories(): Promise<Category[]> {
  await ready();
  try {
    return await db.select().from(categories).orderBy(asc(categories.sortOrder));
  } catch (error) {
    console.error("[data] getCategories", error);
    return [];
  }
}

export async function getCategory(slug: string): Promise<Category | null> {
  await ready();
  try {
    const rows = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
    return rows[0] ?? null;
  } catch (error) {
    console.error("[data] getCategory", error);
    return null;
  }
}

function buildWhere(query: ShopQuery) {
  const clauses = [];
  if (query.category) clauses.push(eq(products.categorySlug, query.category));
  if (query.search) {
    const term = `%${query.search}%`;
    clauses.push(
      or(
        ilike(products.name, term),
        ilike(products.tagline, term),
        ilike(products.brand, term),
        ilike(products.description, term),
      ),
    );
  }
  const ageBand = AGE_BANDS.find((band) => band.id === query.age);
  if (ageBand) {
    clauses.push(lte(products.ageMonthsMin, ageBand.max));
    clauses.push(gte(products.ageMonthsMax, ageBand.min));
  }
  const priceBand = PRICE_BANDS.find((band) => band.id === query.price);
  if (priceBand) {
    clauses.push(gte(products.price, priceBand.min));
    clauses.push(lte(products.price, priceBand.max));
  }
  if (query.rating) {
    const min = Number(query.rating);
    if (!Number.isNaN(min) && min > 0) clauses.push(gte(products.rating, min * 10));
  }
  if (query.tag === "bestsellers") clauses.push(eq(products.isBestseller, true));
  if (query.tag === "new") clauses.push(eq(products.isNew, true));
  return clauses.length > 0 ? and(...clauses) : undefined;
}

function orderBy(sort?: string) {
  switch (sort) {
    case "price-asc":
      return [asc(products.price)];
    case "price-desc":
      return [desc(products.price)];
    case "rating":
      return [desc(products.rating), desc(products.reviewCount)];
    case "popular":
      return [desc(products.soldCount)];
    default:
      return [desc(products.isFeatured), desc(products.isBestseller), desc(products.soldCount)];
  }
}

export async function getProducts(query: ShopQuery = {}): Promise<Product[]> {
  await ready();
  try {
    return await db
      .select()
      .from(products)
      .where(buildWhere(query))
      .orderBy(...orderBy(query.sort))
      .limit(query.limit ?? 60)
      .offset(query.offset ?? 0);
  } catch (error) {
    console.error("[data] getProducts", error);
    return [];
  }
}

export async function getProductCount(query: ShopQuery = {}): Promise<number> {
  await ready();
  try {
    const [row] = await db
      .select({ total: count() })
      .from(products)
      .where(buildWhere(query));
    return Number(row?.total ?? 0);
  } catch (error) {
    console.error("[data] getProductCount", error);
    return 0;
  }
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  await ready();
  try {
    const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    return rows[0] ?? null;
  } catch (error) {
    console.error("[data] getProductBySlug", error);
    return null;
  }
}

export async function getProductsBySlugs(slugs: string[]): Promise<Product[]> {
  if (slugs.length === 0) return [];
  await ready();
  try {
    return await db.select().from(products).where(inArray(products.slug, slugs));
  } catch (error) {
    console.error("[data] getProductsBySlugs", error);
    return [];
  }
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  await ready();
  try {
    const rows = await db
      .select()
      .from(products)
      .where(and(eq(products.categorySlug, product.categorySlug), sql`${products.slug} <> ${product.slug}`))
      .orderBy(desc(products.rating))
      .limit(limit);
    if (rows.length >= limit) return rows;
    const fill = await db
      .select()
      .from(products)
      .where(and(sql`${products.slug} <> ${product.slug}`, eq(products.isBestseller, true)))
      .limit(limit);
    const seen = new Set(rows.map((r) => r.slug));
    for (const item of fill) {
      if (rows.length >= limit) break;
      if (!seen.has(item.slug)) {
        rows.push(item);
        seen.add(item.slug);
      }
    }
    return rows;
  } catch (error) {
    console.error("[data] getRelatedProducts", error);
    return [];
  }
}

export async function getReviews(slug: string): Promise<Review[]> {
  await ready();
  try {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.productSlug, slug))
      .orderBy(desc(reviews.createdAt))
      .limit(24);
  } catch (error) {
    console.error("[data] getReviews", error);
    return [];
  }
}

export async function getTopReviews(limit = 6): Promise<(Review & { productName: string })[]> {
  await ready();
  try {
    const rows = await db
      .select({
        id: reviews.id,
        productSlug: reviews.productSlug,
        author: reviews.author,
        city: reviews.city,
        rating: reviews.rating,
        title: reviews.title,
        body: reviews.body,
        verified: reviews.verified,
        createdAt: reviews.createdAt,
        productName: products.name,
      })
      .from(reviews)
      .innerJoin(products, eq(products.slug, reviews.productSlug))
      .where(eq(reviews.rating, 5))
      .orderBy(desc(reviews.createdAt))
      .limit(limit);
    return rows;
  } catch (error) {
    console.error("[data] getTopReviews", error);
    return [];
  }
}

export async function getFacets(): Promise<Facets> {
  await ready();
  try {
    const all = await db
      .select({
        categorySlug: products.categorySlug,
        rating: products.rating,
        price: products.price,
      })
      .from(products);
    const facets: Facets = {
      total: all.length,
      priceMax: all.reduce((max, item) => Math.max(max, item.price), 0),
      ratingCounts: {},
      categoryCounts: {},
    };
    for (const item of all) {
      facets.categoryCounts[item.categorySlug] = (facets.categoryCounts[item.categorySlug] ?? 0) + 1;
      for (const threshold of [4, 4.5]) {
        const key = String(threshold);
        if (item.rating / 10 >= threshold) {
          facets.ratingCounts[key] = (facets.ratingCounts[key] ?? 0) + 1;
        }
      }
    }
    return facets;
  } catch (error) {
    console.error("[data] getFacets", error);
    return { total: 0, priceMax: 2000, ratingCounts: {}, categoryCounts: {} };
  }
}

export type OrderInput = {
  customerName: string;
  email: string;
  phone: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  pincode: string;
  notes?: string;
  paymentMethod: string;
  couponCode?: string;
  items: { slug: string; name: string; image: string; price: number; quantity: number; variant?: string }[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
};

export async function createOrder(input: OrderInput): Promise<Order> {
  const orderNumber = `OKS-${Date.now().toString(36).toUpperCase().slice(-6)}${Math.floor(
    Math.random() * 90 + 10,
  )}`;
  const [order] = await db
    .insert(orders)
    .values({ ...input, orderNumber, status: "confirmed" })
    .returning();
  return order;
}

export async function getOrderByNumber(orderNumber: string): Promise<Order | null> {
  try {
    const rows = await db
      .select()
      .from(orders)
      .where(eq(orders.orderNumber, orderNumber))
      .limit(1);
    return rows[0] ?? null;
  } catch (error) {
    console.error("[data] getOrderByNumber", error);
    return null;
  }
}

export async function addSubscriber(email: string) {
  await db
    .insert(subscribers)
    .values({ email: email.toLowerCase() })
    .onConflictDoNothing();
}
