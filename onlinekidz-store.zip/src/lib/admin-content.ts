export const ORDER_STATUSES = ["confirmed", "packed", "shipped", "delivered", "cancelled"] as const;

type Block = { type: "paragraph" | "heading" | "list" | "tip"; text?: string; items?: string[] };

/** Journal content <-> simple editable text.
 *  "## Heading", "- list item" lines, "> tip", blank line between blocks. */
export function blocksToText(blocks: Block[]) {
  return blocks
    .map((block) => {
      if (block.type === "heading") return `## ${block.text ?? ""}`;
      if (block.type === "list") return (block.items ?? []).map((item) => `- ${item}`).join("\n");
      if (block.type === "tip") return `> ${block.text ?? ""}`;
      return block.text ?? "";
    })
    .join("\n\n");
}

export function textToBlocks(text: string): Block[] {
  return text
    .replace(/\r/g, "")
    .split(/\n\s*\n/)
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk): Block => {
      const lines = chunk.split("\n").map((line) => line.trim());
      if (chunk.startsWith("## ")) return { type: "heading", text: chunk.slice(3).trim() };
      if (lines.every((line) => line.startsWith("- "))) {
        return { type: "list", items: lines.map((line) => line.slice(2).trim()) };
      }
      if (chunk.startsWith("> ")) return { type: "tip", text: lines.map((l) => l.replace(/^>\s?/, "")).join(" ") };
      return { type: "paragraph", text: lines.join(" ") };
    });
}
