"use client";

export type AnalyticsEventName =
  | "page_view"
  | "site_search"
  | "product_click"
  | "category_click"
  | "hero_cta_click"
  | "newsletter_signup"
  | "article_click"
  | "scroll_depth"
  | "journal_engaged"
  | "product_view"
  | "cta_click"
  | "add_to_cart"
  | "buy_now"
  | "checkout_start"
  | "checkout_error"
  | "purchase_complete"
  | "cart_abandonment"
  | "experiment_impression";

export type AnalyticsMetadata = Record<string, string | number | boolean>;

const SESSION_KEY = "onlinekids.analytics.session.v1";
const SOURCE_KEY = "onlinekids.analytics.source.v1";

function sessionId() {
  try {
    const stored = window.localStorage.getItem(SESSION_KEY);
    if (stored) return stored;
    const id =
      typeof window.crypto?.randomUUID === "function"
        ? window.crypto.randomUUID()
        : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 14)}`;
    window.localStorage.setItem(SESSION_KEY, id);
    return id;
  } catch {
    return `ephemeral-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
}

function sourceFromLocation() {
  try {
    const existing = window.sessionStorage.getItem(SOURCE_KEY);
    if (existing) return existing;

    const params = new URLSearchParams(window.location.search);
    const utm = params.get("utm_source");
    let source = utm?.trim().slice(0, 100) ?? "";

    if (!source && document.referrer) {
      const referrer = new URL(document.referrer);
      source = referrer.hostname === window.location.hostname ? "direct" : referrer.hostname;
    }
    if (!source) source = "direct";
    window.sessionStorage.setItem(SOURCE_KEY, source);
    return source;
  } catch {
    return "direct";
  }
}

function cleanReferrer() {
  if (!document.referrer) return "";
  try {
    const referrer = new URL(document.referrer);
    return `${referrer.origin}${referrer.pathname}`.slice(0, 500);
  } catch {
    return "";
  }
}

export function trackEvent(
  eventName: AnalyticsEventName,
  productSlug?: string,
  metadata: AnalyticsMetadata = {},
) {
  if (typeof window === "undefined") return;

  try {
    const payload = {
      eventName,
      sessionId: sessionId(),
      productSlug,
      pagePath: window.location.pathname,
      referrer: cleanReferrer(),
      source: sourceFromLocation(),
      deviceType: window.innerWidth < 768 ? "mobile" : window.innerWidth < 1024 ? "tablet" : "desktop",
      metadata,
    };

    void fetch("/api/analytics", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      keepalive: true,
      cache: "no-store",
    }).catch(() => undefined);
  } catch {
    // Analytics must never block shopping or checkout.
  }
}
