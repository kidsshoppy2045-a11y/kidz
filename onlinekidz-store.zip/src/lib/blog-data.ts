import { and, count, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { analyticsEvents, blogPosts } from "@/db/schema";
import { ensureBlogSeeded } from "@/db/blog-seed";

export type BlogPost = typeof blogPosts.$inferSelect;

function postWhere(category?: string, search?: string) {
  const clauses = [];
  if (category) clauses.push(eq(blogPosts.category, category));
  const term = search?.trim();
  if (term) {
    const pattern = `%${term.slice(0, 100)}%`;
    clauses.push(
      or(
        ilike(blogPosts.title, pattern),
        ilike(blogPosts.excerpt, pattern),
        ilike(blogPosts.category, pattern),
        ilike(blogPosts.author, pattern),
      ),
    );
  }
  return clauses.length ? and(...clauses) : undefined;
}

export async function getBlogPosts(
  limit = 24,
  offset = 0,
  category?: string,
  search?: string,
  order: "featured" | "latest" = "featured",
): Promise<BlogPost[]> {
  try {
    await ensureBlogSeeded();
    return await db
      .select()
      .from(blogPosts)
      .where(postWhere(category, search))
      .orderBy(
        ...(order === "latest"
          ? [desc(blogPosts.publishedAt)]
          : [desc(blogPosts.featured), desc(blogPosts.publishedAt)]),
      )
      .limit(limit)
      .offset(offset);
  } catch (error) {
    console.error("[blog-data] getBlogPosts", error);
    return [];
  }
}

export async function getBlogPostCount(category?: string, search?: string): Promise<number> {
  try {
    await ensureBlogSeeded();
    const [row] = await db
      .select({ total: count() })
      .from(blogPosts)
      .where(postWhere(category, search));
    return Number(row?.total ?? 0);
  } catch (error) {
    console.error("[blog-data] getBlogPostCount", error);
    return 0;
  }
}

export async function getPopularBlogPosts(limit = 4): Promise<BlogPost[]> {
  try {
    await ensureBlogSeeded();
    const slugExpression = sql<string>`${analyticsEvents.metadata}->>'article_slug'`;
    const ranked = await db
      .select({ slug: slugExpression, clicks: count() })
      .from(analyticsEvents)
      .where(
        sql`${analyticsEvents.eventName} = 'article_click' and ${analyticsEvents.metadata} ? 'article_slug'`,
      )
      .groupBy(slugExpression)
      .orderBy(desc(count()))
      .limit(limit);

    const slugs = ranked.map((row) => row.slug).filter(Boolean);
    if (slugs.length === 0) return [];
    const posts = await db.select().from(blogPosts).where(inArray(blogPosts.slug, slugs));
    const bySlug = new Map(posts.map((post) => [post.slug, post]));
    return slugs.map((slug) => bySlug.get(slug)).filter((post): post is BlogPost => Boolean(post));
  } catch (error) {
    console.error("[blog-data] getPopularBlogPosts", error);
    return [];
  }
}

export async function getTrendingBlogCategories(limit = 5): Promise<string[]> {
  try {
    const categoryExpression = sql<string>`${analyticsEvents.metadata}->>'category'`;
    const rows = await db
      .select({ category: categoryExpression, clicks: count() })
      .from(analyticsEvents)
      .where(
        sql`${analyticsEvents.eventName} = 'category_click' and ${analyticsEvents.metadata}->>'placement' = 'journal-topic-filter'`,
      )
      .groupBy(categoryExpression)
      .orderBy(desc(count()))
      .limit(limit);
    return rows.map((row) => row.category).filter(Boolean);
  } catch (error) {
    console.error("[blog-data] getTrendingBlogCategories", error);
    return [];
  }
}

export async function getBlogPost(slug: string): Promise<BlogPost | null> {
  try {
    await ensureBlogSeeded();
    const rows = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
    return rows[0] ?? null;
  } catch (error) {
    console.error("[blog-data] getBlogPost", error);
    return null;
  }
}
