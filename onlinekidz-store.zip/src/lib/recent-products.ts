export type RecentProduct = {
  slug: string;
  name: string;
  image: string;
  price: number;
  brand: string;
  tagline: string;
};

export const RECENT_PRODUCTS_KEY = "onlinekids.recent-products.v1";
