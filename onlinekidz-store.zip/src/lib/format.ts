export function formatINR(amount: number): string {
  return `₹${new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(
    Math.round(amount),
  )}`;
}

/** rating is stored as rating * 10 (e.g. 48 -> 4.8) */
export function formatRating(rating: number): string {
  return (rating / 10).toFixed(1);
}

export function formatAgeRange(min: number, max: number): string {
  const label = (m: number) => {
    if (m < 12) return `${m} mo`;
    if (m < 24) return "1 yr";
    const years = Math.floor(m / 12);
    return `${years} yr${years > 1 ? "s" : ""}`;
  };
  if (min <= 0) return `0 – ${label(max)}`;
  return `${label(min)} – ${label(max)}`;
}

export function formatDate(value: Date | string): string {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function discountPercent(price: number, compareAt?: number | null): number | null {
  if (!compareAt || compareAt <= price) return null;
  return Math.round(((compareAt - price) / compareAt) * 100);
}

export const FREE_SHIPPING_THRESHOLD = 999;
export const SHIPPING_FEE = 79;

export const COUPONS: Record<string, { type: "percent" | "flat"; value: number; label: string }> = {
  LITTLE10: { type: "percent", value: 10, label: "10% off your first order" },
  MILLET200: { type: "flat", value: 200, label: "₹200 off on orders above ₹1,499" },
};

export function computeTotals(subtotal: number, couponCode?: string) {
  const coupon = couponCode ? COUPONS[couponCode.toUpperCase()] : undefined;
  let discount = 0;
  if (coupon) {
    if (coupon.type === "percent") discount = Math.round((subtotal * coupon.value) / 100);
    else if (subtotal >= 1499) discount = coupon.value;
  }
  const shipping = subtotal === 0 || subtotal - discount >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  return {
    discount,
    shipping,
    total: Math.max(0, subtotal - discount + shipping),
  };
}
