import type { CategoryRow, ProductRow, ReviewRow } from "@/db/schema";

/** Client-safe catalogue types and filter constants (no database imports). */

export type Product = ProductRow;
export type Category = CategoryRow;
export type Review = ReviewRow;

export type ShopQuery = {
  category?: string;
  search?: string;
  age?: string;
  price?: string;
  rating?: string;
  sort?: string;
  tag?: string;
  limit?: number;
  offset?: number;
};

export type Facets = {
  total: number;
  priceMax: number;
  ratingCounts: Record<string, number>;
  categoryCounts: Record<string, number>;
};

export const AGE_BANDS = [
  { id: "newborn", label: "Newborn · 0–6 mo", min: 0, max: 6 },
  { id: "infant", label: "Infant · 6–12 mo", min: 6, max: 12 },
  { id: "toddler", label: "Toddler · 1–3 yrs", min: 12, max: 36 },
  { id: "preschool", label: "Preschool · 3–6 yrs", min: 36, max: 72 },
  { id: "school", label: "School · 6–12 yrs", min: 72, max: 144 },
] as const;

export const PRICE_BANDS = [
  { id: "u300", label: "Under ₹300", min: 0, max: 299 },
  { id: "300to600", label: "₹300 – ₹600", min: 300, max: 600 },
  { id: "600to1000", label: "₹600 – ₹1,000", min: 600, max: 1000 },
  { id: "1000plus", label: "₹1,000 & above", min: 1000, max: 100000 },
] as const;

export const SORT_OPTIONS = [
  { id: "featured", label: "Featured" },
  { id: "price-asc", label: "Price: low to high" },
  { id: "price-desc", label: "Price: high to low" },
  { id: "rating", label: "Top rated" },
  { id: "popular", label: "Most loved" },
] as const;
