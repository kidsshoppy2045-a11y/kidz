"use client";

import { useEffect } from "react";
import { trackEvent } from "@/lib/analytics";
import { RECENT_PRODUCTS_KEY, type RecentProduct } from "@/lib/recent-products";

export function ProductViewAnalytics({ product }: { product: RecentProduct }) {
  useEffect(() => {
    trackEvent("product_view", product.slug);
    try {
      const raw = window.localStorage.getItem(RECENT_PRODUCTS_KEY);
      const previous = raw ? (JSON.parse(raw) as RecentProduct[]) : [];
      const next = [product, ...previous.filter((item) => item.slug !== product.slug)].slice(0, 8);
      window.localStorage.setItem(RECENT_PRODUCTS_KEY, JSON.stringify(next));
    } catch {
      // Viewing a product should work when browser storage is unavailable.
    }
  }, [product]);

  return null;
}
