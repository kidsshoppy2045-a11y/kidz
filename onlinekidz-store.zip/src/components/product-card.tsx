"use client";

import { useState } from "react";
import type { Product } from "@/lib/catalog";
import { trackEvent } from "@/lib/analytics";
import { TrackedLink } from "./tracked-link";
import { discountPercent, formatAgeRange, formatINR, formatRating } from "@/lib/format";
import { useCart } from "./cart-context";
import { BagIcon, HeartIcon } from "./icons";
import { Stars } from "./stars";

export function ProductCard({
  product,
  priority = false,
  compact = false,
}: {
  product: Product;
  priority?: boolean;
  compact?: boolean;
}) {
  const { addItem, toggleWishlist, isWishlisted } = useCart();
  const [hovered, setHovered] = useState(false);
  const saved = isWishlisted(product.slug);
  const off = discountPercent(product.price, product.compareAtPrice);
  const images = product.images ?? [];
  const secondary = images[1] ?? images[0];

  return (
    <article
      className="group card-lift relative flex h-full flex-col overflow-hidden rounded-3xl border border-sand/80 bg-white shadow-soft"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <TrackedLink
        href={`/product/${product.slug}`}
        eventName="product_click"
        productSlug={product.slug}
        metadata={{ placement: "product-card-image" }}
        className="relative block overflow-hidden"
      >
        <div className="relative aspect-square overflow-hidden bg-shell">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={hovered && secondary ? secondary : images[0]}
            alt={product.name}
            loading={priority ? "eager" : "lazy"}
            className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.06]"
          />
        </div>
        <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {product.isNew ? (
            <span className="rounded-full bg-saffron px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-ink">
              Just in
            </span>
          ) : null}
          {product.badge ? (
            <span className="rounded-full bg-ink/90 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-cream backdrop-blur">
              {product.badge}
            </span>
          ) : null}
          {off ? (
            <span className="rounded-full bg-brand-orange px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-ink">
              {off}% off
            </span>
          ) : null}
        </div>
      </TrackedLink>
      <button
        type="button"
        onClick={() =>
          toggleWishlist({
            slug: product.slug,
            name: product.name,
            image: images[0],
            price: product.price,
            compareAtPrice: product.compareAtPrice,
            unitLabel: product.unitLabel,
            brand: product.brand,
            tagline: product.tagline,
            rating: product.rating,
            reviewCount: product.reviewCount,
            ageMonthsMin: product.ageMonthsMin,
            ageMonthsMax: product.ageMonthsMax,
          })
        }
        aria-label={saved ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
        aria-pressed={saved}
        className={`absolute right-3 top-3 z-20 flex h-10 w-10 items-center justify-center rounded-full border border-white/80 shadow-soft backdrop-blur transition-all duration-300 hover:scale-105 active:scale-95 ${
          saved ? "bg-brand-pink text-white" : "bg-white/90 text-ink hover:text-brand-pink"
        }`}
      >
        <HeartIcon filled={saved} width={18} height={18} />
      </button>

      <div className="flex flex-1 flex-col gap-2 p-4 sm:p-5">
        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-soft/70">
          {product.brand}
        </p>
        <h3 className="font-display text-[17px] leading-snug text-ink sm:text-lg">
          <TrackedLink
            href={`/product/${product.slug}`}
            eventName="product_click"
            productSlug={product.slug}
            metadata={{ placement: "product-card-title" }}
            className="transition-colors hover:text-clay"
          >
            {product.name}
          </TrackedLink>
        </h3>
        {!compact ? (
          <p className="line-clamp-2 text-[13px] leading-relaxed text-ink-soft/85">{product.tagline}</p>
        ) : null}

        <div className="mt-1 flex items-center gap-2 text-xs text-ink-soft/80">
          <Stars rating={product.rating / 10} size={12} />
          <span className="font-medium">{formatRating(product.rating)}</span>
          <span className="text-ink-soft/50">({product.reviewCount})</span>
        </div>

        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display text-xl text-ink">{formatINR(product.price)}</span>
              {product.compareAtPrice ? (
                <span className="text-sm text-ink-soft/50 line-through">
                  {formatINR(product.compareAtPrice)}
                </span>
              ) : null}
            </div>
            <p className="mt-0.5 text-[11px] text-ink-soft/70">
              {formatAgeRange(product.ageMonthsMin, product.ageMonthsMax)}
              {product.unitLabel ? ` · ${product.unitLabel.split("·")[0]}` : ""}
            </p>
          </div>
          <button
            type="button"
            disabled={product.stock <= 0}
            onClick={() => {
              trackEvent("cta_click", product.slug, {
                placement: "product-card",
                cta_label: "Add",
              });
              addItem({
                slug: product.slug,
                name: product.name,
                image: images[0],
                price: product.price,
                compareAtPrice: product.compareAtPrice,
                unitLabel: product.unitLabel,
              });
            }}
            aria-label={`Add ${product.name} to basket`}
            className={`flex h-10 shrink-0 items-center justify-center rounded-full bg-clay text-cream transition-all duration-300 hover:scale-105 hover:bg-clay-dark active:scale-95 disabled:cursor-not-allowed disabled:opacity-45 ${
              compact ? "w-10" : "gap-2 px-3.5 text-[12px] font-semibold"
            }`}
          >
            <BagIcon width={16} height={16} />
            {!compact ? <span>Add</span> : null}
          </button>
        </div>
      </div>
      {product.isBestseller ? (
        <span className="pointer-events-none absolute -right-8 top-16 rotate-45 bg-saffron/95 px-10 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-ink opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          Loved
        </span>
      ) : null}
      <span className="sr-only" aria-live="polite">
        {product.name} costs {formatINR(product.price)}
      </span>
    </article>
  );
}
