"use client";

import { useEffect } from "react";
import { trackEvent, type AnalyticsMetadata } from "@/lib/analytics";

export function JournalAnalytics({ articleSlug }: { articleSlug?: string }) {
  useEffect(() => {
    const placement = articleSlug ? "journal-article" : "journal-index";
    const metadata: AnalyticsMetadata = { placement };
    if (articleSlug) metadata.article_slug = articleSlug;
    const fired = new Set<number>();
    let frame = 0;

    const measureDepth = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(() => {
        frame = 0;
        const documentHeight = Math.max(
          document.documentElement.scrollHeight,
          document.body.scrollHeight,
        );
        if (documentHeight <= window.innerHeight) return;
        const depth = Math.min(
          100,
          Math.round(((window.scrollY + window.innerHeight) / documentHeight) * 100),
        );
        for (const threshold of [50, 90]) {
          if (depth >= threshold && !fired.has(threshold)) {
            fired.add(threshold);
            trackEvent("scroll_depth", undefined, { ...metadata, depth: threshold });
          }
        }
      });
    };

    window.addEventListener("scroll", measureDepth, { passive: true });
    measureDepth();
    const engagedTimer = window.setTimeout(() => {
      trackEvent("journal_engaged", undefined, { ...metadata, reading_seconds: 30 });
    }, 30000);

    return () => {
      window.removeEventListener("scroll", measureDepth);
      if (frame) window.cancelAnimationFrame(frame);
      window.clearTimeout(engagedTimer);
    };
  }, [articleSlug]);

  return null;
}
