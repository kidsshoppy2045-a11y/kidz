"use client";

import Link from "next/link";
import { useCart } from "./cart-context";
import { BagIcon, HeartIcon, TrashIcon } from "./icons";
import { formatAgeRange, formatINR, formatRating } from "@/lib/format";
import { Stars } from "./stars";

export function WishlistContent() {
  const { wishlist, hydrated, addItem, removeWishlistItem } = useCart();

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-[1200px] px-4 py-12 sm:px-6 lg:px-10">
        <div className="h-10 w-60 animate-pulse rounded-2xl bg-shell" />
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="overflow-hidden rounded-3xl border border-sand bg-white">
              <div className="aspect-square animate-pulse bg-shell" />
              <div className="space-y-2 p-4">
                <div className="h-4 w-4/5 animate-pulse rounded-full bg-shell" />
                <div className="h-4 w-1/2 animate-pulse rounded-full bg-shell" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1200px] px-4 pb-20 pt-10 sm:px-6 lg:px-10">
      <nav className="flex items-center gap-2 text-[12px] text-ink-soft/70">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <span className="text-ink">Wishlist</span>
      </nav>
      <header className="mt-5 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
            A little list for later
          </p>
          <h1 className="mt-2 font-display text-[34px] leading-tight text-ink sm:text-[44px]">
            Your wishlist
          </h1>
          <p className="mt-2 text-[14.5px] text-ink-soft">
            {wishlist.length === 0
              ? "Save the things you love and find them here when you're ready."
              : `${wishlist.length} saved pick${wishlist.length === 1 ? "" : "s"} — ready when you are.`}
          </p>
        </div>
        {wishlist.length > 0 ? (
          <Link
            href="/shop"
            className="rounded-full border border-ink/15 px-5 py-2.5 text-[13px] font-semibold text-ink transition hover:border-clay hover:text-clay"
          >
            Keep browsing
          </Link>
        ) : null}
      </header>

      {wishlist.length === 0 ? (
        <div className="mt-8 flex min-h-[330px] flex-col items-center justify-center rounded-[2rem] border border-dashed border-sand bg-white/60 px-6 text-center">
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-shell text-clay">
            <HeartIcon width={34} height={34} />
          </span>
          <h2 className="mt-5 font-display text-2xl text-ink">A blank page, for now</h2>
          <p className="mt-2 max-w-md text-[14.5px] leading-relaxed text-ink-soft">
            Tap the heart on any product to save it here. Your list stays on this device, even after
            you close the shop.
          </p>
          <Link
            href="/shop"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-clay px-6 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark"
          >
            Explore the shop <span aria-hidden>→</span>
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {wishlist.map((item) => (
            <article
              key={item.slug}
              className="group overflow-hidden rounded-3xl border border-sand/80 bg-white shadow-soft transition-all duration-400 hover:-translate-y-1 hover:shadow-lift"
            >
              <div className="relative aspect-square overflow-hidden bg-shell">
                <Link href={`/product/${item.slug}`} className="block h-full w-full">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={item.image}
                    alt={item.name}
                    className="h-full w-full object-cover transition-transform duration-[900ms] group-hover:scale-[1.05]"
                    loading="lazy"
                  />
                </Link>
                <button
                  type="button"
                  onClick={() => removeWishlistItem(item.slug)}
                  className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full border border-white/80 bg-white/90 text-clay shadow-soft backdrop-blur transition hover:scale-105"
                  aria-label={`Remove ${item.name} from wishlist`}
                >
                  <TrashIcon width={16} height={16} />
                </button>
              </div>
              <div className="p-4 sm:p-5">
                <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-ink-soft/70">
                  {item.brand}
                </p>
                <Link href={`/product/${item.slug}`}>
                  <h2 className="mt-1 font-display text-[18px] leading-snug text-ink transition hover:text-clay">
                    {item.name}
                  </h2>
                </Link>
                <p className="mt-1 line-clamp-2 text-[12.5px] text-ink-soft/85">{item.tagline}</p>
                <div className="mt-2 flex items-center gap-1.5 text-[11.5px] text-ink-soft">
                  <Stars rating={item.rating / 10} size={11} />
                  {formatRating(item.rating)} · {item.reviewCount} reviews
                </div>
                <div className="mt-4 flex items-end justify-between gap-2">
                  <span>
                    <span className="block font-display text-xl text-ink">{formatINR(item.price)}</span>
                    <span className="block text-[10.5px] text-ink-soft/75">
                      {formatAgeRange(item.ageMonthsMin, item.ageMonthsMax)}
                    </span>
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      addItem({
                        slug: item.slug,
                        name: item.name,
                        image: item.image,
                        price: item.price,
                        compareAtPrice: item.compareAtPrice,
                        unitLabel: item.unitLabel,
                      })
                    }
                    className="inline-flex h-10 items-center gap-2 rounded-full bg-clay px-4 text-[12px] font-semibold text-cream transition hover:bg-clay-dark"
                  >
                    <BagIcon width={15} height={15} /> Add
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
