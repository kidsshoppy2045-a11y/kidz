"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { trackEvent } from "@/lib/analytics";
import { RECENT_PRODUCTS_KEY, type RecentProduct } from "@/lib/recent-products";
import { formatINR } from "@/lib/format";
import { ArrowRightIcon } from "./icons";

export function RecentlyViewed() {
  const [products, setProducts] = useState<RecentProduct[]>([]);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(RECENT_PRODUCTS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as RecentProduct[];
        if (Array.isArray(parsed)) setProducts(parsed.filter((item) => item.slug && item.name).slice(0, 6));
      }
    } catch {
      setProducts([]);
    }
  }, []);

  if (products.length === 0) return null;

  return (
    <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6 lg:px-10">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-clay">Just for you</p>
          <h2 className="mt-1 font-display text-[25px] text-ink sm:text-[30px]">Recently viewed</h2>
        </div>
        <Link href="/shop" className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-clay hover:text-ink">
          Keep exploring <ArrowRightIcon width={14} height={14} />
        </Link>
      </div>
      <div className="no-scrollbar mt-5 flex snap-x gap-3 overflow-x-auto pb-3">
        {products.map((product) => (
          <Link
            key={product.slug}
            href={`/product/${product.slug}`}
            onClick={() => trackEvent("product_click", product.slug, { placement: "recently-viewed" })}
            className="group flex w-[255px] shrink-0 snap-start items-center gap-3 rounded-2xl border border-sand bg-white p-3 shadow-soft transition hover:border-clay/50 hover:shadow-lift"
          >
            <span className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-shell">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={product.image} alt={product.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-soft/65">{product.brand}</span>
              <span className="mt-0.5 block line-clamp-2 text-[13px] font-semibold leading-snug text-ink">{product.name}</span>
              <span className="mt-1 block text-[12px] font-semibold text-clay">{formatINR(product.price)}</span>
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
