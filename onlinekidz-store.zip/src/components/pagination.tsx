import Link from "next/link";

type Props = {
  currentPage: number;
  totalPages: number;
  pathname: string;
  query?: Record<string, string | undefined>;
  totalItems?: number;
  pageSize?: number;
  itemLabel?: string;
};

type PageToken = number | "ellipsis-start" | "ellipsis-end";

function getPageTokens(currentPage: number, totalPages: number): PageToken[] {
  if (totalPages <= 5) return Array.from({ length: totalPages }, (_, index) => index + 1);

  const pages: PageToken[] = [1];
  const start = Math.max(2, currentPage - 1);
  const end = Math.min(totalPages - 1, currentPage + 1);

  if (start > 2) pages.push("ellipsis-start");
  for (let page = start; page <= end; page += 1) pages.push(page);
  if (end < totalPages - 1) pages.push("ellipsis-end");
  pages.push(totalPages);
  return pages;
}

export function Pagination({
  currentPage,
  totalPages,
  pathname,
  query = {},
  totalItems,
  pageSize = 12,
  itemLabel = "items",
}: Props) {
  if (totalPages <= 1) return null;

  const hrefForPage = (page: number) => {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([key, value]) => {
      if (value && key !== "page") params.set(key, value);
    });
    if (page > 1) params.set("page", String(page));
    const search = params.toString();
    return search ? `${pathname}?${search}` : pathname;
  };

  const tokens = getPageTokens(currentPage, totalPages);
  const firstItem = (currentPage - 1) * pageSize + 1;
  const lastItem = Math.min(currentPage * pageSize, totalItems ?? currentPage * pageSize);

  return (
    <nav
      aria-label={`${itemLabel} pagination`}
      className="mt-8 flex flex-col gap-3 border-t border-sand pt-5 sm:flex-row sm:items-center sm:justify-between"
    >
      <p className="text-[12.5px] text-ink-soft">
        Page <strong className="font-semibold text-ink">{currentPage}</strong> of {totalPages}
        {typeof totalItems === "number" ? (
          <span className="ml-2 text-ink-soft/70">· {firstItem}–{lastItem} of {totalItems}</span>
        ) : null}
      </p>
      <div className="flex items-center gap-1.5">
        {currentPage > 1 ? (
          <Link
            href={hrefForPage(currentPage - 1)}
            rel="prev"
            className="inline-flex h-10 items-center gap-1 rounded-full border border-sand bg-white px-3.5 text-[12.5px] font-semibold text-ink transition hover:border-clay hover:text-clay"
          >
            <span aria-hidden>←</span> Previous
          </Link>
        ) : (
          <span aria-disabled="true" className="inline-flex h-10 items-center gap-1 rounded-full border border-sand/70 px-3.5 text-[12.5px] font-semibold text-ink-soft/40">
            <span aria-hidden>←</span> Previous
          </span>
        )}

        <div className="hidden items-center gap-1.5 sm:flex">
          {tokens.map((token) =>
            typeof token === "number" ? (
              <Link
                key={token}
                href={hrefForPage(token)}
                aria-label={`Page ${token}`}
                aria-current={token === currentPage ? "page" : undefined}
                className={`flex h-10 min-w-10 items-center justify-center rounded-full px-3 text-[13px] font-semibold transition ${
                  token === currentPage
                    ? "bg-ink text-cream shadow-soft"
                    : "border border-sand bg-white text-ink hover:border-clay hover:text-clay"
                }`}
              >
                {token}
              </Link>
            ) : (
              <span key={token} aria-hidden className="px-1 text-sm text-ink-soft/60">
                …
              </span>
            ),
          )}
        </div>

        {currentPage < totalPages ? (
          <Link
            href={hrefForPage(currentPage + 1)}
            rel="next"
            className="inline-flex h-10 items-center gap-1 rounded-full border border-sand bg-white px-3.5 text-[12.5px] font-semibold text-ink transition hover:border-clay hover:text-clay"
          >
            Next <span aria-hidden>→</span>
          </Link>
        ) : (
          <span aria-disabled="true" className="inline-flex h-10 items-center gap-1 rounded-full border border-sand/70 px-3.5 text-[12.5px] font-semibold text-ink-soft/40">
            Next <span aria-hidden>→</span>
          </span>
        )}
      </div>
    </nav>
  );
}
