"use client";

import { useCart } from "./cart-context";
import { CheckIcon, CloseIcon } from "./icons";

export function Toaster() {
  const { toasts, dismissToast } = useCart();

  return (
    <div className="pointer-events-none fixed bottom-4 left-1/2 z-[90] flex w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 flex-col gap-2 sm:bottom-6 sm:left-6 sm:translate-x-0">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-start gap-3 rounded-2xl border border-sand bg-white/95 p-3.5 shadow-lift backdrop-blur animate-pop"
        >
          <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sage/20 text-teal">
            <CheckIcon width={15} height={15} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-semibold text-ink">{toast.title}</p>
            {toast.body ? (
              <p className="mt-0.5 line-clamp-2 text-xs text-ink-soft/85">{toast.body}</p>
            ) : null}
          </div>
          <button
            type="button"
            onClick={() => dismissToast(toast.id)}
            className="text-ink-soft/50 transition hover:text-ink"
            aria-label="Dismiss"
          >
            <CloseIcon width={14} height={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
