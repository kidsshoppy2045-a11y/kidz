"use client";

import { useRouter } from "next/navigation";
import { SORT_OPTIONS } from "@/lib/catalog";
import { ChevronDownIcon } from "./icons";

export function SortSelect({ value, pathname = "/shop" }: { value: string; pathname?: string }) {
  const router = useRouter();

  return (
    <label className="relative inline-flex items-center gap-2 rounded-full border border-sand bg-white pl-4 pr-3 py-2.5 text-[13px] shadow-soft">
      <span className="text-ink-soft/80">Sort</span>
      <select
        value={value}
        onChange={(event) => {
          const next = new URLSearchParams(window.location.search);
          if (event.target.value === "featured") next.delete("sort");
          else next.set("sort", event.target.value);
          next.delete("page");
          const query = next.toString();
          router.push(query ? `${pathname}?${query}` : pathname, { scroll: false });
        }}
        className="appearance-none bg-transparent pr-5 font-semibold text-ink outline-none"
      >
        {SORT_OPTIONS.map((option) => (
          <option key={option.id} value={option.id}>
            {option.label}
          </option>
        ))}
      </select>
      <ChevronDownIcon
        width={14}
        height={14}
        className="pointer-events-none absolute right-3 text-ink-soft/70"
      />
    </label>
  );
}
