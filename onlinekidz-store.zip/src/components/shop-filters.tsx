"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Category, Facets } from "@/lib/catalog";
import { AGE_BANDS, PRICE_BANDS } from "@/lib/catalog";
import { CloseIcon } from "./icons";

type Props = {
  categories: Category[];
  facets: Facets;
  params: Record<string, string | undefined>;
  resultCount: number;
};

export function ShopFilters({ categories, facets, params, resultCount }: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const current = {
    category: params.category ?? "",
    age: params.age ?? "",
    price: params.price ?? "",
    rating: params.rating ?? "",
    q: params.q ?? "",
    tag: params.tag ?? "",
    sort: params.sort ?? "",
  };

  const push = (updates: Record<string, string | null>) => {
    const next = new URLSearchParams();
    Object.entries({ ...current, ...updates }).forEach(([key, value]) => {
      if (value && !(key === "category" && value === "all")) next.set(key, value);
    });
    const query = next.toString();
    router.push(query ? `/shop?${query}` : "/shop", { scroll: false });
  };

  const activeChips = Object.entries(current)
    .filter(([key, value]) => value && key !== "sort")
    .map(([key, value]) => {
      let label = value as string;
      if (key === "category") label = categories.find((c) => c.slug === value)?.name ?? value;
      if (key === "age") label = AGE_BANDS.find((b) => b.id === value)?.label ?? value;
      if (key === "price") label = PRICE_BANDS.find((b) => b.id === value)?.label ?? value;
      if (key === "rating") label = `${value}★ & above`;
      if (key === "q") label = `“${value}”`;
      if (key === "tag") label = value === "bestsellers" ? "Bestsellers" : "New arrivals";
      return { key, value: value as string, label };
    });

  const hasFilters = activeChips.length > 0;

  const Group = ({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) => (
    <div className="border-t border-sand pt-5">
      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-soft/70">{title}</p>
      <div className="mt-3 space-y-1.5">{children}</div>
    </div>
  );

  const Radio = ({
    active,
    label,
    count,
    onClick,
  }: {
    active: boolean;
    label: string;
    count?: number;
    onClick: () => void;
  }) => (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2 text-left text-[13.5px] transition ${
        active ? "bg-ink text-cream" : "text-ink-soft hover:bg-shell"
      }`}
    >
      <span className="flex-1 truncate">{label}</span>
      {typeof count === "number" ? (
        <span className={`text-[11px] ${active ? "text-cream/70" : "text-ink-soft/60"}`}>{count}</span>
      ) : null}
    </button>
  );

  const panel = (
    <div className="space-y-5">
      <Group title="Collection">
        <Radio
          active={!current.category}
          label="All products"
          count={facets.total}
          onClick={() => push({ category: null })}
        />
        {categories.map((category) => (
          <Radio
            key={category.slug}
            active={current.category === category.slug}
            label={category.name}
            count={facets.categoryCounts[category.slug] ?? 0}
            onClick={() => push({ category: category.slug })}
          />
        ))}
      </Group>

      <Group title="Age group">
        {AGE_BANDS.map((band) => (
          <Radio
            key={band.id}
            active={current.age === band.id}
            label={band.label}
            onClick={() => push({ age: current.age === band.id ? null : band.id })}
          />
        ))}
      </Group>

      <Group title="Price">
        {PRICE_BANDS.map((band) => (
          <Radio
            key={band.id}
            active={current.price === band.id}
            label={band.label}
            onClick={() => push({ price: current.price === band.id ? null : band.id })}
          />
        ))}
      </Group>

      <Group title="Rating">
        {["4.5", "4"].map((value) => (
          <Radio
            key={value}
            active={current.rating === value}
            label={`${value} stars & above`}
            count={facets.ratingCounts[value] ?? 0}
            onClick={() => push({ rating: current.rating === value ? null : value })}
          />
        ))}
      </Group>

      <div className="border-t border-sand pt-5">
        <button
          type="button"
          onClick={() => router.push("/shop", { scroll: false })}
          disabled={!hasFilters}
          className="w-full rounded-full border border-ink/15 py-2.5 text-[13px] font-semibold text-ink transition enabled:hover:bg-shell disabled:opacity-40"
        >
          Clear all filters
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile toolbar */}
      <div className="mb-4 flex items-center justify-between gap-3 lg:hidden">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-full border border-sand bg-white px-4 py-2.5 text-[13px] font-semibold text-ink"
        >
          Filters
          {hasFilters ? (
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-clay text-[10px] text-white">
              {activeChips.length}
            </span>
          ) : null}
        </button>
        <span className="text-[13px] text-ink-soft">{resultCount} products</span>
      </div>

      <aside className="hidden lg:block">
        <div className="sticky top-32 rounded-3xl border border-sand bg-white p-5 shadow-soft">
          <p className="font-display text-lg text-ink">Refine</p>
          {hasFilters ? (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {activeChips.map((chip) => (
                <button
                  key={chip.key}
                  type="button"
                  onClick={() => push({ [chip.key]: null })}
                  className="inline-flex items-center gap-1 rounded-full bg-shell px-2.5 py-1 text-[11px] font-medium text-ink transition hover:bg-sand"
                >
                  {chip.label}
                  <CloseIcon width={11} height={11} />
                </button>
              ))}
            </div>
          ) : null}
          <div className="mt-4">{panel}</div>
        </div>
      </aside>

      {/* Mobile sheet */}
      <div className={`fixed inset-0 z-[75] lg:hidden ${open ? "" : "pointer-events-none"}`}>
        <button
          type="button"
          aria-label="Close filters"
          onClick={() => setOpen(false)}
          className={`absolute inset-0 bg-ink/45 backdrop-blur-[3px] transition-opacity duration-300 ${
            open ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          className={`absolute bottom-0 left-0 right-0 max-h-[86vh] overflow-y-auto rounded-t-3xl bg-cream p-5 shadow-lift transition-transform duration-[400ms] [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] ${
            open ? "translate-y-0" : "translate-y-full"
          }`}
        >
          <div className="mb-4 flex items-center justify-between">
            <p className="font-display text-lg text-ink">Filters</p>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-sand"
              aria-label="Close filters"
            >
              <CloseIcon width={16} height={16} />
            </button>
          </div>
          {panel}
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="mt-5 w-full rounded-full bg-ink py-3.5 text-sm font-semibold text-cream"
          >
            Show {resultCount} products
          </button>
        </div>
      </div>
    </>
  );
}
