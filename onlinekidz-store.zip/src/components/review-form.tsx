"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Stars } from "./stars";
import { StarIcon } from "./icons";

export function ReviewForm({ slug }: { slug: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [author, setAuthor] = useState("");
  const [city, setCity] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [status, setStatus] = useState<"idle" | "saving" | "done" | "error">("idle");

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setStatus("saving");
    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug, author, city, title, body, rating }),
      });
      if (!response.ok) throw new Error("failed");
      setStatus("done");
      setAuthor("");
      setCity("");
      setTitle("");
      setBody("");
      router.refresh();
    } catch {
      setStatus("error");
    }
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-full border border-ink/15 px-5 py-2.5 text-[13px] font-semibold text-ink transition hover:border-clay hover:text-clay"
      >
        Write a review
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-3xl border border-sand bg-white p-5 shadow-soft">
      <div className="flex items-center justify-between">
        <p className="font-display text-lg text-ink">Share your experience</p>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="text-[12px] text-ink-soft underline hover:text-clay"
        >
          Cancel
        </button>
      </div>

      <div className="mt-3 flex items-center gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            aria-label={`${star} star`}
            className={star <= rating ? "text-saffron" : "text-sand"}
          >
            <StarIcon width={22} height={22} filled={star <= rating} />
          </button>
        ))}
        <span className="ml-1 text-[13px] text-ink-soft">{rating}.0</span>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <input
          required
          value={author}
          onChange={(event) => setAuthor(event.target.value)}
          placeholder="Your name"
          className="rounded-xl border border-sand bg-cream px-3.5 py-2.5 text-sm outline-none focus:border-clay"
        />
        <input
          value={city}
          onChange={(event) => setCity(event.target.value)}
          placeholder="City (optional)"
          className="rounded-xl border border-sand bg-cream px-3.5 py-2.5 text-sm outline-none focus:border-clay"
        />
      </div>
      <input
        required
        value={title}
        onChange={(event) => setTitle(event.target.value)}
        placeholder="Headline"
        className="mt-3 w-full rounded-xl border border-sand bg-cream px-3.5 py-2.5 text-sm outline-none focus:border-clay"
      />
      <textarea
        required
        rows={4}
        value={body}
        onChange={(event) => setBody(event.target.value)}
        placeholder="What did you and your little one think?"
        className="mt-3 w-full rounded-xl border border-sand bg-cream px-3.5 py-2.5 text-sm outline-none focus:border-clay"
      />
      <div className="mt-4 flex items-center gap-3">
        <button
          type="submit"
          disabled={status === "saving"}
          className="rounded-full bg-clay px-6 py-2.5 text-[13.5px] font-semibold text-cream transition hover:bg-clay-dark disabled:opacity-60"
        >
          {status === "saving" ? "Posting…" : "Post review"}
        </button>
        {status === "done" ? (
          <span className="text-[13px] font-medium text-teal">Thank you — it&apos;s live now.</span>
        ) : null}
        {status === "error" ? (
          <span className="text-[13px] font-medium text-clay">Something went wrong, try again.</span>
        ) : null}
      </div>
    </form>
  );
}

export function ReviewSummary({
  slug,
  rating,
  count,
  distribution,
}: {
  slug: string;
  rating: number;
  count: number;
  distribution: { stars: number; count: number }[];
}) {
  return (
    <div className="grid gap-6 rounded-3xl border border-sand bg-white p-6 shadow-soft sm:grid-cols-[190px_1fr]">
      <div className="text-center sm:text-left">
        <p className="font-display text-[52px] leading-none text-ink">{(rating / 10).toFixed(1)}</p>
        <Stars rating={rating / 10} size={17} className="mt-2" />
        <p className="mt-2 text-[12.5px] text-ink-soft">{count} verified reviews</p>
        <div className="mt-4">
          <ReviewForm slug={slug} />
        </div>
      </div>
      <div className="space-y-2">
        {distribution.map((row) => {
          const pct = count > 0 ? Math.round((row.count / count) * 100) : 0;
          return (
            <div key={row.stars} className="flex items-center gap-3">
              <span className="w-8 text-[12px] font-medium text-ink-soft">{row.stars}★</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-shell">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-saffron to-clay transition-[width] duration-700"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className="w-9 text-right text-[12px] text-ink-soft/75">{row.count}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
