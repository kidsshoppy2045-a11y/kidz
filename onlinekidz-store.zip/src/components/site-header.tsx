"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import type { Category } from "@/lib/data";
import { BrandLogo } from "./brand-logo";
import { HomeSearch } from "./home-search";
import { useCart } from "./cart-context";
import { BagIcon, ChevronDownIcon, CloseIcon, HeartIcon, MenuIcon, SearchIcon, UserIcon } from "./icons";

const NAV = [
  { href: "/shop", label: "Shop all" },
  { href: "/collections/organic-foods", label: "Organic foods" },
  { href: "/collections/mother-care", label: "Mother care" },
  { href: "/shop?tag=bestsellers", label: "Bestsellers" },
  { href: "/blog", label: "Journal" },
  { href: "/about", label: "Our story" },
];

const TICKER = [
  "Free delivery over ₹999",
  "Made in small batches, never warehoused",
  "Free 30-day returns",
  "FSSAI certified kitchen",
  "COD available across India",
];

export function SiteHeader({ categories }: { categories: Category[] }) {
  const { count, wishlistCount, openCart, hydrated } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [collectionsOpen, setCollectionsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    setMenuOpen(false);
    setCollectionsOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const term = query.trim();
    setSearchOpen(false);
    router.push(term ? `/shop?q=${encodeURIComponent(term)}` : "/shop");
  };

  if (pathname?.startsWith("/admin")) return null;

  return (
    <header className="sticky top-0 z-50">
      <div className="overflow-hidden bg-ink text-cream">
        <div className="flex w-max animate-marquee gap-10 py-2 text-[11px] font-medium uppercase tracking-[0.22em]">
          {[...TICKER, ...TICKER].map((line, index) => (
            <span key={`${line}-${index}`} className="flex items-center gap-10 whitespace-nowrap">
              {line}
              <span className="text-saffron">✦</span>
            </span>
          ))}
        </div>
      </div>

      <div
        className={`border-b border-sand/70 transition-all duration-300 ${
          scrolled ? "bg-cream/95 backdrop-blur-md shadow-soft" : "bg-cream"
        }`}
      >
        <div className="mx-auto flex h-[68px] max-w-[1400px] items-center gap-4 px-4 sm:px-6 lg:px-10">
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-shell lg:hidden"
            aria-label="Open menu"
          >
            <MenuIcon width={20} height={20} />
          </button>

          <Link href="/" aria-label="OnlineKidz.Store home" className="flex shrink-0 items-center">
            <BrandLogo />
          </Link>

          <nav className="ml-6 hidden items-center gap-1 lg:flex">
            <div
              className="relative"
              onMouseEnter={() => setCollectionsOpen(true)}
              onMouseLeave={() => setCollectionsOpen(false)}
            >
              <button
                type="button"
                onClick={() => setCollectionsOpen((open) => !open)}
                className="flex items-center gap-1 rounded-full px-3.5 py-2 text-[13.5px] font-medium text-ink transition hover:bg-shell"
              >
                Collections
                <ChevronDownIcon
                  width={14}
                  height={14}
                  className={`transition-transform duration-300 ${collectionsOpen ? "rotate-180" : ""}`}
                />
              </button>
              <div
                className={`absolute left-0 top-full w-[540px] pt-2 transition-all duration-300 ${
                  collectionsOpen
                    ? "visible translate-y-0 opacity-100"
                    : "invisible -translate-y-1 opacity-0"
                }`}
              >
                <div className="grid grid-cols-2 gap-1 rounded-3xl border border-sand bg-white p-3 shadow-lift">
                  {categories.map((category) => (
                    <Link
                      key={category.slug}
                      href={`/collections/${category.slug}`}
                      className="flex items-center gap-3 rounded-2xl p-2.5 transition hover:bg-shell"
                    >
                      <span className="h-11 w-11 shrink-0 overflow-hidden rounded-xl bg-shell">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={category.image}
                          alt=""
                          className="h-full w-full object-cover"
                          loading="lazy"
                        />
                      </span>
                      <span className="min-w-0">
                        <span className="block truncate text-[13px] font-semibold text-ink">
                          {category.name}
                        </span>
                        <span className="block truncate text-[11px] text-ink-soft/75">
                          {category.tagline}
                        </span>
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-full px-3.5 py-2 text-[13.5px] font-medium text-ink transition hover:bg-shell"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-1">
            <button
              type="button"
              onClick={() => setSearchOpen((open) => !open)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-shell"
              aria-label="Search products"
            >
              <SearchIcon width={19} height={19} />
            </button>
            <Link
              href="/wishlist"
              className="relative hidden h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-shell sm:flex"
              aria-label={`Wishlist, ${wishlistCount} saved items`}
            >
              <HeartIcon width={19} height={19} />
              {hydrated && wishlistCount > 0 ? (
                <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand-pink px-1 text-[9px] font-bold text-white">
                  {wishlistCount}
                </span>
              ) : null}
            </Link>
            <Link
              href="/orders"
              className="hidden h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-shell sm:flex"
              aria-label="Track your order"
            >
              <UserIcon width={19} height={19} />
            </Link>
            <button
              type="button"
              onClick={openCart}
              className="relative ml-1 flex h-10 items-center gap-2 rounded-full bg-clay px-4 text-cream transition-all duration-300 hover:bg-clay-dark"
              aria-label={`Open basket, ${count} items`}
            >
              <BagIcon width={17} height={17} />
              <span className="text-[13px] font-semibold">Basket</span>
              <span
                className={`flex h-5 min-w-5 items-center justify-center rounded-full bg-cream px-1 text-[11px] font-bold text-ink transition-transform duration-300 ${
                  hydrated && count > 0 ? "scale-100" : "scale-0"
                }`}
              >
                {count}
              </span>
            </button>
          </div>
        </div>

        {searchOpen ? (
          <div className="relative z-20 border-t border-sand/70 bg-cream px-4 py-3 sm:px-6 lg:px-10">
            <div className="mx-auto max-w-[1400px]">
              <HomeSearch compact />
            </div>
          </div>
        ) : null}
      </div>

      {/* Mobile menu */}
      <div className={`fixed inset-0 z-[80] lg:hidden ${menuOpen ? "" : "pointer-events-none"}`}>
        <button
          type="button"
          aria-label="Close menu"
          onClick={() => setMenuOpen(false)}
          className={`absolute inset-0 bg-ink/45 backdrop-blur-[3px] transition-opacity duration-300 ${
            menuOpen ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          className={`absolute left-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto bg-cream p-5 shadow-lift transition-transform duration-[420ms] [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] ${
            menuOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-display text-lg text-ink">Menu</span>
            <button
              type="button"
              onClick={() => setMenuOpen(false)}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-sand"
              aria-label="Close menu"
            >
              <CloseIcon width={17} height={17} />
            </button>
          </div>
          <form onSubmit={submitSearch} className="mt-4">
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search the shop…"
              className="w-full rounded-full border border-sand bg-white px-4 py-2.5 text-sm outline-none focus:border-clay"
            />
          </form>
          <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.18em] text-ink-soft/60">
            Collections
          </p>
          <div className="mt-2 space-y-1">
            {categories.map((category) => (
              <Link
                key={category.slug}
                href={`/collections/${category.slug}`}
                className="flex items-center gap-3 rounded-2xl p-2 transition hover:bg-shell"
              >
                <span className="h-10 w-10 overflow-hidden rounded-xl bg-shell">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={category.image} alt="" className="h-full w-full object-cover" loading="lazy" />
                </span>
                <span className="text-sm font-medium text-ink">{category.name}</span>
              </Link>
            ))}
          </div>
          <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.18em] text-ink-soft/60">
            Explore
          </p>
          <div className="mt-2 space-y-1">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block rounded-2xl px-3 py-2.5 text-[15px] font-medium text-ink transition hover:bg-shell"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/wishlist"
              className="flex items-center justify-between rounded-2xl px-3 py-2.5 text-[15px] font-medium text-ink transition hover:bg-shell"
            >
              <span>Wishlist</span>
              {wishlistCount > 0 ? (
                <span className="rounded-full bg-brand-pink px-2 py-0.5 text-[11px] font-bold text-white">
                  {wishlistCount}
                </span>
              ) : null}
            </Link>
            <Link
              href="/orders"
              className="block rounded-2xl px-3 py-2.5 text-[15px] font-medium text-ink transition hover:bg-shell"
            >
              Track your order
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
