"use client";

import { useState } from "react";

/**
 * Official logo slot. Place the supplied artwork at:
 *   public/brand/onlinekidz-logo.png  (full logo, square)
 * Until the file exists, a colour-matched wordmark is shown instead.
 * The artwork is rendered with object-contain so it is never distorted.
 */
const LETTERS: { text: string; color: string }[] = [
  { text: "Online", color: "text-brand-blue" },
  { text: "K", color: "text-brand-pink" },
  { text: "i", color: "text-brand-green" },
  { text: "d", color: "text-brand-orange" },
  { text: "z", color: "text-brand-purple" },
  { text: ".", color: "text-brand-orange" },
  { text: "Store", color: "text-brand-green" },
];

export function BrandLogo({ size = "md" }: { size?: "sm" | "md" }) {
  const [failed, setFailed] = useState(false);
  const imgSize = size === "sm" ? "h-10 w-10" : "h-12 w-12";

  return (
    <span className="flex items-center gap-2">
      {!failed ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src="/brand/onlinekidz-logo.png"
          alt=""
          aria-hidden
          onError={() => setFailed(true)}
          className={`${imgSize} shrink-0 object-contain`}
        />
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img src="/brand/cart-mark.svg" alt="" aria-hidden className={`${imgSize} shrink-0`} />
      )}
      <span className="flex flex-col leading-none">
        <span className={`font-display font-bold tracking-tight ${size === "sm" ? "text-[17px]" : "text-[20px]"}`}>
          {LETTERS.map((part, index) => (
            <span key={index} className={part.color}>
              {part.text}
            </span>
          ))}
        </span>
        <span className="mt-1 hidden text-[9.5px] sm:block font-bold uppercase tracking-[0.18em] text-ink-soft">
          Happy Kids <span className="text-brand-pink">♥</span> Happy Parents
        </span>
      </span>
      <span className="sr-only">OnlineKidz.Store home</span>
    </span>
  );
}
