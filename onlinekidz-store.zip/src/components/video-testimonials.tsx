"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { ArrowRightIcon, PlayIcon } from "./icons";

const STORIES = [
  {
    title: "A calmer breakfast, one spoon at a time",
    theme: "First foods",
    product: "Sprouted Ragi Porridge Mix",
    href: "/product/sprouted-ragi-porridge-mix",
    video: "https://videos.pexels.com/video-files/8046396/8046396-hd_1080_1920_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8046396/adolescence-adult-affection-baby-8046396.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: "00:13",
    tint: "from-[#b65c39]/90",
  },
  {
    title: "The little moments we want to bottle",
    theme: "New parent days",
    product: "Cold-Pressed Baby Massage Oil",
    href: "/product/coconut-almond-baby-massage-oil",
    video: "https://videos.pexels.com/video-files/7652806/7652806-uhd_2160_3840_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/7652806/adorable-asian-baby-beautiful-7652806.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: "00:07",
    tint: "from-[#6d8f77]/90",
  },
  {
    title: "A little play goes a long way",
    theme: "Growing together",
    product: "Beechwood Stacking Rings",
    href: "/product/beechwood-stacking-rings-rattle",
    video: "https://videos.pexels.com/video-files/6392117/6392117-uhd_2160_3840_24fps.mp4",
    poster:
      "https://images.pexels.com/videos/6392117/pexels-photo-6392117.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: "00:10",
    tint: "from-[#8e3b5b]/90",
  },
  {
    title: "Bath time, without the hurry",
    theme: "Everyday rituals",
    product: "Tear-Free Milky Shampoo & Body Wash",
    href: "/product/tear-free-milky-shampoo-wash",
    video: "https://videos.pexels.com/video-files/6386613/6386613-uhd_2160_3840_24fps.mp4",
    poster:
      "https://images.pexels.com/videos/6386613/pexels-photo-6386613.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    duration: "00:10",
    tint: "from-[#2f6f6a]/90",
  },
];

export function VideoTestimonials() {
  const [playingIndex, setPlayingIndex] = useState<number | null>(null);
  const videos = useRef<Array<HTMLVideoElement | null>>([]);

  const play = (index: number) => {
    videos.current.forEach((video, videoIndex) => {
      if (video && videoIndex !== index) video.pause();
    });
    const video = videos.current[index];
    if (!video) return;
    if (playingIndex === index && !video.paused) {
      video.pause();
      setPlayingIndex(null);
      return;
    }
    setPlayingIndex(index);
    void video.play().catch(() => setPlayingIndex(null));
  };

  return (
    <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6 lg:px-10 lg:pb-24">
      <div className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
            Video testimonials · press play
          </p>
          <h2 className="mt-2 font-display text-[30px] leading-tight text-ink sm:text-[40px]">
            Little moments, told in their own way
          </h2>
        </div>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <p className="max-w-xl text-[14px] leading-relaxed text-ink-soft">
            A video-first place for the everyday wins — first tastes, gentler bath times and those
            tiny milestones that feel enormous. Preview clips are illustrative demo footage from
            Pexels; swap in your community&apos;s own stories before publishing real testimonials.
          </p>
          <Link
            href="/about#contact"
            className="group inline-flex shrink-0 items-center gap-2 text-[13px] font-semibold text-clay transition hover:text-ink"
          >
            Share your story
            <ArrowRightIcon width={15} height={15} className="transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>

      <div className="no-scrollbar mt-8 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-4">
        {STORIES.map((story, index) => {
          const isPlaying = playingIndex === index;
          return (
            <article
              key={story.title}
              className="group w-[min(72vw,248px)] shrink-0 snap-start overflow-hidden rounded-[1.7rem] border border-sand bg-white shadow-soft transition-all duration-500 hover:-translate-y-1 hover:shadow-lift sm:w-[260px]"
            >
              <div className="relative aspect-[9/14] overflow-hidden bg-ink">
                <video
                  ref={(node) => {
                    videos.current[index] = node;
                  }}
                  src={story.video}
                  poster={story.poster}
                  preload="none"
                  playsInline
                  controls={isPlaying}
                  onPlay={() => setPlayingIndex(index)}
                  onPause={() => setPlayingIndex((current) => (current === index ? null : current))}
                  onEnded={() => setPlayingIndex(null)}
                  aria-label={`${story.title} — illustrative demo video`}
                  className="absolute inset-0 h-full w-full object-cover"
                />
                {!isPlaying ? (
                  <button
                    type="button"
                    onClick={() => play(index)}
                    aria-label={`Play demo clip: ${story.title}`}
                    className="absolute inset-0 z-10 flex items-center justify-center bg-ink/10 transition-colors hover:bg-ink/25"
                  >
                    <span className="flex h-14 w-14 items-center justify-center rounded-full border border-white/70 bg-white/90 text-clay shadow-lift backdrop-blur transition-transform duration-300 group-hover:scale-110">
                      <PlayIcon width={23} height={23} className="ml-0.5" />
                    </span>
                  </button>
                ) : null}
                <span className="absolute left-3 top-3 z-20 rounded-full bg-ink/65 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.15em] text-white backdrop-blur">
                  Illustrative clip
                </span>
                {!isPlaying ? (
                  <>
                    <span className="pointer-events-none absolute inset-x-0 bottom-0 z-[5] h-40 bg-gradient-to-t from-ink/85 via-ink/25 to-transparent" />
                    <span className="pointer-events-none absolute bottom-4 left-4 z-[6] right-4">
                      <span className="block text-[9px] font-semibold uppercase tracking-[0.17em] text-saffron">
                        {story.theme}
                      </span>
                      <span className="mt-1.5 block font-display text-[17px] leading-snug text-white">
                        {story.title}
                      </span>
                      <span className="mt-2 block text-[10px] font-medium uppercase tracking-wider text-white/65">
                        {story.duration} · demo story
                      </span>
                    </span>
                  </>
                ) : null}
              </div>
              <div className="p-4">
                <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-ink-soft/65">
                  A product in the story
                </p>
                <Link
                  href={story.href}
                  className="mt-1 flex items-center justify-between gap-2 text-[13px] font-semibold leading-snug text-ink transition hover:text-clay"
                >
                  <span className="line-clamp-1">{story.product}</span>
                  <ArrowRightIcon width={14} height={14} className="shrink-0" />
                </Link>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
