"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { computeTotals, COUPONS } from "@/lib/format";
import { trackEvent } from "@/lib/analytics";

export type CartItem = {
  slug: string;
  name: string;
  image: string;
  price: number;
  compareAtPrice?: number | null;
  unitLabel?: string;
  variant?: string;
  quantity: number;
};

export type WishlistItem = {
  slug: string;
  name: string;
  image: string;
  price: number;
  compareAtPrice?: number | null;
  unitLabel?: string;
  brand: string;
  tagline: string;
  rating: number;
  reviewCount: number;
  ageMonthsMin: number;
  ageMonthsMax: number;
};

type Toast = { id: number; title: string; body?: string };

type CartContextValue = {
  items: CartItem[];
  hydrated: boolean;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addItem: (
    item: Omit<CartItem, "quantity">,
    quantity?: number,
    options?: { openCart?: boolean },
  ) => void;
  removeItem: (slug: string, variant?: string) => void;
  updateQuantity: (slug: string, quantity: number, variant?: string) => void;
  clearCart: () => void;
  count: number;
  wishlist: WishlistItem[];
  wishlistCount: number;
  isWishlisted: (slug: string) => boolean;
  toggleWishlist: (item: WishlistItem) => void;
  removeWishlistItem: (slug: string) => void;
  subtotal: number;
  coupon: string;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  discount: number;
  shipping: number;
  total: number;
  toasts: Toast[];
  pushToast: (title: string, body?: string) => void;
  dismissToast: (id: number) => void;
  recentlyAdded: string | null;
};

const STORAGE_KEY = "onlinekids.cart.v2";
const CartContext = createContext<CartContextValue | null>(null);
const keyOf = (slug: string, variant?: string) => `${slug}::${variant ?? ""}`;

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [coupon, setCoupon] = useState("");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [recentlyAdded, setRecentlyAdded] = useState<string | null>(null);
  const toastId = useRef(0);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as {
          items?: CartItem[];
          wishlist?: WishlistItem[];
          coupon?: string;
        };
        if (Array.isArray(parsed.items)) setItems(parsed.items);
        if (Array.isArray(parsed.wishlist)) setWishlist(parsed.wishlist);
        if (parsed.coupon) setCoupon(parsed.coupon);
      }
    } catch {
      /* Ignore malformed storage. */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ items, wishlist, coupon }));
    } catch {
      /* Storage may be unavailable in private browsing. */
    }
  }, [items, wishlist, coupon, hydrated]);

  useEffect(() => {
    if (!isOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  const dismissToast = useCallback((id: number) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const pushToast = useCallback(
    (title: string, body?: string) => {
      toastId.current += 1;
      const id = toastId.current;
      setToasts((current) => [...current.slice(-2), { id, title, body }]);
      window.setTimeout(() => dismissToast(id), 3400);
    },
    [dismissToast],
  );

  const addItem = useCallback(
    (
      item: Omit<CartItem, "quantity">,
      quantity = 1,
      options?: { openCart?: boolean },
    ) => {
      setItems((current) => {
        const id = keyOf(item.slug, item.variant);
        const index = current.findIndex((entry) => keyOf(entry.slug, entry.variant) === id);
        if (index >= 0) {
          const next = [...current];
          next[index] = { ...next[index], quantity: Math.min(20, next[index].quantity + quantity) };
          return next;
        }
        return [...current, { ...item, quantity }];
      });
      setRecentlyAdded(item.slug);
      window.setTimeout(() => setRecentlyAdded(null), 1600);
      if (options?.openCart !== false) setIsOpen(true);
      trackEvent("add_to_cart", item.slug, {
        quantity,
        unit_price: item.price,
        variant: item.variant ?? "",
      });
      pushToast("Added to your basket", item.name);
    },
    [pushToast],
  );

  const removeItem = useCallback((slug: string, variant?: string) => {
    const id = keyOf(slug, variant);
    setItems((current) => current.filter((entry) => keyOf(entry.slug, entry.variant) !== id));
  }, []);

  const updateQuantity = useCallback((slug: string, quantity: number, variant?: string) => {
    const id = keyOf(slug, variant);
    setItems((current) =>
      quantity <= 0
        ? current.filter((entry) => keyOf(entry.slug, entry.variant) !== id)
        : current.map((entry) =>
            keyOf(entry.slug, entry.variant) === id
              ? { ...entry, quantity: Math.min(20, quantity) }
              : entry,
          ),
    );
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
    setCoupon("");
  }, []);

  const isWishlisted = useCallback(
    (slug: string) => wishlist.some((item) => item.slug === slug),
    [wishlist],
  );

  const removeWishlistItem = useCallback((slug: string) => {
    setWishlist((current) => current.filter((item) => item.slug !== slug));
  }, []);

  const toggleWishlist = useCallback(
    (item: WishlistItem) => {
      const exists = wishlist.some((entry) => entry.slug === item.slug);
      if (exists) {
        setWishlist((current) => current.filter((entry) => entry.slug !== item.slug));
        pushToast("Removed from wishlist", item.name);
      } else {
        setWishlist((current) => [...current, item]);
        pushToast("Saved to your wishlist", item.name);
      }
    },
    [wishlist, pushToast],
  );

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.price * item.quantity, 0),
    [items],
  );
  const count = useMemo(() => items.reduce((sum, item) => sum + item.quantity, 0), [items]);
  const wishlistCount = wishlist.length;

  useEffect(() => {
    if (!hydrated) return;
    const handlePageHide = () => {
      if (count > 0) {
        trackEvent("cart_abandonment", undefined, {
          cart_count: count,
          cart_value: subtotal,
        });
      }
    };
    window.addEventListener("pagehide", handlePageHide);
    return () => window.removeEventListener("pagehide", handlePageHide);
  }, [hydrated, count, subtotal]);

  const applyCoupon = useCallback(
    (code: string) => {
      const key = code.trim().toUpperCase();
      if (COUPONS[key]) {
        setCoupon(key);
        pushToast("Coupon applied", COUPONS[key].label);
        return true;
      }
      pushToast("That code isn't valid", "Try LITTLE10 or MILLET200");
      return false;
    },
    [pushToast],
  );

  const removeCoupon = useCallback(() => setCoupon(""), []);
  const totals = useMemo(() => computeTotals(subtotal, coupon), [subtotal, coupon]);

  const value = useMemo<CartContextValue>(
    () => ({
      items,
      hydrated,
      isOpen,
      openCart: () => setIsOpen(true),
      closeCart: () => setIsOpen(false),
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      count,
      wishlist,
      wishlistCount,
      isWishlisted,
      toggleWishlist,
      removeWishlistItem,
      subtotal,
      coupon,
      applyCoupon,
      removeCoupon,
      discount: totals.discount,
      shipping: totals.shipping,
      total: totals.total,
      toasts,
      pushToast,
      dismissToast,
      recentlyAdded,
    }),
    [
      items,
      hydrated,
      isOpen,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      count,
      wishlist,
      wishlistCount,
      isWishlisted,
      toggleWishlist,
      removeWishlistItem,
      subtotal,
      coupon,
      applyCoupon,
      removeCoupon,
      totals.discount,
      totals.shipping,
      totals.total,
      toasts,
      pushToast,
      dismissToast,
      recentlyAdded,
    ],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside CartProvider");
  return context;
}
