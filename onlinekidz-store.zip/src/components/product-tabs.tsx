"use client";

import { useState, type ReactNode } from "react";

export function ProductTabs({
  tabs,
}: {
  tabs: { id: string; label: string; content: ReactNode }[];
}) {
  const [active, setActive] = useState(tabs[0]?.id);

  return (
    <section className="mt-14">
      <div className="flex gap-1 overflow-x-auto border-b border-sand no-scrollbar">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActive(tab.id)}
            className={`relative shrink-0 px-5 py-3.5 text-[14px] font-semibold transition-colors ${
              active === tab.id ? "text-ink" : "text-ink-soft/70 hover:text-ink"
            }`}
          >
            {tab.label}
            <span
              className={`absolute inset-x-2 -bottom-px h-[2px] rounded-full bg-clay transition-all duration-300 ${
                active === tab.id ? "opacity-100" : "opacity-0"
              }`}
            />
          </button>
        ))}
      </div>
      <div key={active} className="animate-fade-up pt-7">
        {tabs.find((tab) => tab.id === active)?.content}
      </div>
    </section>
  );
}
