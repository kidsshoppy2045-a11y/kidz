"use client";

import Link from "next/link";
import { useState } from "react";
import { FREE_SHIPPING_THRESHOLD, formatINR } from "@/lib/format";
import { useCart } from "./cart-context";
import { ArrowRightIcon, CheckIcon, CloseIcon, MinusIcon, PlusIcon, TruckIcon } from "./icons";

export function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    updateQuantity,
    removeItem,
    subtotal,
    count,
    discount,
    shipping,
    total,
    coupon,
    applyCoupon,
    removeCoupon,
  } = useCart();
  const [code, setCode] = useState("");

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - (subtotal - discount));
  const progress = Math.min(100, ((subtotal - discount) / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <div
      className={`fixed inset-0 z-[70] ${isOpen ? "" : "pointer-events-none"}`}
      aria-hidden={!isOpen}
    >
      <button
        type="button"
        tabIndex={isOpen ? 0 : -1}
        onClick={closeCart}
        aria-label="Close basket"
        className={`absolute inset-0 bg-ink/45 backdrop-blur-[3px] transition-opacity duration-400 ${
          isOpen ? "opacity-100" : "opacity-0"
        }`}
      />
      <aside
        role="dialog"
        aria-label="Shopping basket"
        className={`absolute right-0 top-0 flex h-full w-full max-w-[27rem] flex-col bg-cream shadow-lift transition-transform duration-[450ms] [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between border-b border-sand px-5 py-4">
          <div>
            <h2 className="font-display text-xl text-ink">Your basket</h2>
            <p className="text-xs text-ink-soft/70">
              {count === 0 ? "Nothing here yet" : `${count} item${count > 1 ? "s" : ""} reserved`}
            </p>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-sand text-ink transition hover:bg-shell"
            aria-label="Close basket"
          >
            <CloseIcon width={17} height={17} />
          </button>
        </header>

        {items.length > 0 ? (
          <div className="border-b border-sand bg-shell/60 px-5 py-3">
            <div className="flex items-center gap-2 text-xs text-ink-soft">
              <TruckIcon width={15} height={15} className="text-teal" />
              {remaining > 0 ? (
                <span>
                  Add <strong className="font-semibold text-ink">{formatINR(remaining)}</strong> for free
                  delivery
                </span>
              ) : (
                <span className="font-medium text-teal">Free delivery unlocked 🎉</span>
              )}
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-sand">
              <div
                className="h-full rounded-full bg-gradient-to-r from-saffron to-clay transition-[width] duration-700"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        ) : null}

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-shell text-3xl">
                🧺
              </div>
              <div>
                <p className="font-display text-lg text-ink">Your basket is empty</p>
                <p className="mt-1 max-w-[16rem] text-sm text-ink-soft/80">
                  Start with a jar of sprouted ragi or a soft pair of first walkers.
                </p>
              </div>
              <Link
                href="/shop"
                onClick={closeCart}
                className="inline-flex items-center gap-2 rounded-full bg-clay px-5 py-2.5 text-sm font-medium text-cream transition hover:bg-clay-dark"
              >
                Browse the shop <ArrowRightIcon width={16} height={16} />
              </Link>
            </div>
          ) : (
            <ul className="space-y-4">
              {items.map((item) => {
                const id = `${item.slug}::${item.variant ?? ""}`;
                return (
                  <li key={id} className="flex gap-3 rounded-2xl border border-sand/70 bg-white p-3">
                    <Link
                      href={`/product/${item.slug}`}
                      onClick={closeCart}
                      className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-shell"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover"
                        loading="lazy"
                      />
                    </Link>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <Link
                          href={`/product/${item.slug}`}
                          onClick={closeCart}
                          className="line-clamp-2 text-sm font-medium leading-snug text-ink hover:text-clay"
                        >
                          {item.name}
                        </Link>
                        <button
                          type="button"
                          onClick={() => removeItem(item.slug, item.variant)}
                          className="shrink-0 text-ink-soft/50 transition hover:text-clay"
                          aria-label={`Remove ${item.name}`}
                        >
                          <CloseIcon width={15} height={15} />
                        </button>
                      </div>
                      {item.variant ? (
                        <p className="text-[11px] text-ink-soft/70">{item.variant}</p>
                      ) : item.unitLabel ? (
                        <p className="text-[11px] text-ink-soft/70">{item.unitLabel}</p>
                      ) : null}
                      <div className="mt-auto flex items-center justify-between pt-2">
                        <div className="flex items-center gap-1 rounded-full border border-sand">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.slug, item.quantity - 1, item.variant)}
                            className="flex h-7 w-7 items-center justify-center rounded-full text-ink transition hover:bg-shell"
                            aria-label="Decrease quantity"
                          >
                            <MinusIcon width={13} height={13} />
                          </button>
                          <span className="w-5 text-center text-sm font-medium">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.slug, item.quantity + 1, item.variant)}
                            className="flex h-7 w-7 items-center justify-center rounded-full text-ink transition hover:bg-shell"
                            aria-label="Increase quantity"
                          >
                            <PlusIcon width={13} height={13} />
                          </button>
                        </div>
                        <span className="font-display text-base text-ink">
                          {formatINR(item.price * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {items.length > 0 ? (
          <footer className="border-t border-sand bg-white/70 px-5 py-4">
            {coupon ? (
              <div className="mb-3 flex items-center justify-between rounded-xl bg-sage/12 px-3 py-2 text-xs text-teal">
                <span className="inline-flex items-center gap-1.5 font-medium">
                  <CheckIcon width={14} height={14} /> {coupon} applied
                </span>
                <button type="button" onClick={removeCoupon} className="underline hover:text-clay">
                  remove
                </button>
              </div>
            ) : (
              <form
                className="mb-3 flex gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  if (applyCoupon(code)) setCode("");
                }}
              >
                <input
                  value={code}
                  onChange={(event) => setCode(event.target.value)}
                  placeholder="Coupon code (try LITTLE10)"
                  className="min-w-0 flex-1 rounded-xl border border-sand bg-cream px-3 py-2 text-xs outline-none transition focus:border-clay"
                />
                <button
                  type="submit"
                  className="rounded-xl border border-ink/15 px-3 py-2 text-xs font-medium text-ink transition hover:bg-shell"
                >
                  Apply
                </button>
              </form>
            )}

            <dl className="space-y-1.5 text-sm">
              <div className="flex justify-between text-ink-soft">
                <dt>Subtotal</dt>
                <dd className="font-medium text-ink">{formatINR(subtotal)}</dd>
              </div>
              {discount > 0 ? (
                <div className="flex justify-between text-teal">
                  <dt>Discount</dt>
                  <dd>-{formatINR(discount)}</dd>
                </div>
              ) : null}
              <div className="flex justify-between text-ink-soft">
                <dt>Delivery</dt>
                <dd className="font-medium text-ink">
                  {shipping === 0 ? "Free" : formatINR(shipping)}
                </dd>
              </div>
              <div className="flex items-baseline justify-between border-t border-sand pt-2 font-display text-lg text-ink">
                <dt>Total</dt>
                <dd>{formatINR(total)}</dd>
              </div>
            </dl>

            <Link
              href="/checkout"
              onClick={closeCart}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-clay px-6 py-3.5 text-sm font-semibold text-cream transition-all duration-300 hover:bg-clay-dark"
            >
              Checkout securely <ArrowRightIcon width={16} height={16} />
            </Link>
            <p className="mt-2 text-center text-[11px] text-ink-soft/70">
              Free 30-day returns · COD available · Ships in 24 hrs
            </p>
          </footer>
        ) : null}
      </aside>
    </div>
  );
}
