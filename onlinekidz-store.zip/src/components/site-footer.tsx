"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { trackEvent } from "@/lib/analytics";
import { BrandLogo } from "./brand-logo";
import { ArrowRightIcon, CheckIcon, LeafIcon, ShieldIcon, TruckIcon } from "./icons";

const COLUMNS = [
  {
    title: "Shop",
    links: [
      { label: "Organic foods & millets", href: "/collections/organic-foods" },
      { label: "Baby care", href: "/collections/baby-care" },
      { label: "Diapers & wipes", href: "/collections/diapers" },
      { label: "Toys & play", href: "/collections/toys" },
      { label: "Clothing", href: "/collections/clothes" },
      { label: "Footwear", href: "/collections/footwear" },
    ],
  },
  {
    title: "For parents",
    links: [
      { label: "Mother & maternity", href: "/collections/mother-care" },
      { label: "Bestsellers", href: "/shop?tag=bestsellers" },
      { label: "New arrivals", href: "/shop?tag=new" },
      { label: "Gift hampers", href: "/shop?q=gift" },
      { label: "Parent journal", href: "/blog" },
      { label: "Our story", href: "/about" },
    ],
  },
  {
    title: "Help",
    links: [
      { label: "Track your order", href: "/orders" },
      { label: "Shipping & returns", href: "/about#shipping" },
      { label: "Feeding guide", href: "/about#feeding" },
      { label: "Contact us", href: "/about#contact" },
      { label: "FAQs", href: "/about#faq" },
    ],
  },
];

export function SiteFooter() {
  const pathname = usePathname();
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!email.includes("@")) return;
    setState("loading");
    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!response.ok) throw new Error("Signup failed");
      trackEvent("newsletter_signup");
      setState("done");
      setEmail("");
    } catch {
      setState("error");
    }
  };

  if (pathname?.startsWith("/admin")) return null;

  return (
    <footer className="mt-24 border-t border-sand bg-shell/70">
      <div className="mx-auto max-w-[1400px] px-4 py-14 sm:px-6 lg:px-10">
        <div className="grid gap-10 rounded-3xl border border-sand bg-white p-7 shadow-soft lg:grid-cols-[1.1fr_1.4fr] lg:p-10">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-clay">
              Join the family
            </p>
            <h3 className="mt-2 font-display text-2xl leading-snug text-ink sm:text-[28px]">
              Weekly feeding guides, recipes & 10% off your first order
            </h3>
            <p className="mt-2 max-w-md text-sm text-ink-soft/85">
              One thoughtful email a week from our paediatric nutritionist — weaning charts, millet
              recipes and honest product advice. No spam, ever.
            </p>
            {state === "done" ? (
              <p className="mt-5 inline-flex items-center gap-2 rounded-full bg-sage/15 px-4 py-2.5 text-sm font-medium text-teal">
                <CheckIcon width={16} height={16} /> You&apos;re in! Use LITTLE10 for 10% off.
              </p>
            ) : (
              <>
              <form onSubmit={submit} className="mt-5 flex max-w-md gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@email.com"
                  className="min-w-0 flex-1 rounded-full border border-sand bg-cream px-5 py-3 text-sm outline-none transition focus:border-clay"
                />
                <button
                  type="submit"
                  disabled={state === "loading"}
                  className="inline-flex items-center gap-2 rounded-full bg-clay px-5 py-3 text-sm font-semibold text-cream transition hover:bg-clay-dark disabled:opacity-60"
                >
                  {state === "loading" ? "Joining…" : "Join"}
                  <ArrowRightIcon width={16} height={16} />
                </button>
              </form>
              {state === "error" ? (
                <p role="alert" className="mt-2 text-[12px] font-medium text-clay">
                  We couldn&apos;t save your signup just now. Please try again.
                </p>
              ) : null}
              </>
            )}
            <p className="mt-2 text-[10.5px] leading-relaxed text-ink-soft/65">
              By joining, you agree to receive OnlineKidz email updates. We use your address only for
              these updates and never sell it.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3">
            {COLUMNS.map((column) => (
              <div key={column.title}>
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ink-soft/70">
                  {column.title}
                </p>
                <ul className="mt-3 space-y-2">
                  {column.links.map((link) => (
                    <li key={link.href + link.label}>
                      <Link
                        href={link.href}
                        className="text-[13px] text-ink-soft transition hover:text-clay"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {[
            { icon: TruckIcon, title: "Ships in 24 hours", body: "Delivered across India in 2–5 days" },
            { icon: LeafIcon, title: "Clean labels", body: "No preservatives, no added sugar, no talc" },
            { icon: ShieldIcon, title: "Free 30-day returns", body: "Unopened packs, no questions asked" },
          ].map((item) => (
            <div
              key={item.title}
              className="flex items-start gap-3 rounded-2xl border border-sand/80 bg-cream p-4"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-clay shadow-soft">
                <item.icon width={19} height={19} />
              </span>
              <div>
                <p className="text-sm font-semibold text-ink">{item.title}</p>
                <p className="text-xs text-ink-soft/80">{item.body}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-sand pt-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5">
            <BrandLogo size="sm" />
            <p className="text-xs text-ink-soft/80">
              © {new Date().getFullYear()} OnlineKidz.Store · Made with care in Coorg & Bagru, India
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {["UPI", "Visa", "Mastercard", "RuPay", "COD", "Net banking"].map((method) => (
              <span
                key={method}
                className="rounded-lg border border-sand bg-white px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-ink-soft/80"
              >
                {method}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
