"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { FREE_SHIPPING_THRESHOLD, formatINR } from "@/lib/format";
import { trackEvent } from "@/lib/analytics";
import { useCart } from "./cart-context";
import { BagIcon, CheckIcon, CloseIcon, HeartIcon, MinusIcon, PlusIcon, TruckIcon } from "./icons";

type SizeGuide = { title: string; notes: string[] };

function guideFor(categorySlug: string): SizeGuide {
  if (categorySlug === "footwear") {
    return {
      title: "First walker fit guide",
      notes: [
        "Measure both feet while your child is standing, from the back of the heel to the longest toe.",
        "Leave about a thumb's width of growing room; toes should still move freely.",
        "Little feet grow quickly. Recheck the fit every 6–8 weeks and use the size selector as a starting point.",
      ],
    };
  }
  if (categorySlug === "diapers") {
    return {
      title: "Diaper size guide",
      notes: [
        "Choose by your baby's current weight range on the pack, not age alone.",
        "A snug fit should leave room for two fingers at the waistband without red marks.",
        "If leaks or tight leg marks persist, try the next size up.",
      ],
    };
  }
  return {
    title: "Clothing fit guide",
    notes: [
      "Age ranges are a starting point; babies and children grow at their own pace.",
      "For a more reliable fit, measure height and chest and compare with the garment label.",
      "If your child is between sizes or you prefer room to grow, choose the larger size.",
    ],
  };
}

export function ProductPurchase({
  slug,
  name,
  image,
  price,
  compareAtPrice,
  unitLabel,
  variants,
  inStock,
  brand,
  tagline,
  rating,
  reviewCount,
  ageMonthsMin,
  ageMonthsMax,
  categorySlug,
}: {
  slug: string;
  name: string;
  image: string;
  price: number;
  compareAtPrice?: number | null;
  unitLabel: string;
  variants: string[];
  inStock: boolean;
  brand: string;
  tagline: string;
  rating: number;
  reviewCount: number;
  ageMonthsMin: number;
  ageMonthsMax: number;
  categorySlug: string;
}) {
  const { addItem, toggleWishlist, isWishlisted } = useCart();
  const saved = isWishlisted(slug);
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const defaultVariant = variants.find((option) => {
    const sizeLabel = option.split("·")[0].trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    const productSlug = slug.toLowerCase().replace(/[^a-z0-9]/g, "");
    return sizeLabel.length > 2 && productSlug.includes(sizeLabel);
  });
  const [variant, setVariant] = useState(defaultVariant ?? variants[0] ?? "");
  const [pincode, setPincode] = useState("");
  const [eta, setEta] = useState<string | null>(null);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const [stickyVisible, setStickyVisible] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [ctaVariant, setCtaVariant] = useState<"control" | "test">("control");
  const actionLocked = useRef(false);
  const primaryButtonRef = useRef<HTMLButtonElement | null>(null);
  const sizeGuide = guideFor(categorySlug);

  const payload = {
    slug,
    name,
    image,
    price,
    compareAtPrice,
    unitLabel,
    variant: variant || undefined,
  };

  useEffect(() => {
    const experimentKey = "onlinekids.pdp-add-cta.v1";
    let assigned: "control" | "test" = "control";
    try {
      const savedVariant = window.localStorage.getItem(experimentKey);
      if (savedVariant === "control" || savedVariant === "test") {
        assigned = savedVariant;
      } else {
        assigned = Math.random() < 0.5 ? "control" : "test";
        window.localStorage.setItem(experimentKey, assigned);
      }
    } catch {
      assigned = "control";
    }
    setCtaVariant(assigned);
    trackEvent("experiment_impression", slug, {
      experiment: "pdp-add-cta-v1",
      cta_variant: assigned,
    });
  }, [slug]);

  useEffect(() => {
    const target = primaryButtonRef.current;
    if (!target || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(
      ([entry]) => setStickyVisible(!entry.isIntersecting),
      { threshold: 0.12 },
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!sizeGuideOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSizeGuideOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [sizeGuideOpen]);

  const acquireActionLock = () => {
    if (!inStock || actionLocked.current) return false;
    actionLocked.current = true;
    setIsAdding(true);
    window.setTimeout(() => {
      actionLocked.current = false;
      setIsAdding(false);
    }, 800);
    return true;
  };

  const addToBasket = (placement: "pdp-primary" | "mobile-sticky") => {
    if (!acquireActionLock()) return;
    trackEvent("cta_click", slug, {
      placement,
      experiment: "pdp-add-cta-v1",
      cta_variant: ctaVariant,
      cta_label: ctaVariant === "control" ? "Add to basket" : "Add my pick",
    });
    addItem(payload, quantity);
  };

  const buyNow = () => {
    if (!acquireActionLock()) return;
    trackEvent("cta_click", slug, { placement: "buy-now", cta_label: "Buy it now" });
    trackEvent("buy_now", slug, { quantity, unit_price: price, variant });
    addItem(payload, quantity, { openCart: false });
    router.push("/checkout");
  };

  const checkPincode = (event: React.FormEvent) => {
    event.preventDefault();
    const code = pincode.trim();
    if (!/^\d{6}$/.test(code)) {
      setEta("Enter a valid 6-digit pincode");
      return;
    }
    const metro = ["1", "4", "5", "6"].includes(code[0]);
    setEta(
      metro
        ? `Delivers by ${new Date(Date.now() + 2 * 86400000).toLocaleDateString("en-IN", {
            weekday: "short",
            day: "numeric",
            month: "short",
          })} · Free`
        : `Delivers by ${new Date(Date.now() + 5 * 86400000).toLocaleDateString("en-IN", {
            weekday: "short",
            day: "numeric",
            month: "short",
          })} · Free`,
    );
  };

  const ctaLabel = ctaVariant === "control" ? "Add to basket" : "Add my pick";
  const ctaTone = ctaVariant === "control" ? "bg-clay hover:bg-clay-dark" : "bg-clay-dark hover:bg-clay";

  return (
    <>
      <div className="space-y-5">
        {variants.length > 0 ? (
          <div>
            <div className="flex items-center justify-between gap-3">
              <p className="text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-soft/75">
                Choose size
              </p>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(true)}
                className="text-[12px] font-semibold text-clay underline underline-offset-2 hover:text-ink"
              >
                Size guide
              </button>
            </div>
            <div className="mt-2 flex items-center justify-between">
              <span className="text-[12px] text-ink-soft/70">Selected</span>
              <span className="text-[12px] font-medium text-clay">{variant}</span>
            </div>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {variants.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setVariant(option)}
                  aria-pressed={variant === option}
                  className={`rounded-xl border px-3.5 py-2 text-[13px] font-medium transition-all duration-200 ${
                    variant === option
                      ? "border-ink bg-ink text-cream"
                      : "border-sand bg-white text-ink hover:border-clay"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        ) : null}

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 rounded-full border border-sand bg-white p-1">
            <button
              type="button"
              onClick={() => setQuantity((current) => Math.max(1, current - 1))}
              className="flex h-9 w-9 items-center justify-center rounded-full text-ink transition hover:bg-shell"
              aria-label="Decrease quantity"
            >
              <MinusIcon width={15} height={15} />
            </button>
            <span aria-live="polite" className="w-7 text-center text-sm font-semibold">
              {quantity}
            </span>
            <button
              type="button"
              onClick={() => setQuantity((current) => Math.min(20, current + 1))}
              className="flex h-9 w-9 items-center justify-center rounded-full text-ink transition hover:bg-shell"
              aria-label="Increase quantity"
            >
              <PlusIcon width={15} height={15} />
            </button>
          </div>

          <button
            ref={primaryButtonRef}
            type="button"
            disabled={!inStock || isAdding}
            onClick={() => addToBasket("pdp-primary")}
            className={`group inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-full px-5 py-3.5 text-[14px] font-semibold text-white shadow-soft transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-50 ${ctaTone}`}
          >
            <BagIcon width={17} height={17} />
            {isAdding ? "Added" : inStock ? `${ctaLabel} · ${formatINR(price * quantity)}` : "Out of stock"}
          </button>
          <button
            type="button"
            onClick={() =>
              toggleWishlist({
                slug,
                name,
                image,
                price,
                compareAtPrice,
                unitLabel,
                brand,
                tagline,
                rating,
                reviewCount,
                ageMonthsMin,
                ageMonthsMax,
              })
            }
            aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
            aria-pressed={saved}
            title={saved ? "Remove from wishlist" : "Save to wishlist"}
            className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full border transition-all duration-300 hover:scale-105 active:scale-95 ${
              saved
                ? "border-brand-pink bg-brand-pink text-white"
                : "border-sand bg-white text-ink hover:border-brand-pink hover:text-brand-pink"
            }`}
          >
            <HeartIcon filled={saved} width={19} height={19} />
          </button>
        </div>

        <button
          type="button"
          disabled={!inStock || isAdding}
          onClick={buyNow}
          className="w-full rounded-full border border-ink/15 bg-white px-6 py-3.5 text-[15px] font-semibold text-ink transition hover:border-clay hover:text-clay disabled:cursor-not-allowed disabled:opacity-50"
        >
          Buy it now · {formatINR(price * quantity)}
        </button>

        <form onSubmit={checkPincode} className="rounded-2xl border border-sand bg-white p-4">
          <div className="flex items-center gap-2 text-[13px] font-semibold text-ink">
            <TruckIcon width={16} height={16} className="text-teal" /> Check delivery
          </div>
          <div className="mt-2.5 flex gap-2">
            <input
              value={pincode}
              onChange={(event) => setPincode(event.target.value)}
              inputMode="numeric"
              maxLength={6}
              placeholder="6-digit pincode"
              className="min-w-0 flex-1 rounded-xl border border-sand bg-cream px-3 py-2.5 text-sm outline-none transition focus:border-clay"
            />
            <button
              type="submit"
              className="rounded-xl border border-ink/15 px-4 py-2.5 text-[13px] font-semibold text-ink transition hover:bg-shell"
            >
              Check
            </button>
          </div>
          {eta ? (
            <p className="mt-2.5 inline-flex items-center gap-1.5 text-[12.5px] font-medium text-teal" role="status">
              <CheckIcon width={13} height={13} /> {eta}
            </p>
          ) : (
            <p className="mt-2.5 text-[12.5px] text-ink-soft/80">
              Free delivery on orders above {formatINR(FREE_SHIPPING_THRESHOLD)} · COD available
            </p>
          )}
        </form>
      </div>

      {stickyVisible ? (
        <div className="fixed inset-x-0 bottom-0 z-[45] border-t border-sand bg-cream/95 px-4 pt-3 pb-[calc(env(safe-area-inset-bottom)+0.75rem)] shadow-lift backdrop-blur sm:hidden animate-fade-up">
          <div className="mx-auto flex max-w-lg items-center gap-3">
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[11px] font-medium text-ink-soft">{name}</span>
              <span className="block font-display text-lg leading-tight text-ink">
                {formatINR(price * quantity)}
              </span>
            </span>
            <button
              type="button"
              disabled={!inStock || isAdding}
              onClick={() => addToBasket("mobile-sticky")}
              className={`inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-full px-5 text-[13px] font-semibold text-white shadow-soft transition disabled:opacity-50 ${ctaTone}`}
            >
              <BagIcon width={15} height={15} />
              {isAdding ? "Added" : ctaLabel}
            </button>
          </div>
        </div>
      ) : null}

      {sizeGuideOpen ? (
        <div className="fixed inset-0 z-[85] flex items-end justify-center bg-ink/45 p-3 backdrop-blur-[3px] sm:items-center sm:p-6">
          <button
            type="button"
            aria-label="Close size guide"
            onClick={() => setSizeGuideOpen(false)}
            className="absolute inset-0"
          />
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="size-guide-title"
            className="relative z-10 w-full max-w-md rounded-3xl border border-sand bg-cream p-6 shadow-lift animate-fade-up"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-clay">Fit help</p>
                <h2 id="size-guide-title" className="mt-1 font-display text-2xl text-ink">
                  {sizeGuide.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(false)}
                aria-label="Close size guide"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-sand bg-white"
              >
                <CloseIcon width={16} height={16} />
              </button>
            </div>
            <ul className="mt-4 space-y-3">
              {sizeGuide.notes.map((note) => (
                <li key={note} className="flex gap-2.5 text-[13.5px] leading-relaxed text-ink-soft">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-clay" />
                  {note}
                </li>
              ))}
            </ul>
            <p className="mt-4 rounded-xl bg-shell px-3.5 py-3 text-[11.5px] leading-relaxed text-ink-soft">
              Need help choosing? Contact our parent-support team before ordering.
            </p>
          </section>
        </div>
      ) : null}
    </>
  );
}
