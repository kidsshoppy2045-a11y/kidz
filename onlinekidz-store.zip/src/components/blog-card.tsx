import type { BlogPost } from "@/lib/blog-data";
import { TrackedLink } from "./tracked-link";
import { formatDate } from "@/lib/format";
import { ArrowRightIcon } from "./icons";

export function BlogCard({ post, featured = false }: { post: BlogPost; featured?: boolean }) {
  return (
    <article
      className={`group card-lift overflow-hidden rounded-3xl border border-sand/80 bg-white shadow-soft ${
        featured ? "lg:grid lg:grid-cols-[1.12fr_1fr]" : "flex h-full flex-col"
      }`}
    >
      <TrackedLink
        href={`/blog/${post.slug}`}
        eventName="article_click"
        metadata={{ article_slug: post.slug, placement: featured ? "featured-image" : "article-card-image" }}
        className={`relative block overflow-hidden bg-shell ${featured ? "aspect-[4/3] lg:aspect-auto" : "aspect-[1.38]"}`}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={post.heroImage}
          alt={post.title}
          className="h-full w-full object-cover transition-transform duration-[900ms] group-hover:scale-[1.05]"
          loading={featured ? "eager" : "lazy"}
          fetchPriority={featured ? "high" : "auto"}
        />
        <span className="absolute left-3 top-3 rounded-full bg-cream/90 px-3 py-1.5 text-[9px] font-semibold uppercase tracking-[0.15em] text-clay backdrop-blur">
          {post.category}
        </span>
      </TrackedLink>
      <div className={`flex flex-1 flex-col p-5 sm:p-6 ${featured ? "lg:justify-center lg:p-8" : ""}`}>
        <div className="flex items-center gap-2 text-[10.5px] font-semibold uppercase tracking-[0.13em] text-ink-soft/65">
          <span>{formatDate(post.publishedAt)}</span>
          {post.updatedAt && post.updatedAt.getTime() > post.publishedAt.getTime() ? (
            <>
              <span className="h-1 w-1 rounded-full bg-saffron" />
              <span>Updated {formatDate(post.updatedAt)}</span>
            </>
          ) : null}
          <span className="h-1 w-1 rounded-full bg-saffron" />
          <span>{post.readingMinutes} min read</span>
        </div>
        <h3 className={`mt-2 font-display leading-snug text-ink ${featured ? "text-[24px] sm:text-[30px]" : "text-[19px]"}`}>
          <TrackedLink
            href={`/blog/${post.slug}`}
            eventName="article_click"
            metadata={{ article_slug: post.slug, placement: "article-card-title" }}
            className="transition hover:text-clay"
          >
            {post.title}
          </TrackedLink>
        </h3>
        <p className={`mt-2.5 text-[13.5px] leading-relaxed text-ink-soft/90 ${featured ? "line-clamp-4" : "line-clamp-3"}`}>
          {post.excerpt}
        </p>
        <div className="mt-auto flex items-center justify-between gap-3 pt-5">
          <span className="line-clamp-1 text-[11px] font-medium text-ink-soft" title={post.author}>By {post.author}</span>
          <TrackedLink
            href={`/blog/${post.slug}`}
            eventName="article_click"
            metadata={{ article_slug: post.slug, placement: "article-card-cta" }}
            className="inline-flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-[0.12em] text-clay transition hover:text-ink"
          >
            Read story <ArrowRightIcon width={14} height={14} />
          </TrackedLink>
        </div>
      </div>
    </article>
  );
}
