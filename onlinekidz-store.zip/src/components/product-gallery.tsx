"use client";

import { useRef, useState } from "react";
import { PlayIcon } from "./icons";

type ProductDemoVideo = {
  src: string;
  poster: string;
  title: string;
};

export function ProductGallery({
  images,
  name,
  badge,
  demoVideo,
}: {
  images: string[];
  name: string;
  badge?: string | null;
  demoVideo?: ProductDemoVideo;
}) {
  const [index, setIndex] = useState(0);
  const [videoActive, setVideoActive] = useState(false);
  const [zoom, setZoom] = useState({ active: false, x: 50, y: 50 });
  const frame = useRef<HTMLDivElement | null>(null);
  const list = images.length > 0 ? images : ["/images/hero.jpg"];

  const onMove = (event: React.MouseEvent) => {
    if (videoActive) return;
    const node = frame.current;
    if (!node) return;
    const rect = node.getBoundingClientRect();
    setZoom({
      active: true,
      x: ((event.clientX - rect.left) / rect.width) * 100,
      y: ((event.clientY - rect.top) / rect.height) * 100,
    });
  };

  const selectImage = (imageIndex: number) => {
    setVideoActive(false);
    setIndex(imageIndex);
  };

  return (
    <div className="lg:flex lg:gap-4">
      <div className="order-2 mt-3 flex gap-3 overflow-x-auto pb-1 no-scrollbar lg:order-1 lg:mt-0 lg:flex-col lg:overflow-visible">
        {list.map((image, imageIndex) => (
          <button
            key={`${image}-${imageIndex}`}
            type="button"
            onMouseEnter={() => selectImage(imageIndex)}
            onFocus={() => selectImage(imageIndex)}
            onClick={() => selectImage(imageIndex)}
            className={`relative h-[68px] w-[68px] shrink-0 overflow-hidden rounded-2xl border-2 bg-shell transition-all duration-300 lg:h-[86px] lg:w-[86px] ${
              !videoActive && index === imageIndex
                ? "border-clay shadow-soft"
                : "border-transparent opacity-70 hover:opacity-100"
            }`}
            aria-label={`View image ${imageIndex + 1} of ${name}`}
            aria-pressed={!videoActive && index === imageIndex}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={image} alt="" className="h-full w-full object-cover" loading="lazy" />
          </button>
        ))}

        {demoVideo ? (
          <button
            type="button"
            onMouseEnter={() => setVideoActive(true)}
            onFocus={() => setVideoActive(true)}
            onClick={() => setVideoActive(true)}
            className={`relative h-[68px] w-[68px] shrink-0 overflow-hidden rounded-2xl border-2 bg-ink transition-all duration-300 lg:h-[86px] lg:w-[86px] ${
              videoActive ? "border-clay shadow-soft" : "border-transparent opacity-75 hover:opacity-100"
            }`}
            aria-label={`Watch illustrative demo: ${demoVideo.title}`}
            aria-pressed={videoActive}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={demoVideo.poster} alt="" className="h-full w-full object-cover" loading="lazy" />
            <span className="absolute inset-0 flex items-center justify-center bg-ink/20 text-white">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/90 text-clay shadow-soft">
                <PlayIcon width={13} height={13} className="ml-0.5" />
              </span>
            </span>
            <span className="absolute inset-x-0 bottom-0 bg-ink/70 py-0.5 text-center text-[8px] font-semibold uppercase tracking-widest text-white">
              Video
            </span>
          </button>
        ) : null}
      </div>

      <div className="order-1 flex-1 lg:order-2">
        <div
          ref={frame}
          onMouseMove={onMove}
          onMouseLeave={() => setZoom((current) => ({ ...current, active: false }))}
          className="group relative aspect-square overflow-hidden rounded-[2rem] border border-sand bg-shell shadow-soft"
        >
          {videoActive && demoVideo ? (
            <div className="absolute inset-0 bg-ink">
              <video
                key={demoVideo.src}
                controls
                playsInline
                preload="none"
                poster={demoVideo.poster}
                aria-label={`${demoVideo.title} — illustrative category demo footage`}
                className="h-full w-full object-cover"
              >
                <source src={demoVideo.src} type="video/mp4" />
                Your browser does not support embedded video.
              </video>
              <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-ink/75 px-3 py-1.5 text-[9px] font-semibold uppercase tracking-[0.15em] text-white backdrop-blur">
                Illustrative category demo · Pexels
              </span>
              <button
                type="button"
                onClick={() => setVideoActive(false)}
                className="absolute right-3 top-3 rounded-full bg-ink/75 px-3 py-1.5 text-[10px] font-semibold text-white backdrop-blur transition hover:bg-clay"
              >
                Back to photos
              </button>
            </div>
          ) : (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                key={list[index]}
                src={list[index]}
                alt={name}
                className="h-full w-full animate-fade-in object-cover transition-transform duration-500"
                style={{
                  transform: zoom.active ? "scale(1.6)" : "scale(1)",
                  transformOrigin: `${zoom.x}% ${zoom.y}%`,
                }}
              />
              {badge ? (
                <span className="absolute left-4 top-4 rounded-full bg-ink/90 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-cream backdrop-blur">
                  {badge}
                </span>
              ) : null}
              <span className="pointer-events-none absolute bottom-4 right-4 rounded-full bg-white/85 px-3 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.14em] text-ink-soft opacity-0 backdrop-blur transition-opacity duration-300 group-hover:opacity-100">
                Hover to zoom
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
