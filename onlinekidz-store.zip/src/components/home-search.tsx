"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useId, useState } from "react";
import { trackEvent } from "@/lib/analytics";
import { formatINR } from "@/lib/format";
import { ArrowRightIcon, SearchIcon } from "./icons";

type Suggestion = {
  slug: string;
  name: string;
  image: string;
  price: number;
  categorySlug: string;
  tagline: string;
};

const QUICK_SEARCHES = ["ragi porridge", "diapers", "wooden toys"];

export function HomeSearch({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const inputId = useId();
  const listId = `product-suggestions-${inputId}`;
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const term = query.trim();
    if (!open || term.length < 2) {
      setSuggestions([]);
      setLoading(false);
      return;
    }

    let active = true;
    const timer = window.setTimeout(async () => {
      setLoading(true);
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(term)}`, {
          cache: "no-store",
        });
        const data = (await response.json()) as { products?: Suggestion[] };
        if (active) setSuggestions(data.products ?? []);
      } catch {
        if (active) setSuggestions([]);
      } finally {
        if (active) setLoading(false);
      }
    }, 220);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [query, open]);

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const term = query.trim();
    if (!term) return;
    trackEvent("site_search", undefined, { term_length: term.length });
    setOpen(false);
    router.push(`/shop?q=${encodeURIComponent(term)}`);
  };

  return (
    <div className={compact ? "w-full" : "mt-6 max-w-xl"}>
      <form onSubmit={submit} className="relative z-20">
        <label htmlFor={inputId} className="sr-only">Search baby, kids and mother essentials</label>
        <div className="flex overflow-hidden rounded-full border border-sand bg-white shadow-soft transition focus-within:border-clay focus-within:shadow-lift">
          <SearchIcon
            width={19}
            height={19}
            className="ml-4 mt-3.5 shrink-0 text-ink-soft/55"
            aria-hidden
          />
          <input
            id={inputId}
            role="combobox"
            aria-autocomplete="list"
            aria-expanded={open && suggestions.length > 0}
            aria-controls={listId}
            value={query}
            onFocus={() => setOpen(true)}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Escape") setOpen(false);
            }}
            placeholder="Search ragi, diapers, toys…"
            className="min-w-0 flex-1 bg-transparent px-3 py-3.5 text-[13.5px] text-ink outline-none placeholder:text-ink-soft/50 sm:text-sm"
          />
          <button
            type="submit"
            className="m-1.5 inline-flex shrink-0 items-center gap-2 rounded-full bg-clay px-4 py-2.5 text-[12.5px] font-semibold text-white transition hover:bg-clay-dark sm:px-5"
          >
            Search <ArrowRightIcon width={14} height={14} />
          </button>
        </div>

        {open && query.trim().length >= 2 ? (
          <div
            id={listId}
            role="listbox"
            aria-label="Product suggestions"
            className="absolute left-0 right-0 top-full mt-2 overflow-hidden rounded-2xl border border-sand bg-white shadow-lift"
          >
            {loading ? (
              <p className="px-4 py-3 text-[13px] text-ink-soft">Finding thoughtful picks…</p>
            ) : suggestions.length > 0 ? (
              <>
                {suggestions.map((product) => (
                  <Link
                    key={product.slug}
                    href={`/product/${product.slug}`}
                    role="option"
                    aria-selected={false}
                    onClick={() => {
                      trackEvent("product_click", product.slug, { placement: "home-search" });
                      setOpen(false);
                    }}
                    className="flex items-center gap-3 border-b border-sand/70 px-3 py-2.5 transition last:border-0 hover:bg-shell"
                  >
                    <span className="h-11 w-11 shrink-0 overflow-hidden rounded-xl bg-shell">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={product.image} alt="" className="h-full w-full object-cover" loading="lazy" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-semibold text-ink">{product.name}</span>
                      <span className="block truncate text-[11px] text-ink-soft/70">{product.tagline}</span>
                    </span>
                    <span className="text-[12px] font-semibold text-clay">{formatINR(product.price)}</span>
                  </Link>
                ))}
                <button
                  type="submit"
                  className="w-full bg-shell/60 px-4 py-2.5 text-left text-[12px] font-semibold text-ink-soft transition hover:bg-shell"
                >
                  See all results for “{query.trim()}” →
                </button>
              </>
            ) : (
              <p className="px-4 py-3 text-[13px] text-ink-soft">No exact matches. Try a product or category name.</p>
            )}
          </div>
        ) : null}
      </form>
      {!compact ? (
        <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[11px] text-ink-soft/70">
          <span className="font-semibold uppercase tracking-[0.12em]">Try</span>
          {QUICK_SEARCHES.map((term) => (
            <button
              key={term}
              type="button"
              onClick={() => {
                setQuery(term);
                setOpen(true);
              }}
              className="rounded-full border border-sand bg-white/65 px-2.5 py-1 transition hover:border-clay hover:text-clay"
            >
              {term}
            </button>
          ))}
        </div>
      ) : null}
      {open ? <button aria-label="Close search suggestions" onClick={() => setOpen(false)} className="fixed inset-0 z-10 cursor-default" /> : null}
    </div>
  );
}
