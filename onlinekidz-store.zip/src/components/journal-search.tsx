"use client";

import { trackEvent } from "@/lib/analytics";
import { SearchIcon } from "./icons";

export function JournalSearch({ query = "", category }: { query?: string; category?: string }) {
  return (
    <form
      action="/blog"
      method="get"
      role="search"
      onSubmit={(event) => {
        const term = queryFromForm(event.currentTarget);
        if (term) trackEvent("site_search", undefined, { placement: "journal", term_length: term.length });
      }}
      className="relative mt-6 flex max-w-2xl items-center gap-2 rounded-full border border-sand bg-white p-1.5 shadow-soft transition focus-within:border-clay focus-within:shadow-lift"
    >
      <label htmlFor="journal-search" className="sr-only">Search journal articles</label>
      <SearchIcon width={18} height={18} className="ml-3 shrink-0 text-ink-soft/55" aria-hidden />
      <input
        id="journal-search"
        type="search"
        name="q"
        defaultValue={query}
        placeholder="Search feeding, sleep, play, millet recipes…"
        className="min-w-0 flex-1 bg-transparent px-1 py-2.5 text-[14px] text-ink outline-none placeholder:text-ink-soft/50"
      />
      {category ? <input type="hidden" name="category" value={category} /> : null}
      <button
        type="submit"
        className="rounded-full bg-clay px-5 py-2.5 text-[12.5px] font-semibold text-cream transition hover:bg-clay-dark"
      >
        Search
      </button>
    </form>
  );
}

function queryFromForm(form: HTMLFormElement) {
  const data = new FormData(form);
  return String(data.get("q") ?? "").trim();
}
