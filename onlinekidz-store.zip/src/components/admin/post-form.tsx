import { savePost } from "@/app/admin/actions";
import type { BlogPost } from "@/lib/blog-data";
import { blocksToText } from "@/lib/admin-content";
import { Field, inputClass } from "./form-fields";

export function PostForm({ post }: { post?: BlogPost }) {
  return (
    <form action={savePost} className="space-y-6">
      {post ? <input type="hidden" name="id" value={post.id} /> : null}
      <section className="grid gap-4 rounded-2xl border border-sand bg-white p-5 shadow-soft md:grid-cols-2">
        <div className="md:col-span-2">
          <Field label="Title"><input name="title" required defaultValue={post?.title} className={inputClass} /></Field>
        </div>
        <Field label="URL slug" hint="Leave blank to generate from the title.">
          <input name="slug" defaultValue={post?.slug} className={inputClass} />
        </Field>
        <Field label="Category"><input name="category" defaultValue={post?.category} placeholder="Feeding & weaning" className={inputClass} /></Field>
        <Field label="Author & credentials"><input name="author" defaultValue={post?.author} className={inputClass} /></Field>
        <Field label="Reading time (min)"><input name="readingMinutes" type="number" min={1} defaultValue={post?.readingMinutes ?? 5} className={inputClass} /></Field>
        <div className="md:col-span-2">
          <Field label="Hero image URL"><input name="heroImage" defaultValue={post?.heroImage} className={inputClass} /></Field>
        </div>
        <div className="md:col-span-2">
          <Field label="Excerpt"><textarea name="excerpt" rows={2} defaultValue={post?.excerpt} className={inputClass} /></Field>
        </div>
        <div className="flex gap-5 text-[13px] text-ink md:col-span-2">
          <label className="flex items-center gap-2"><input type="checkbox" name="featured" defaultChecked={post?.featured} className="h-4 w-4 accent-[#0866c6]" /> Featured</label>
          <label className="flex items-center gap-2"><input type="checkbox" name="sponsored" defaultChecked={post?.sponsored} className="h-4 w-4 accent-[#0866c6]" /> Sponsored (shows disclosure)</label>
        </div>
      </section>
      <section className="space-y-4 rounded-2xl border border-sand bg-white p-5 shadow-soft">
        <Field label="Article content" hint="Separate blocks with a blank line. Use “## ” for headings, “- ” for list items and “> ” for a highlighted tip.">
          <textarea name="content" rows={18} required defaultValue={post ? blocksToText(post.content) : ""} className={`${inputClass} font-mono text-[13px]`} />
        </Field>
        <Field label="Sources" hint="One per line as “Label | https://url”.">
          <textarea
            name="sources"
            rows={3}
            defaultValue={post?.sources.map((source) => `${source.label} | ${source.url}`).join("\n")}
            className={inputClass}
          />
        </Field>
      </section>
      <button type="submit" className="rounded-full bg-clay px-6 py-3 text-sm font-semibold text-white hover:bg-clay-dark">
        {post ? "Save article" : "Publish article"}
      </button>
    </form>
  );
}
