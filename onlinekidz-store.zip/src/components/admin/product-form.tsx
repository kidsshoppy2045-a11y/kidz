import type { CategoryRow, ProductRow } from "@/db/schema";
import { saveProduct } from "@/app/admin/actions";
import { Field, inputClass } from "./form-fields";

export function ProductForm({ product, categories }: { product?: ProductRow; categories: CategoryRow[] }) {
  return (
    <form action={saveProduct} className="space-y-6">
      {product ? <input type="hidden" name="id" value={product.id} /> : null}

      <section className="grid gap-4 rounded-2xl border border-sand bg-white p-5 shadow-soft md:grid-cols-2">
        <Field label="Product name"><input name="name" required defaultValue={product?.name} className={inputClass} /></Field>
        <Field label="URL slug" hint="Leave blank to generate from the name.">
          <input name="slug" defaultValue={product?.slug} className={inputClass} />
        </Field>
        <Field label="Category">
          <select name="categorySlug" defaultValue={product?.categorySlug ?? categories[0]?.slug} className={inputClass}>
            {categories.map((category) => (
              <option key={category.slug} value={category.slug}>{category.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Brand"><input name="brand" defaultValue={product?.brand} className={inputClass} /></Field>
        <div className="md:col-span-2">
          <Field label="Tagline"><input name="tagline" defaultValue={product?.tagline} className={inputClass} /></Field>
        </div>
        <div className="md:col-span-2">
          <Field label="Description"><textarea name="description" rows={4} defaultValue={product?.description} className={inputClass} /></Field>
        </div>
      </section>

      <section className="grid gap-4 rounded-2xl border border-sand bg-white p-5 shadow-soft sm:grid-cols-2 lg:grid-cols-4">
        <Field label="Price (₹)"><input name="price" type="number" min={1} required defaultValue={product?.price} className={inputClass} /></Field>
        <Field label="Compare-at price (₹)" hint="Optional original price.">
          <input name="compareAtPrice" type="number" min={0} defaultValue={product?.compareAtPrice ?? ""} className={inputClass} />
        </Field>
        <Field label="Stock"><input name="stock" type="number" min={0} defaultValue={product?.stock ?? 50} className={inputClass} /></Field>
        <Field label="Unit label"><input name="unitLabel" defaultValue={product?.unitLabel} placeholder="200 g" className={inputClass} /></Field>
        <Field label="Min age (months)"><input name="ageMonthsMin" type="number" min={0} defaultValue={product?.ageMonthsMin ?? 0} className={inputClass} /></Field>
        <Field label="Max age (months)"><input name="ageMonthsMax" type="number" min={1} defaultValue={product?.ageMonthsMax ?? 144} className={inputClass} /></Field>
        <Field label="Badge"><input name="badge" defaultValue={product?.badge ?? ""} placeholder="Bestseller" className={inputClass} /></Field>
        <fieldset className="space-y-2 text-[13px] text-ink">
          <legend className="text-[12px] font-semibold uppercase tracking-wider text-ink-soft">Merchandising</legend>
          {([
            ["isFeatured", "Featured", product?.isFeatured],
            ["isBestseller", "Bestseller", product?.isBestseller],
            ["isNew", "New arrival", product?.isNew],
          ] as const).map(([name, label, checked]) => (
            <label key={name} className="flex items-center gap-2">
              <input type="checkbox" name={name} defaultChecked={Boolean(checked)} className="h-4 w-4 accent-[#0866c6]" /> {label}
            </label>
          ))}
        </fieldset>
      </section>

      <section className="grid gap-4 rounded-2xl border border-sand bg-white p-5 shadow-soft lg:grid-cols-3">
        <Field label="Image URLs" hint="One per line. The first is the main image.">
          <textarea name="images" rows={5} required defaultValue={product?.images.join("\n")} className={inputClass} />
        </Field>
        <Field label="Highlights" hint="One benefit per line.">
          <textarea name="highlights" rows={5} defaultValue={product?.highlights.join("\n")} className={inputClass} />
        </Field>
        <Field label="Details" hint="One per line as “Label: value”.">
          <textarea
            name="details"
            rows={5}
            defaultValue={product?.details.map((detail) => `${detail.label}: ${detail.value}`).join("\n")}
            className={inputClass}
          />
        </Field>
      </section>

      <button type="submit" className="rounded-full bg-clay px-6 py-3 text-sm font-semibold text-white hover:bg-clay-dark">
        {product ? "Save changes" : "Create product"}
      </button>
    </form>
  );
}
