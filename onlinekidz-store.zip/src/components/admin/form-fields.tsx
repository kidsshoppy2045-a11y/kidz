import type { ReactNode } from "react";

export const inputClass =
  "mt-1 w-full rounded-xl border border-sand bg-white px-3.5 py-2.5 text-[14px] text-ink outline-none focus:border-clay";

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block text-[12px] font-semibold uppercase tracking-wider text-ink-soft">
      {label}
      {children}
      {hint ? <span className="mt-1 block text-[11px] font-normal normal-case tracking-normal text-ink-soft/80">{hint}</span> : null}
    </label>
  );
}

export function Notice({ error, saved }: { error?: string; saved?: string }) {
  if (error) {
    return <p role="alert" className="rounded-xl bg-brand-pink/10 p-3 text-[13px] font-medium text-ink">{error}</p>;
  }
  if (saved) {
    return <p role="status" className="rounded-xl bg-brand-green/10 p-3 text-[13px] font-medium text-brand-green">Saved successfully.</p>;
  }
  return null;
}
