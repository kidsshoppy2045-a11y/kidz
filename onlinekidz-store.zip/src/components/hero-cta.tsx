"use client";

import { useEffect, useState } from "react";
import { trackEvent } from "@/lib/analytics";
import { ArrowRightIcon } from "./icons";
import { TrackedLink } from "./tracked-link";

export function HeroCta() {
  const [variant, setVariant] = useState<"control" | "test">("control");

  useEffect(() => {
    const key = "onlinekids.home-hero-cta.v1";
    let assigned: "control" | "test" = "control";
    try {
      const existing = window.localStorage.getItem(key);
      if (existing === "control" || existing === "test") assigned = existing;
      else {
        assigned = Math.random() < 0.5 ? "control" : "test";
        window.localStorage.setItem(key, assigned);
      }
    } catch {
      assigned = "control";
    }
    setVariant(assigned);
    trackEvent("experiment_impression", undefined, {
      experiment: "home-hero-cta-v1",
      cta_variant: assigned,
    });
  }, []);

  return (
    <TrackedLink
      href="/shop"
      eventName="hero_cta_click"
      metadata={{
        placement: "home-hero",
        experiment: "home-hero-cta-v1",
        cta_variant: variant,
        cta_label: variant === "control" ? "Shop the collection" : "Find their next favorite",
      }}
      className="group inline-flex items-center gap-2 rounded-full bg-clay px-7 py-3.5 text-[15px] font-semibold text-cream shadow-soft transition-all duration-300 hover:bg-clay-dark hover:shadow-lift"
    >
      {variant === "control" ? "Shop the collection" : "Find their next favorite"}
      <ArrowRightIcon
        width={17}
        height={17}
        className="transition-transform duration-300 group-hover:translate-x-1"
      />
    </TrackedLink>
  );
}
