"use client";

import { useState } from "react";
import { trackEvent } from "@/lib/analytics";
import { ArrowRightIcon, CheckIcon } from "./icons";

export function JournalNewsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail.includes("@") || status === "loading") {
      setStatus("error");
      return;
    }

    setStatus("loading");
    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: normalizedEmail }),
      });
      if (!response.ok) throw new Error("Signup failed");
      trackEvent("newsletter_signup", undefined, { placement: "journal-newsletter" });
      setStatus("success");
      setEmail("");
    } catch {
      setStatus("error");
    }
  };

  return (
    <section aria-labelledby="journal-newsletter-title" className="overflow-hidden rounded-[2rem] border border-sand bg-shell/70">
      <div className="grid gap-6 p-6 sm:p-8 lg:grid-cols-[1fr_0.9fr] lg:items-center">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-clay">A thoughtful note, once a week</p>
          <h2 id="journal-newsletter-title" className="mt-2 font-display text-[25px] leading-tight text-ink sm:text-[30px]">
            Helpful reads for the next little milestone
          </h2>
          <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-ink-soft">
            Feeding guides, family recipes and practical care notes—plus 10% off your first order with LITTLE10.
          </p>
        </div>
        <div>
          {status === "success" ? (
            <p role="status" className="flex items-start gap-2 rounded-2xl bg-sage/15 p-4 text-[13px] font-medium leading-relaxed text-teal">
              <CheckIcon width={16} height={16} className="mt-0.5 shrink-0" />
              You&apos;re subscribed. Use LITTLE10 for 10% off your first order.
            </p>
          ) : (
            <form onSubmit={submit} className="flex gap-2">
              <label htmlFor="journal-email" className="sr-only">Email address</label>
              <input
                id="journal-email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => {
                  setEmail(event.target.value);
                  if (status === "error") setStatus("idle");
                }}
                placeholder="you@email.com"
                className="min-w-0 flex-1 rounded-full border border-sand bg-white px-4 py-3 text-[13px] outline-none transition focus:border-clay"
              />
              <button
                type="submit"
                disabled={status === "loading"}
                className="inline-flex shrink-0 items-center gap-2 rounded-full bg-clay px-4 py-3 text-[12.5px] font-semibold text-cream transition hover:bg-clay-dark disabled:opacity-60"
              >
                {status === "loading" ? "Joining…" : "Join"}
                <ArrowRightIcon width={14} height={14} />
              </button>
            </form>
          )}
          {status === "error" ? (
            <p role="alert" className="mt-2 text-[12px] font-medium text-clay">
              Please check your email address and try again.
            </p>
          ) : null}
          <p className="mt-2 text-[10.5px] leading-relaxed text-ink-soft/65">
            By subscribing, you agree to receive OnlineKidz email updates. We use your address only for these updates and never sell it.
          </p>
        </div>
      </div>
    </section>
  );
}
