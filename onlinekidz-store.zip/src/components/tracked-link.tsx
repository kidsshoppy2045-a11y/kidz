"use client";

import Link from "next/link";
import type { ComponentProps, MouseEventHandler } from "react";
import { trackEvent, type AnalyticsEventName, type AnalyticsMetadata } from "@/lib/analytics";

type Props = ComponentProps<typeof Link> & {
  eventName: AnalyticsEventName;
  productSlug?: string;
  metadata?: AnalyticsMetadata;
};

export function TrackedLink({
  eventName,
  productSlug,
  metadata,
  onClick,
  ...props
}: Props) {
  const handleClick: MouseEventHandler<HTMLAnchorElement> = (event) => {
    trackEvent(eventName, productSlug, metadata);
    onClick?.(event);
  };

  return <Link {...props} onClick={handleClick} />;
}
