import { StarIcon } from "./icons";

export function Stars({
  rating,
  size = 14,
  className = "",
}: {
  rating: number;
  size?: number;
  className?: string;
}) {
  const rounded = Math.round(rating * 2) / 2;
  return (
    <span className={`inline-flex items-center gap-[2px] text-saffron ${className}`}>
      {[1, 2, 3, 4, 5].map((star) => {
        const fill = rounded >= star;
        const half = !fill && rounded >= star - 0.5;
        return (
          <StarIcon
            key={star}
            filled={fill || half}
            width={size}
            height={size}
            aria-hidden
            className={fill || half ? "" : "text-sand"}
          />
        );
      })}
    </span>
  );
}
