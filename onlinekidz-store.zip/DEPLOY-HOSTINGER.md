# Deploying OnlineKidz.Store on Hostinger

This is a Next.js 16 app with a PostgreSQL database. Hostinger runs the app
(Node.js Web App), and a hosted PostgreSQL database stores your products,
orders, reviews, journal articles and subscribers.

## What you need

- A Hostinger **Business** or **Cloud** hosting plan (the Premium plan cannot
  run Node.js apps).
- A free or paid **Supabase** project for the PostgreSQL database
  (https://supabase.com). Hostinger's database wizard for Node.js apps supports
  Supabase. Any other hosted PostgreSQL 13+ database also works.

> Hostinger's built-in MySQL databases cannot be used by this version of the
> app; it is written for PostgreSQL. The MySQL files in `database/mysql/` are
> for reference or a future migration only.

## Step 1 — Create the database (Supabase)

1. Create a new Supabase project. Choose a region close to your customers
   (for India: **Mumbai, ap-south-1**). Save the database password.
2. Open **SQL Editor → New query**, paste the full contents of
   `database/postgres/schema.sql`, and click **Run**. This creates the 7 tables.
3. Click **Connect** (top of the project page) and copy the
   **Session pooler** connection string. Replace `[YOUR-PASSWORD]` with your
   database password. This is your `DATABASE_URL`.

You don't need to import any data: the website adds the starter categories,
products, reviews and journal articles automatically the first time it runs.

## Step 2 — Deploy the app on Hostinger

1. In hPanel go to **Websites → Add Website → Node.js web app**.
2. Choose **Upload your files** and upload `onlinekidz-store.zip`.
3. Check the detected settings:
   - Framework preset: **Next.js**
   - Node.js version: **22**
   - Build command: `npm run build`
   - Package manager: **npm**
4. Add these **environment variables** (see `.env.example`):

   | Name | Value |
   |---|---|
   | `DATABASE_URL` | your Supabase Session pooler connection string |
   | `DATABASE_SSL` | `require` |
   | `ADMIN_PASSWORD` | a new, long, random password |
   | `NODE_ENV` | `production` |

5. Click **Deploy** and wait for the build to finish.

## Step 3 — Check the live site

- Open `https://your-domain/api/health` — it should show `{"ok":true}`.
- Open the home page. The first load may take a few seconds while the
  starter catalog is created.
- Sign in at `https://your-domain/admin` with your `ADMIN_PASSWORD`.

## Before going live

- **Update `https://onlinekidz.store` references** if your domain differs.
  They are used in SEO metadata in `src/app/layout.tsx`, `src/app/sitemap.ts`,
  `src/app/robots.ts`, `src/app/blog/page.tsx`, `src/app/blog/[slug]/page.tsx`
  and `src/app/product/[slug]/page.tsx`.
- **Replace the demo content**: products, prices, reviews and articles are
  realistic samples. Edit or delete them in `/admin`.
- **Payments are not connected.** Checkout records orders but does not charge
  customers. Connect a payment gateway (e.g. Razorpay) before accepting real
  orders.
- **Add the official logo** as `public/brand/onlinekidz-logo.png`.
- Video testimonials use illustrative Pexels clips — replace them with real,
  consented customer videos.

## Updating the site later

Upload a new zip of the project to the same Web App (or connect a GitHub
repository for automatic deploys). Your data stays in Supabase.

## Troubleshooting

- **Build fails with "DATABASE_URL is required"** — add the environment
  variables in Hostinger, then redeploy.
- **App shows an error after a successful build** — open **Runtime Logs**.
  Connection errors usually mean a wrong password in `DATABASE_URL`, or a
  missing `DATABASE_SSL=require`.
- **"relation ... does not exist"** — run `database/postgres/schema.sql` in the
  Supabase SQL Editor.
