// Exports catalog content from the live PostgreSQL database as MySQL INSERTs.
// Usage: node scripts/export-mysql-seed.mjs > database/mysql/seed.sql
import pg from "pg";
import "dotenv/config";

const TABLES = [
  {
    name: "categories",
    columns: ["id", "slug", "name", "tagline", "description", "image", "accent", "sort_order"],
  },
  {
    name: "products",
    columns: [
      "id", "slug", "name", "category_slug", "brand", "tagline", "description", "price",
      "compare_at_price", "rating", "review_count", "stock", "age_months_min", "age_months_max",
      "badge", "unit_label", "images", "highlights", "details", "is_featured", "is_bestseller",
      "is_new", "sold_count", "created_at",
    ],
  },
  {
    name: "reviews",
    columns: ["id", "product_slug", "author", "city", "rating", "title", "body", "verified", "created_at"],
  },
  {
    name: "blog_posts",
    columns: [
      "id", "slug", "title", "excerpt", "category", "author", "reading_minutes", "hero_image",
      "published_at", "updated_at", "sponsored", "sources", "content", "featured",
    ],
  },
];

const quote = (text) =>
  `'${text
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\'")
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r")
    .replace(/\0/g, "\\0")}'`;

function value(input) {
  if (input === null || input === undefined) return "NULL";
  if (typeof input === "boolean") return input ? "1" : "0";
  if (typeof input === "number") return String(input);
  if (input instanceof Date) return quote(input.toISOString().replace("T", " ").replace("Z", ""));
  if (typeof input === "object") return quote(JSON.stringify(input));
  return quote(String(input));
}

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();

const out = [
  "-- ============================================================================",
  "-- OnlineKidz.Store — MySQL catalog data",
  `-- Generated ${new Date().toISOString()} from the live database.`,
  "-- Run after schema.sql. Timestamps are UTC.",
  "-- Orders, subscribers and analytics are intentionally excluded (test data).",
  "-- ============================================================================",
  "",
  "USE onlinekidz_store;",
  "SET NAMES utf8mb4;",
  "SET time_zone = '+00:00';",
  "SET FOREIGN_KEY_CHECKS = 0;",
  "START TRANSACTION;",
  "",
];

for (const table of TABLES) {
  const { rows } = await client.query(
    `select ${table.columns.join(", ")} from ${table.name} order by id`,
  );
  out.push(`-- ${table.name}: ${rows.length} rows`);
  out.push(`DELETE FROM ${table.name};`);
  for (let i = 0; i < rows.length; i += 25) {
    const chunk = rows.slice(i, i + 25);
    out.push(`INSERT INTO ${table.name} (${table.columns.join(", ")}) VALUES`);
    out.push(
      chunk
        .map((row) => `  (${table.columns.map((column) => value(row[column])).join(", ")})`)
        .join(",\n") + ";",
    );
  }
  const maxId = rows.reduce((max, row) => Math.max(max, row.id), 0);
  out.push(`ALTER TABLE ${table.name} AUTO_INCREMENT = ${maxId + 1};`, "");
}

out.push("COMMIT;", "SET FOREIGN_KEY_CHECKS = 1;", "");
process.stdout.write(out.join("\n"));
await client.end();
